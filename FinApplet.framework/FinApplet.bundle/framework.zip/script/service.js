/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "script/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 612);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var core = __webpack_require__(24);
var hide = __webpack_require__(15);
var redefine = __webpack_require__(16);
var ctx = __webpack_require__(25);
var PROTOTYPE = 'prototype';

var $export = function (type, name, source) {
  var IS_FORCED = type & $export.F;
  var IS_GLOBAL = type & $export.G;
  var IS_STATIC = type & $export.S;
  var IS_PROTO = type & $export.P;
  var IS_BIND = type & $export.B;
  var target = IS_GLOBAL ? global : IS_STATIC ? global[name] || (global[name] = {}) : (global[name] || {})[PROTOTYPE];
  var exports = IS_GLOBAL ? core : core[name] || (core[name] = {});
  var expProto = exports[PROTOTYPE] || (exports[PROTOTYPE] = {});
  var key, own, out, exp;
  if (IS_GLOBAL) source = name;
  for (key in source) {
    // contains in native
    own = !IS_FORCED && target && target[key] !== undefined;
    // export native or passed
    out = (own ? target : source)[key];
    // bind timers to global for call from export context
    exp = IS_BIND && own ? ctx(out, global) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
    // extend global
    if (target) redefine(target, key, out, type & $export.U);
    // export
    if (exports[key] != out) hide(exports, key, exp);
    if (IS_PROTO && expProto[key] != out) expProto[key] = out;
  }
};
global.core = core;
// type bitmap
$export.F = 1;   // forced
$export.G = 2;   // global
$export.S = 4;   // static
$export.P = 8;   // proto
$export.B = 16;  // bind
$export.W = 32;  // wrap
$export.U = 64;  // safe
$export.R = 128; // real proto method for `library`
module.exports = $export;


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
module.exports = function (it) {
  if (!isObject(it)) throw TypeError(it + ' is not an object!');
  return it;
};


/***/ }),
/* 2 */
/***/ (function(module, exports) {

// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var global = module.exports = typeof window != 'undefined' && window.Math == Math
  ? window : typeof self != 'undefined' && self.Math == Math ? self
  // eslint-disable-next-line no-new-func
  : Function('return this')();
if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef


/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = function (exec) {
  try {
    return !!exec();
  } catch (e) {
    return true;
  }
};


/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = function (it) {
  return typeof it === 'object' ? it !== null : typeof it === 'function';
};


/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

var store = __webpack_require__(68)('wks');
var uid = __webpack_require__(47);
var Symbol = __webpack_require__(2).Symbol;
var USE_SYMBOL = typeof Symbol == 'function';

var $exports = module.exports = function (name) {
  return store[name] || (store[name] =
    USE_SYMBOL && Symbol[name] || (USE_SYMBOL ? Symbol : uid)('Symbol.' + name));
};

$exports.store = store;


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.15 ToLength
var toInteger = __webpack_require__(27);
var min = Math.min;
module.exports = function (it) {
  return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
};


/***/ }),
/* 7 */
/***/ (function(module, exports) {

var core = module.exports = { version: '2.6.5' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

// Thank's IE8 for his funny defineProperty
module.exports = !__webpack_require__(3)(function () {
  return Object.defineProperty({}, 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(1);
var IE8_DOM_DEFINE = __webpack_require__(156);
var toPrimitive = __webpack_require__(31);
var dP = Object.defineProperty;

exports.f = __webpack_require__(8) ? Object.defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPrimitive(P, true);
  anObject(Attributes);
  if (IE8_DOM_DEFINE) try {
    return dP(O, P, Attributes);
  } catch (e) { /* empty */ }
  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};


/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.13 ToObject(argument)
var defined = __webpack_require__(32);
module.exports = function (it) {
  return Object(defined(it));
};


/***/ }),
/* 11 */
/***/ (function(module, exports) {

module.exports = function (it) {
  if (typeof it != 'function') throw TypeError(it + ' is not a function!');
  return it;
};


/***/ }),
/* 12 */
/***/ (function(module, exports) {

// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var global = module.exports = typeof window != 'undefined' && window.Math == Math
  ? window : typeof self != 'undefined' && self.Math == Math ? self
  // eslint-disable-next-line no-new-func
  : Function('return this')();
if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef


/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _iterator = __webpack_require__(216);

var _iterator2 = _interopRequireDefault(_iterator);

var _symbol = __webpack_require__(199);

var _symbol2 = _interopRequireDefault(_symbol);

var _typeof = typeof _symbol2.default === "function" && typeof _iterator2.default === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof _symbol2.default === "function" && obj.constructor === _symbol2.default && obj !== _symbol2.default.prototype ? "symbol" : typeof obj; };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = typeof _symbol2.default === "function" && _typeof(_iterator2.default) === "symbol" ? function (obj) {
  return typeof obj === "undefined" ? "undefined" : _typeof(obj);
} : function (obj) {
  return obj && typeof _symbol2.default === "function" && obj.constructor === _symbol2.default && obj !== _symbol2.default.prototype ? "symbol" : typeof obj === "undefined" ? "undefined" : _typeof(obj);
};

/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

var store = __webpack_require__(139)('wks');
var uid = __webpack_require__(96);
var Symbol = __webpack_require__(12).Symbol;
var USE_SYMBOL = typeof Symbol == 'function';

var $exports = module.exports = function (name) {
  return store[name] || (store[name] =
    USE_SYMBOL && Symbol[name] || (USE_SYMBOL ? Symbol : uid)('Symbol.' + name));
};

$exports.store = store;


/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(9);
var createDesc = __webpack_require__(46);
module.exports = __webpack_require__(8) ? function (object, key, value) {
  return dP.f(object, key, createDesc(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};


/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var hide = __webpack_require__(15);
var has = __webpack_require__(19);
var SRC = __webpack_require__(47)('src');
var $toString = __webpack_require__(231);
var TO_STRING = 'toString';
var TPL = ('' + $toString).split(TO_STRING);

__webpack_require__(24).inspectSource = function (it) {
  return $toString.call(it);
};

(module.exports = function (O, key, val, safe) {
  var isFunction = typeof val == 'function';
  if (isFunction) has(val, 'name') || hide(val, 'name', key);
  if (O[key] === val) return;
  if (isFunction) has(val, SRC) || hide(val, SRC, O[key] ? '' + O[key] : TPL.join(String(key)));
  if (O === global) {
    O[key] = val;
  } else if (!safe) {
    delete O[key];
    hide(O, key, val);
  } else if (O[key]) {
    O[key] = val;
  } else {
    hide(O, key, val);
  }
// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
})(Function.prototype, TO_STRING, function toString() {
  return typeof this == 'function' && this[SRC] || $toString.call(this);
});


/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var fails = __webpack_require__(3);
var defined = __webpack_require__(32);
var quot = /"/g;
// B.2.3.2.1 CreateHTML(string, tag, attribute, value)
var createHTML = function (string, tag, attribute, value) {
  var S = String(defined(string));
  var p1 = '<' + tag;
  if (attribute !== '') p1 += ' ' + attribute + '="' + String(value).replace(quot, '&quot;') + '"';
  return p1 + '>' + S + '</' + tag + '>';
};
module.exports = function (NAME, exec) {
  var O = {};
  O[NAME] = exec(createHTML);
  $export($export.P + $export.F * fails(function () {
    var test = ''[NAME]('"');
    return test !== test.toLowerCase() || test.split('"').length > 3;
  }), 'String', O);
};


/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(12);
var core = __webpack_require__(7);
var ctx = __webpack_require__(64);
var hide = __webpack_require__(58);
var has = __webpack_require__(57);
var PROTOTYPE = 'prototype';

var $export = function (type, name, source) {
  var IS_FORCED = type & $export.F;
  var IS_GLOBAL = type & $export.G;
  var IS_STATIC = type & $export.S;
  var IS_PROTO = type & $export.P;
  var IS_BIND = type & $export.B;
  var IS_WRAP = type & $export.W;
  var exports = IS_GLOBAL ? core : core[name] || (core[name] = {});
  var expProto = exports[PROTOTYPE];
  var target = IS_GLOBAL ? global : IS_STATIC ? global[name] : (global[name] || {})[PROTOTYPE];
  var key, own, out;
  if (IS_GLOBAL) source = name;
  for (key in source) {
    // contains in native
    own = !IS_FORCED && target && target[key] !== undefined;
    if (own && has(exports, key)) continue;
    // export native or passed
    out = own ? target[key] : source[key];
    // prevent global pollution for namespaces
    exports[key] = IS_GLOBAL && typeof target[key] != 'function' ? source[key]
    // bind timers to global for call from export context
    : IS_BIND && own ? ctx(out, global)
    // wrap global constructors for prevent change them in library
    : IS_WRAP && target[key] == out ? (function (C) {
      var F = function (a, b, c) {
        if (this instanceof C) {
          switch (arguments.length) {
            case 0: return new C();
            case 1: return new C(a);
            case 2: return new C(a, b);
          } return new C(a, b, c);
        } return C.apply(this, arguments);
      };
      F[PROTOTYPE] = C[PROTOTYPE];
      return F;
    // make static versions for prototype methods
    })(out) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
    // export proto methods to core.%CONSTRUCTOR%.methods.%NAME%
    if (IS_PROTO) {
      (exports.virtual || (exports.virtual = {}))[key] = out;
      // export proto methods to core.%CONSTRUCTOR%.prototype.%NAME%
      if (type & $export.R && expProto && !expProto[key]) hide(expProto, key, out);
    }
  }
};
// type bitmap
$export.F = 1;   // forced
$export.G = 2;   // global
$export.S = 4;   // static
$export.P = 8;   // proto
$export.B = 16;  // bind
$export.W = 32;  // wrap
$export.U = 64;  // safe
$export.R = 128; // real proto method for `library`
module.exports = $export;


/***/ }),
/* 19 */
/***/ (function(module, exports) {

var hasOwnProperty = {}.hasOwnProperty;
module.exports = function (it, key) {
  return hasOwnProperty.call(it, key);
};


/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

// to indexed object, toObject with fallback for non-array-like ES3 strings
var IObject = __webpack_require__(69);
var defined = __webpack_require__(32);
module.exports = function (it) {
  return IObject(defined(it));
};


/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

var pIE = __webpack_require__(70);
var createDesc = __webpack_require__(46);
var toIObject = __webpack_require__(20);
var toPrimitive = __webpack_require__(31);
var has = __webpack_require__(19);
var IE8_DOM_DEFINE = __webpack_require__(156);
var gOPD = Object.getOwnPropertyDescriptor;

exports.f = __webpack_require__(8) ? gOPD : function getOwnPropertyDescriptor(O, P) {
  O = toIObject(O);
  P = toPrimitive(P, true);
  if (IE8_DOM_DEFINE) try {
    return gOPD(O, P);
  } catch (e) { /* empty */ }
  if (has(O, P)) return createDesc(!pIE.f.call(O, P), O[P]);
};


/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)
var has = __webpack_require__(19);
var toObject = __webpack_require__(10);
var IE_PROTO = __webpack_require__(110)('IE_PROTO');
var ObjectProto = Object.prototype;

module.exports = Object.getPrototypeOf || function (O) {
  O = toObject(O);
  if (has(O, IE_PROTO)) return O[IE_PROTO];
  if (typeof O.constructor == 'function' && O instanceof O.constructor) {
    return O.constructor.prototype;
  } return O instanceof Object ? ObjectProto : null;
};


/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

exports.default = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

/***/ }),
/* 24 */
/***/ (function(module, exports) {

var core = module.exports = { version: '2.6.5' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

// optional / simple context binding
var aFunction = __webpack_require__(11);
module.exports = function (fn, that, length) {
  aFunction(fn);
  if (that === undefined) return fn;
  switch (length) {
    case 1: return function (a) {
      return fn.call(that, a);
    };
    case 2: return function (a, b) {
      return fn.call(that, a, b);
    };
    case 3: return function (a, b, c) {
      return fn.call(that, a, b, c);
    };
  }
  return function (/* ...args */) {
    return fn.apply(that, arguments);
  };
};


/***/ }),
/* 26 */
/***/ (function(module, exports) {

var toString = {}.toString;

module.exports = function (it) {
  return toString.call(it).slice(8, -1);
};


/***/ }),
/* 27 */
/***/ (function(module, exports) {

// 7.1.4 ToInteger
var ceil = Math.ceil;
var floor = Math.floor;
module.exports = function (it) {
  return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
};


/***/ }),
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var fails = __webpack_require__(3);

module.exports = function (method, arg) {
  return !!method && fails(function () {
    // eslint-disable-next-line no-useless-call
    arg ? method.call(null, function () { /* empty */ }, 1) : method.call(null);
  });
};


/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _defineProperty = __webpack_require__(105);

var _defineProperty2 = _interopRequireDefault(_defineProperty);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      (0, _defineProperty2.default)(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();

/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(456), __esModule: true };

/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.1 ToPrimitive(input [, PreferredType])
var isObject = __webpack_require__(4);
// instead of the ES6 spec version, we didn't implement @@toPrimitive case
// and the second argument - flag - preferred type is a string
module.exports = function (it, S) {
  if (!isObject(it)) return it;
  var fn, val;
  if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
  if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  throw TypeError("Can't convert object to primitive value");
};


/***/ }),
/* 32 */
/***/ (function(module, exports) {

// 7.2.1 RequireObjectCoercible(argument)
module.exports = function (it) {
  if (it == undefined) throw TypeError("Can't call method on  " + it);
  return it;
};


/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

// most Object methods by ES6 should accept primitives
var $export = __webpack_require__(0);
var core = __webpack_require__(24);
var fails = __webpack_require__(3);
module.exports = function (KEY, exec) {
  var fn = (core.Object || {})[KEY] || Object[KEY];
  var exp = {};
  exp[KEY] = exec(fn);
  $export($export.S + $export.F * fails(function () { fn(1); }), 'Object', exp);
};


/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

// 0 -> Array#forEach
// 1 -> Array#map
// 2 -> Array#filter
// 3 -> Array#some
// 4 -> Array#every
// 5 -> Array#find
// 6 -> Array#findIndex
var ctx = __webpack_require__(25);
var IObject = __webpack_require__(69);
var toObject = __webpack_require__(10);
var toLength = __webpack_require__(6);
var asc = __webpack_require__(126);
module.exports = function (TYPE, $create) {
  var IS_MAP = TYPE == 1;
  var IS_FILTER = TYPE == 2;
  var IS_SOME = TYPE == 3;
  var IS_EVERY = TYPE == 4;
  var IS_FIND_INDEX = TYPE == 6;
  var NO_HOLES = TYPE == 5 || IS_FIND_INDEX;
  var create = $create || asc;
  return function ($this, callbackfn, that) {
    var O = toObject($this);
    var self = IObject(O);
    var f = ctx(callbackfn, that, 3);
    var length = toLength(self.length);
    var index = 0;
    var result = IS_MAP ? create($this, length) : IS_FILTER ? create($this, 0) : undefined;
    var val, res;
    for (;length > index; index++) if (NO_HOLES || index in self) {
      val = self[index];
      res = f(val, index, O);
      if (TYPE) {
        if (IS_MAP) result[index] = res;   // map
        else if (res) switch (TYPE) {
          case 3: return true;             // some
          case 5: return val;              // find
          case 6: return index;            // findIndex
          case 2: result.push(val);        // filter
        } else if (IS_EVERY) return false; // every
      }
    }
    return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : result;
  };
};


/***/ }),
/* 35 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(44);
module.exports = function (it) {
  if (!isObject(it)) throw TypeError(it + ' is not an object!');
  return it;
};


/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(430), __esModule: true };

/***/ }),
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(432), __esModule: true };

/***/ }),
/* 38 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

if (__webpack_require__(8)) {
  var LIBRARY = __webpack_require__(41);
  var global = __webpack_require__(2);
  var fails = __webpack_require__(3);
  var $export = __webpack_require__(0);
  var $typed = __webpack_require__(92);
  var $buffer = __webpack_require__(134);
  var ctx = __webpack_require__(25);
  var anInstance = __webpack_require__(53);
  var propertyDesc = __webpack_require__(46);
  var hide = __webpack_require__(15);
  var redefineAll = __webpack_require__(55);
  var toInteger = __webpack_require__(27);
  var toLength = __webpack_require__(6);
  var toIndex = __webpack_require__(184);
  var toAbsoluteIndex = __webpack_require__(49);
  var toPrimitive = __webpack_require__(31);
  var has = __webpack_require__(19);
  var classof = __webpack_require__(61);
  var isObject = __webpack_require__(4);
  var toObject = __webpack_require__(10);
  var isArrayIter = __webpack_require__(123);
  var create = __webpack_require__(50);
  var getPrototypeOf = __webpack_require__(22);
  var gOPN = __webpack_require__(51).f;
  var getIterFn = __webpack_require__(125);
  var uid = __webpack_require__(47);
  var wks = __webpack_require__(5);
  var createArrayMethod = __webpack_require__(34);
  var createArrayIncludes = __webpack_require__(82);
  var speciesConstructor = __webpack_require__(72);
  var ArrayIterators = __webpack_require__(128);
  var Iterators = __webpack_require__(63);
  var $iterDetect = __webpack_require__(87);
  var setSpecies = __webpack_require__(52);
  var arrayFill = __webpack_require__(127);
  var arrayCopyWithin = __webpack_require__(173);
  var $DP = __webpack_require__(9);
  var $GOPD = __webpack_require__(21);
  var dP = $DP.f;
  var gOPD = $GOPD.f;
  var RangeError = global.RangeError;
  var TypeError = global.TypeError;
  var Uint8Array = global.Uint8Array;
  var ARRAY_BUFFER = 'ArrayBuffer';
  var SHARED_BUFFER = 'Shared' + ARRAY_BUFFER;
  var BYTES_PER_ELEMENT = 'BYTES_PER_ELEMENT';
  var PROTOTYPE = 'prototype';
  var ArrayProto = Array[PROTOTYPE];
  var $ArrayBuffer = $buffer.ArrayBuffer;
  var $DataView = $buffer.DataView;
  var arrayForEach = createArrayMethod(0);
  var arrayFilter = createArrayMethod(2);
  var arraySome = createArrayMethod(3);
  var arrayEvery = createArrayMethod(4);
  var arrayFind = createArrayMethod(5);
  var arrayFindIndex = createArrayMethod(6);
  var arrayIncludes = createArrayIncludes(true);
  var arrayIndexOf = createArrayIncludes(false);
  var arrayValues = ArrayIterators.values;
  var arrayKeys = ArrayIterators.keys;
  var arrayEntries = ArrayIterators.entries;
  var arrayLastIndexOf = ArrayProto.lastIndexOf;
  var arrayReduce = ArrayProto.reduce;
  var arrayReduceRight = ArrayProto.reduceRight;
  var arrayJoin = ArrayProto.join;
  var arraySort = ArrayProto.sort;
  var arraySlice = ArrayProto.slice;
  var arrayToString = ArrayProto.toString;
  var arrayToLocaleString = ArrayProto.toLocaleString;
  var ITERATOR = wks('iterator');
  var TAG = wks('toStringTag');
  var TYPED_CONSTRUCTOR = uid('typed_constructor');
  var DEF_CONSTRUCTOR = uid('def_constructor');
  var ALL_CONSTRUCTORS = $typed.CONSTR;
  var TYPED_ARRAY = $typed.TYPED;
  var VIEW = $typed.VIEW;
  var WRONG_LENGTH = 'Wrong length!';

  var $map = createArrayMethod(1, function (O, length) {
    return allocate(speciesConstructor(O, O[DEF_CONSTRUCTOR]), length);
  });

  var LITTLE_ENDIAN = fails(function () {
    // eslint-disable-next-line no-undef
    return new Uint8Array(new Uint16Array([1]).buffer)[0] === 1;
  });

  var FORCED_SET = !!Uint8Array && !!Uint8Array[PROTOTYPE].set && fails(function () {
    new Uint8Array(1).set({});
  });

  var toOffset = function (it, BYTES) {
    var offset = toInteger(it);
    if (offset < 0 || offset % BYTES) throw RangeError('Wrong offset!');
    return offset;
  };

  var validate = function (it) {
    if (isObject(it) && TYPED_ARRAY in it) return it;
    throw TypeError(it + ' is not a typed array!');
  };

  var allocate = function (C, length) {
    if (!(isObject(C) && TYPED_CONSTRUCTOR in C)) {
      throw TypeError('It is not a typed array constructor!');
    } return new C(length);
  };

  var speciesFromList = function (O, list) {
    return fromList(speciesConstructor(O, O[DEF_CONSTRUCTOR]), list);
  };

  var fromList = function (C, list) {
    var index = 0;
    var length = list.length;
    var result = allocate(C, length);
    while (length > index) result[index] = list[index++];
    return result;
  };

  var addGetter = function (it, key, internal) {
    dP(it, key, { get: function () { return this._d[internal]; } });
  };

  var $from = function from(source /* , mapfn, thisArg */) {
    var O = toObject(source);
    var aLen = arguments.length;
    var mapfn = aLen > 1 ? arguments[1] : undefined;
    var mapping = mapfn !== undefined;
    var iterFn = getIterFn(O);
    var i, length, values, result, step, iterator;
    if (iterFn != undefined && !isArrayIter(iterFn)) {
      for (iterator = iterFn.call(O), values = [], i = 0; !(step = iterator.next()).done; i++) {
        values.push(step.value);
      } O = values;
    }
    if (mapping && aLen > 2) mapfn = ctx(mapfn, arguments[2], 2);
    for (i = 0, length = toLength(O.length), result = allocate(this, length); length > i; i++) {
      result[i] = mapping ? mapfn(O[i], i) : O[i];
    }
    return result;
  };

  var $of = function of(/* ...items */) {
    var index = 0;
    var length = arguments.length;
    var result = allocate(this, length);
    while (length > index) result[index] = arguments[index++];
    return result;
  };

  // iOS Safari 6.x fails here
  var TO_LOCALE_BUG = !!Uint8Array && fails(function () { arrayToLocaleString.call(new Uint8Array(1)); });

  var $toLocaleString = function toLocaleString() {
    return arrayToLocaleString.apply(TO_LOCALE_BUG ? arraySlice.call(validate(this)) : validate(this), arguments);
  };

  var proto = {
    copyWithin: function copyWithin(target, start /* , end */) {
      return arrayCopyWithin.call(validate(this), target, start, arguments.length > 2 ? arguments[2] : undefined);
    },
    every: function every(callbackfn /* , thisArg */) {
      return arrayEvery(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    fill: function fill(value /* , start, end */) { // eslint-disable-line no-unused-vars
      return arrayFill.apply(validate(this), arguments);
    },
    filter: function filter(callbackfn /* , thisArg */) {
      return speciesFromList(this, arrayFilter(validate(this), callbackfn,
        arguments.length > 1 ? arguments[1] : undefined));
    },
    find: function find(predicate /* , thisArg */) {
      return arrayFind(validate(this), predicate, arguments.length > 1 ? arguments[1] : undefined);
    },
    findIndex: function findIndex(predicate /* , thisArg */) {
      return arrayFindIndex(validate(this), predicate, arguments.length > 1 ? arguments[1] : undefined);
    },
    forEach: function forEach(callbackfn /* , thisArg */) {
      arrayForEach(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    indexOf: function indexOf(searchElement /* , fromIndex */) {
      return arrayIndexOf(validate(this), searchElement, arguments.length > 1 ? arguments[1] : undefined);
    },
    includes: function includes(searchElement /* , fromIndex */) {
      return arrayIncludes(validate(this), searchElement, arguments.length > 1 ? arguments[1] : undefined);
    },
    join: function join(separator) { // eslint-disable-line no-unused-vars
      return arrayJoin.apply(validate(this), arguments);
    },
    lastIndexOf: function lastIndexOf(searchElement /* , fromIndex */) { // eslint-disable-line no-unused-vars
      return arrayLastIndexOf.apply(validate(this), arguments);
    },
    map: function map(mapfn /* , thisArg */) {
      return $map(validate(this), mapfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    reduce: function reduce(callbackfn /* , initialValue */) { // eslint-disable-line no-unused-vars
      return arrayReduce.apply(validate(this), arguments);
    },
    reduceRight: function reduceRight(callbackfn /* , initialValue */) { // eslint-disable-line no-unused-vars
      return arrayReduceRight.apply(validate(this), arguments);
    },
    reverse: function reverse() {
      var that = this;
      var length = validate(that).length;
      var middle = Math.floor(length / 2);
      var index = 0;
      var value;
      while (index < middle) {
        value = that[index];
        that[index++] = that[--length];
        that[length] = value;
      } return that;
    },
    some: function some(callbackfn /* , thisArg */) {
      return arraySome(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    sort: function sort(comparefn) {
      return arraySort.call(validate(this), comparefn);
    },
    subarray: function subarray(begin, end) {
      var O = validate(this);
      var length = O.length;
      var $begin = toAbsoluteIndex(begin, length);
      return new (speciesConstructor(O, O[DEF_CONSTRUCTOR]))(
        O.buffer,
        O.byteOffset + $begin * O.BYTES_PER_ELEMENT,
        toLength((end === undefined ? length : toAbsoluteIndex(end, length)) - $begin)
      );
    }
  };

  var $slice = function slice(start, end) {
    return speciesFromList(this, arraySlice.call(validate(this), start, end));
  };

  var $set = function set(arrayLike /* , offset */) {
    validate(this);
    var offset = toOffset(arguments[1], 1);
    var length = this.length;
    var src = toObject(arrayLike);
    var len = toLength(src.length);
    var index = 0;
    if (len + offset > length) throw RangeError(WRONG_LENGTH);
    while (index < len) this[offset + index] = src[index++];
  };

  var $iterators = {
    entries: function entries() {
      return arrayEntries.call(validate(this));
    },
    keys: function keys() {
      return arrayKeys.call(validate(this));
    },
    values: function values() {
      return arrayValues.call(validate(this));
    }
  };

  var isTAIndex = function (target, key) {
    return isObject(target)
      && target[TYPED_ARRAY]
      && typeof key != 'symbol'
      && key in target
      && String(+key) == String(key);
  };
  var $getDesc = function getOwnPropertyDescriptor(target, key) {
    return isTAIndex(target, key = toPrimitive(key, true))
      ? propertyDesc(2, target[key])
      : gOPD(target, key);
  };
  var $setDesc = function defineProperty(target, key, desc) {
    if (isTAIndex(target, key = toPrimitive(key, true))
      && isObject(desc)
      && has(desc, 'value')
      && !has(desc, 'get')
      && !has(desc, 'set')
      // TODO: add validation descriptor w/o calling accessors
      && !desc.configurable
      && (!has(desc, 'writable') || desc.writable)
      && (!has(desc, 'enumerable') || desc.enumerable)
    ) {
      target[key] = desc.value;
      return target;
    } return dP(target, key, desc);
  };

  if (!ALL_CONSTRUCTORS) {
    $GOPD.f = $getDesc;
    $DP.f = $setDesc;
  }

  $export($export.S + $export.F * !ALL_CONSTRUCTORS, 'Object', {
    getOwnPropertyDescriptor: $getDesc,
    defineProperty: $setDesc
  });

  if (fails(function () { arrayToString.call({}); })) {
    arrayToString = arrayToLocaleString = function toString() {
      return arrayJoin.call(this);
    };
  }

  var $TypedArrayPrototype$ = redefineAll({}, proto);
  redefineAll($TypedArrayPrototype$, $iterators);
  hide($TypedArrayPrototype$, ITERATOR, $iterators.values);
  redefineAll($TypedArrayPrototype$, {
    slice: $slice,
    set: $set,
    constructor: function () { /* noop */ },
    toString: arrayToString,
    toLocaleString: $toLocaleString
  });
  addGetter($TypedArrayPrototype$, 'buffer', 'b');
  addGetter($TypedArrayPrototype$, 'byteOffset', 'o');
  addGetter($TypedArrayPrototype$, 'byteLength', 'l');
  addGetter($TypedArrayPrototype$, 'length', 'e');
  dP($TypedArrayPrototype$, TAG, {
    get: function () { return this[TYPED_ARRAY]; }
  });

  // eslint-disable-next-line max-statements
  module.exports = function (KEY, BYTES, wrapper, CLAMPED) {
    CLAMPED = !!CLAMPED;
    var NAME = KEY + (CLAMPED ? 'Clamped' : '') + 'Array';
    var GETTER = 'get' + KEY;
    var SETTER = 'set' + KEY;
    var TypedArray = global[NAME];
    var Base = TypedArray || {};
    var TAC = TypedArray && getPrototypeOf(TypedArray);
    var FORCED = !TypedArray || !$typed.ABV;
    var O = {};
    var TypedArrayPrototype = TypedArray && TypedArray[PROTOTYPE];
    var getter = function (that, index) {
      var data = that._d;
      return data.v[GETTER](index * BYTES + data.o, LITTLE_ENDIAN);
    };
    var setter = function (that, index, value) {
      var data = that._d;
      if (CLAMPED) value = (value = Math.round(value)) < 0 ? 0 : value > 0xff ? 0xff : value & 0xff;
      data.v[SETTER](index * BYTES + data.o, value, LITTLE_ENDIAN);
    };
    var addElement = function (that, index) {
      dP(that, index, {
        get: function () {
          return getter(this, index);
        },
        set: function (value) {
          return setter(this, index, value);
        },
        enumerable: true
      });
    };
    if (FORCED) {
      TypedArray = wrapper(function (that, data, $offset, $length) {
        anInstance(that, TypedArray, NAME, '_d');
        var index = 0;
        var offset = 0;
        var buffer, byteLength, length, klass;
        if (!isObject(data)) {
          length = toIndex(data);
          byteLength = length * BYTES;
          buffer = new $ArrayBuffer(byteLength);
        } else if (data instanceof $ArrayBuffer || (klass = classof(data)) == ARRAY_BUFFER || klass == SHARED_BUFFER) {
          buffer = data;
          offset = toOffset($offset, BYTES);
          var $len = data.byteLength;
          if ($length === undefined) {
            if ($len % BYTES) throw RangeError(WRONG_LENGTH);
            byteLength = $len - offset;
            if (byteLength < 0) throw RangeError(WRONG_LENGTH);
          } else {
            byteLength = toLength($length) * BYTES;
            if (byteLength + offset > $len) throw RangeError(WRONG_LENGTH);
          }
          length = byteLength / BYTES;
        } else if (TYPED_ARRAY in data) {
          return fromList(TypedArray, data);
        } else {
          return $from.call(TypedArray, data);
        }
        hide(that, '_d', {
          b: buffer,
          o: offset,
          l: byteLength,
          e: length,
          v: new $DataView(buffer)
        });
        while (index < length) addElement(that, index++);
      });
      TypedArrayPrototype = TypedArray[PROTOTYPE] = create($TypedArrayPrototype$);
      hide(TypedArrayPrototype, 'constructor', TypedArray);
    } else if (!fails(function () {
      TypedArray(1);
    }) || !fails(function () {
      new TypedArray(-1); // eslint-disable-line no-new
    }) || !$iterDetect(function (iter) {
      new TypedArray(); // eslint-disable-line no-new
      new TypedArray(null); // eslint-disable-line no-new
      new TypedArray(1.5); // eslint-disable-line no-new
      new TypedArray(iter); // eslint-disable-line no-new
    }, true)) {
      TypedArray = wrapper(function (that, data, $offset, $length) {
        anInstance(that, TypedArray, NAME);
        var klass;
        // `ws` module bug, temporarily remove validation length for Uint8Array
        // https://github.com/websockets/ws/pull/645
        if (!isObject(data)) return new Base(toIndex(data));
        if (data instanceof $ArrayBuffer || (klass = classof(data)) == ARRAY_BUFFER || klass == SHARED_BUFFER) {
          return $length !== undefined
            ? new Base(data, toOffset($offset, BYTES), $length)
            : $offset !== undefined
              ? new Base(data, toOffset($offset, BYTES))
              : new Base(data);
        }
        if (TYPED_ARRAY in data) return fromList(TypedArray, data);
        return $from.call(TypedArray, data);
      });
      arrayForEach(TAC !== Function.prototype ? gOPN(Base).concat(gOPN(TAC)) : gOPN(Base), function (key) {
        if (!(key in TypedArray)) hide(TypedArray, key, Base[key]);
      });
      TypedArray[PROTOTYPE] = TypedArrayPrototype;
      if (!LIBRARY) TypedArrayPrototype.constructor = TypedArray;
    }
    var $nativeIterator = TypedArrayPrototype[ITERATOR];
    var CORRECT_ITER_NAME = !!$nativeIterator
      && ($nativeIterator.name == 'values' || $nativeIterator.name == undefined);
    var $iterator = $iterators.values;
    hide(TypedArray, TYPED_CONSTRUCTOR, true);
    hide(TypedArrayPrototype, TYPED_ARRAY, NAME);
    hide(TypedArrayPrototype, VIEW, true);
    hide(TypedArrayPrototype, DEF_CONSTRUCTOR, TypedArray);

    if (CLAMPED ? new TypedArray(1)[TAG] != NAME : !(TAG in TypedArrayPrototype)) {
      dP(TypedArrayPrototype, TAG, {
        get: function () { return NAME; }
      });
    }

    O[NAME] = TypedArray;

    $export($export.G + $export.W + $export.F * (TypedArray != Base), O);

    $export($export.S, NAME, {
      BYTES_PER_ELEMENT: BYTES
    });

    $export($export.S + $export.F * fails(function () { Base.of.call(TypedArray, 1); }), NAME, {
      from: $from,
      of: $of
    });

    if (!(BYTES_PER_ELEMENT in TypedArrayPrototype)) hide(TypedArrayPrototype, BYTES_PER_ELEMENT, BYTES);

    $export($export.P, NAME, proto);

    setSpecies(NAME);

    $export($export.P + $export.F * FORCED_SET, NAME, { set: $set });

    $export($export.P + $export.F * !CORRECT_ITER_NAME, NAME, $iterators);

    if (!LIBRARY && TypedArrayPrototype.toString != arrayToString) TypedArrayPrototype.toString = arrayToString;

    $export($export.P + $export.F * fails(function () {
      new TypedArray(1).slice();
    }), NAME, { slice: $slice });

    $export($export.P + $export.F * (fails(function () {
      return [1, 2].toLocaleString() != new TypedArray([1, 2]).toLocaleString();
    }) || !fails(function () {
      TypedArrayPrototype.toLocaleString.call([1, 2]);
    })), NAME, { toLocaleString: $toLocaleString });

    Iterators[NAME] = CORRECT_ITER_NAME ? $nativeIterator : $iterator;
    if (!LIBRARY && !CORRECT_ITER_NAME) hide(TypedArrayPrototype, ITERATOR, $iterator);
  };
} else module.exports = function () { /* empty */ };


/***/ }),
/* 39 */
/***/ (function(module, exports, __webpack_require__) {

var Map = __webpack_require__(179);
var $export = __webpack_require__(0);
var shared = __webpack_require__(68)('metadata');
var store = shared.store || (shared.store = new (__webpack_require__(182))());

var getOrCreateMetadataMap = function (target, targetKey, create) {
  var targetMetadata = store.get(target);
  if (!targetMetadata) {
    if (!create) return undefined;
    store.set(target, targetMetadata = new Map());
  }
  var keyMetadata = targetMetadata.get(targetKey);
  if (!keyMetadata) {
    if (!create) return undefined;
    targetMetadata.set(targetKey, keyMetadata = new Map());
  } return keyMetadata;
};
var ordinaryHasOwnMetadata = function (MetadataKey, O, P) {
  var metadataMap = getOrCreateMetadataMap(O, P, false);
  return metadataMap === undefined ? false : metadataMap.has(MetadataKey);
};
var ordinaryGetOwnMetadata = function (MetadataKey, O, P) {
  var metadataMap = getOrCreateMetadataMap(O, P, false);
  return metadataMap === undefined ? undefined : metadataMap.get(MetadataKey);
};
var ordinaryDefineOwnMetadata = function (MetadataKey, MetadataValue, O, P) {
  getOrCreateMetadataMap(O, P, true).set(MetadataKey, MetadataValue);
};
var ordinaryOwnMetadataKeys = function (target, targetKey) {
  var metadataMap = getOrCreateMetadataMap(target, targetKey, false);
  var keys = [];
  if (metadataMap) metadataMap.forEach(function (_, key) { keys.push(key); });
  return keys;
};
var toMetaKey = function (it) {
  return it === undefined || typeof it == 'symbol' ? it : String(it);
};
var exp = function (O) {
  $export($export.S, 'Reflect', O);
};

module.exports = {
  store: store,
  map: getOrCreateMetadataMap,
  has: ordinaryHasOwnMetadata,
  get: ordinaryGetOwnMetadata,
  set: ordinaryDefineOwnMetadata,
  keys: ordinaryOwnMetadataKeys,
  key: toMetaKey,
  exp: exp
};


/***/ }),
/* 40 */
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(35);
var IE8_DOM_DEFINE = __webpack_require__(194);
var toPrimitive = __webpack_require__(142);
var dP = Object.defineProperty;

exports.f = __webpack_require__(45) ? Object.defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPrimitive(P, true);
  anObject(Attributes);
  if (IE8_DOM_DEFINE) try {
    return dP(O, P, Attributes);
  } catch (e) { /* empty */ }
  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};


/***/ }),
/* 41 */
/***/ (function(module, exports) {

module.exports = false;


/***/ }),
/* 42 */
/***/ (function(module, exports, __webpack_require__) {

var META = __webpack_require__(47)('meta');
var isObject = __webpack_require__(4);
var has = __webpack_require__(19);
var setDesc = __webpack_require__(9).f;
var id = 0;
var isExtensible = Object.isExtensible || function () {
  return true;
};
var FREEZE = !__webpack_require__(3)(function () {
  return isExtensible(Object.preventExtensions({}));
});
var setMeta = function (it) {
  setDesc(it, META, { value: {
    i: 'O' + ++id, // object ID
    w: {}          // weak collections IDs
  } });
};
var fastKey = function (it, create) {
  // return primitive with prefix
  if (!isObject(it)) return typeof it == 'symbol' ? it : (typeof it == 'string' ? 'S' : 'P') + it;
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return 'F';
    // not necessary to add metadata
    if (!create) return 'E';
    // add missing metadata
    setMeta(it);
  // return object ID
  } return it[META].i;
};
var getWeak = function (it, create) {
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return true;
    // not necessary to add metadata
    if (!create) return false;
    // add missing metadata
    setMeta(it);
  // return hash weak collections IDs
  } return it[META].w;
};
// add metadata on freeze-family methods calling
var onFreeze = function (it) {
  if (FREEZE && meta.NEED && isExtensible(it) && !has(it, META)) setMeta(it);
  return it;
};
var meta = module.exports = {
  KEY: META,
  NEED: false,
  fastKey: fastKey,
  getWeak: getWeak,
  onFreeze: onFreeze
};


/***/ }),
/* 43 */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.3.31 Array.prototype[@@unscopables]
var UNSCOPABLES = __webpack_require__(5)('unscopables');
var ArrayProto = Array.prototype;
if (ArrayProto[UNSCOPABLES] == undefined) __webpack_require__(15)(ArrayProto, UNSCOPABLES, {});
module.exports = function (key) {
  ArrayProto[UNSCOPABLES][key] = true;
};


/***/ }),
/* 44 */
/***/ (function(module, exports) {

module.exports = function (it) {
  return typeof it === 'object' ? it !== null : typeof it === 'function';
};


/***/ }),
/* 45 */
/***/ (function(module, exports, __webpack_require__) {

// Thank's IE8 for his funny defineProperty
module.exports = !__webpack_require__(65)(function () {
  return Object.defineProperty({}, 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),
/* 46 */
/***/ (function(module, exports) {

module.exports = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};


/***/ }),
/* 47 */
/***/ (function(module, exports) {

var id = 0;
var px = Math.random();
module.exports = function (key) {
  return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
};


/***/ }),
/* 48 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 / 15.2.3.14 Object.keys(O)
var $keys = __webpack_require__(158);
var enumBugKeys = __webpack_require__(111);

module.exports = Object.keys || function keys(O) {
  return $keys(O, enumBugKeys);
};


/***/ }),
/* 49 */
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(27);
var max = Math.max;
var min = Math.min;
module.exports = function (index, length) {
  index = toInteger(index);
  return index < 0 ? max(index + length, 0) : min(index, length);
};


/***/ }),
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
var anObject = __webpack_require__(1);
var dPs = __webpack_require__(159);
var enumBugKeys = __webpack_require__(111);
var IE_PROTO = __webpack_require__(110)('IE_PROTO');
var Empty = function () { /* empty */ };
var PROTOTYPE = 'prototype';

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var createDict = function () {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = __webpack_require__(108)('iframe');
  var i = enumBugKeys.length;
  var lt = '<';
  var gt = '>';
  var iframeDocument;
  iframe.style.display = 'none';
  __webpack_require__(112).appendChild(iframe);
  iframe.src = 'javascript:'; // eslint-disable-line no-script-url
  // createDict = iframe.contentWindow.Object;
  // html.removeChild(iframe);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
  iframeDocument.close();
  createDict = iframeDocument.F;
  while (i--) delete createDict[PROTOTYPE][enumBugKeys[i]];
  return createDict();
};

module.exports = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    Empty[PROTOTYPE] = anObject(O);
    result = new Empty();
    Empty[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = createDict();
  return Properties === undefined ? result : dPs(result, Properties);
};


/***/ }),
/* 51 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.7 / 15.2.3.4 Object.getOwnPropertyNames(O)
var $keys = __webpack_require__(158);
var hiddenKeys = __webpack_require__(111).concat('length', 'prototype');

exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return $keys(O, hiddenKeys);
};


/***/ }),
/* 52 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(2);
var dP = __webpack_require__(9);
var DESCRIPTORS = __webpack_require__(8);
var SPECIES = __webpack_require__(5)('species');

module.exports = function (KEY) {
  var C = global[KEY];
  if (DESCRIPTORS && C && !C[SPECIES]) dP.f(C, SPECIES, {
    configurable: true,
    get: function () { return this; }
  });
};


/***/ }),
/* 53 */
/***/ (function(module, exports) {

module.exports = function (it, Constructor, name, forbiddenField) {
  if (!(it instanceof Constructor) || (forbiddenField !== undefined && forbiddenField in it)) {
    throw TypeError(name + ': incorrect invocation!');
  } return it;
};


/***/ }),
/* 54 */
/***/ (function(module, exports, __webpack_require__) {

var ctx = __webpack_require__(25);
var call = __webpack_require__(171);
var isArrayIter = __webpack_require__(123);
var anObject = __webpack_require__(1);
var toLength = __webpack_require__(6);
var getIterFn = __webpack_require__(125);
var BREAK = {};
var RETURN = {};
var exports = module.exports = function (iterable, entries, fn, that, ITERATOR) {
  var iterFn = ITERATOR ? function () { return iterable; } : getIterFn(iterable);
  var f = ctx(fn, that, entries ? 2 : 1);
  var index = 0;
  var length, step, iterator, result;
  if (typeof iterFn != 'function') throw TypeError(iterable + ' is not iterable!');
  // fast case for arrays with default iterator
  if (isArrayIter(iterFn)) for (length = toLength(iterable.length); length > index; index++) {
    result = entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
    if (result === BREAK || result === RETURN) return result;
  } else for (iterator = iterFn.call(iterable); !(step = iterator.next()).done;) {
    result = call(iterator, f, step.value, entries);
    if (result === BREAK || result === RETURN) return result;
  }
};
exports.BREAK = BREAK;
exports.RETURN = RETURN;


/***/ }),
/* 55 */
/***/ (function(module, exports, __webpack_require__) {

var redefine = __webpack_require__(16);
module.exports = function (target, src, safe) {
  for (var key in src) redefine(target, key, src[key], safe);
  return target;
};


/***/ }),
/* 56 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
module.exports = function (it, TYPE) {
  if (!isObject(it) || it._t !== TYPE) throw TypeError('Incompatible receiver, ' + TYPE + ' required!');
  return it;
};


/***/ }),
/* 57 */
/***/ (function(module, exports) {

var hasOwnProperty = {}.hasOwnProperty;
module.exports = function (it, key) {
  return hasOwnProperty.call(it, key);
};


/***/ }),
/* 58 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(40);
var createDesc = __webpack_require__(77);
module.exports = __webpack_require__(45) ? function (object, key, value) {
  return dP.f(object, key, createDesc(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};


/***/ }),
/* 59 */
/***/ (function(module, exports, __webpack_require__) {

// to indexed object, toObject with fallback for non-array-like ES3 strings
var IObject = __webpack_require__(193);
var defined = __webpack_require__(135);
module.exports = function (it) {
  return IObject(defined(it));
};


/***/ }),
/* 60 */
/***/ (function(module, exports, __webpack_require__) {

var def = __webpack_require__(9).f;
var has = __webpack_require__(19);
var TAG = __webpack_require__(5)('toStringTag');

module.exports = function (it, tag, stat) {
  if (it && !has(it = stat ? it : it.prototype, TAG)) def(it, TAG, { configurable: true, value: tag });
};


/***/ }),
/* 61 */
/***/ (function(module, exports, __webpack_require__) {

// getting tag from 19.1.3.6 Object.prototype.toString()
var cof = __webpack_require__(26);
var TAG = __webpack_require__(5)('toStringTag');
// ES3 wrong here
var ARG = cof(function () { return arguments; }()) == 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function (it, key) {
  try {
    return it[key];
  } catch (e) { /* empty */ }
};

module.exports = function (it) {
  var O, T, B;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
    // @@toStringTag case
    : typeof (T = tryGet(O = Object(it), TAG)) == 'string' ? T
    // builtinTag case
    : ARG ? cof(O)
    // ES3 arguments fallback
    : (B = cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
};


/***/ }),
/* 62 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var defined = __webpack_require__(32);
var fails = __webpack_require__(3);
var spaces = __webpack_require__(114);
var space = '[' + spaces + ']';
var non = '\u200b\u0085';
var ltrim = RegExp('^' + space + space + '*');
var rtrim = RegExp(space + space + '*$');

var exporter = function (KEY, exec, ALIAS) {
  var exp = {};
  var FORCE = fails(function () {
    return !!spaces[KEY]() || non[KEY]() != non;
  });
  var fn = exp[KEY] = FORCE ? exec(trim) : spaces[KEY];
  if (ALIAS) exp[ALIAS] = fn;
  $export($export.P + $export.F * FORCE, 'String', exp);
};

// 1 -> String#trimLeft
// 2 -> String#trimRight
// 3 -> String#trim
var trim = exporter.trim = function (string, TYPE) {
  string = String(defined(string));
  if (TYPE & 1) string = string.replace(ltrim, '');
  if (TYPE & 2) string = string.replace(rtrim, '');
  return string;
};

module.exports = exporter;


/***/ }),
/* 63 */
/***/ (function(module, exports) {

module.exports = {};


/***/ }),
/* 64 */
/***/ (function(module, exports, __webpack_require__) {

// optional / simple context binding
var aFunction = __webpack_require__(97);
module.exports = function (fn, that, length) {
  aFunction(fn);
  if (that === undefined) return fn;
  switch (length) {
    case 1: return function (a) {
      return fn.call(that, a);
    };
    case 2: return function (a, b) {
      return fn.call(that, a, b);
    };
    case 3: return function (a, b, c) {
      return fn.call(that, a, b, c);
    };
  }
  return function (/* ...args */) {
    return fn.apply(that, arguments);
  };
};


/***/ }),
/* 65 */
/***/ (function(module, exports) {

module.exports = function (exec) {
  try {
    return !!exec();
  } catch (e) {
    return true;
  }
};


/***/ }),
/* 66 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(466), __esModule: true };

/***/ }),
/* 67 */
/***/ (function(module, exports) {

module.exports = {};


/***/ }),
/* 68 */
/***/ (function(module, exports, __webpack_require__) {

var core = __webpack_require__(24);
var global = __webpack_require__(2);
var SHARED = '__core-js_shared__';
var store = global[SHARED] || (global[SHARED] = {});

(module.exports = function (key, value) {
  return store[key] || (store[key] = value !== undefined ? value : {});
})('versions', []).push({
  version: core.version,
  mode: __webpack_require__(41) ? 'pure' : 'global',
  copyright: '© 2019 Denis Pushkarev (zloirock.ru)'
});


/***/ }),
/* 69 */
/***/ (function(module, exports, __webpack_require__) {

// fallback for non-array-like ES3 and non-enumerable old V8 strings
var cof = __webpack_require__(26);
// eslint-disable-next-line no-prototype-builtins
module.exports = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
  return cof(it) == 'String' ? it.split('') : Object(it);
};


/***/ }),
/* 70 */
/***/ (function(module, exports) {

exports.f = {}.propertyIsEnumerable;


/***/ }),
/* 71 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 21.2.5.3 get RegExp.prototype.flags
var anObject = __webpack_require__(1);
module.exports = function () {
  var that = anObject(this);
  var result = '';
  if (that.global) result += 'g';
  if (that.ignoreCase) result += 'i';
  if (that.multiline) result += 'm';
  if (that.unicode) result += 'u';
  if (that.sticky) result += 'y';
  return result;
};


/***/ }),
/* 72 */
/***/ (function(module, exports, __webpack_require__) {

// 7.3.20 SpeciesConstructor(O, defaultConstructor)
var anObject = __webpack_require__(1);
var aFunction = __webpack_require__(11);
var SPECIES = __webpack_require__(5)('species');
module.exports = function (O, D) {
  var C = anObject(O).constructor;
  var S;
  return C === undefined || (S = anObject(C)[SPECIES]) == undefined ? D : aFunction(S);
};


/***/ }),
/* 73 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.13 ToObject(argument)
var defined = __webpack_require__(135);
module.exports = function (it) {
  return Object(defined(it));
};


/***/ }),
/* 74 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 / 15.2.3.14 Object.keys(O)
var $keys = __webpack_require__(192);
var enumBugKeys = __webpack_require__(140);

module.exports = Object.keys || function keys(O) {
  return $keys(O, enumBugKeys);
};


/***/ }),
/* 75 */
/***/ (function(module, exports) {

var toString = {}.toString;

module.exports = function (it) {
  return toString.call(it).slice(8, -1);
};


/***/ }),
/* 76 */
/***/ (function(module, exports) {

module.exports = true;


/***/ }),
/* 77 */
/***/ (function(module, exports) {

module.exports = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};


/***/ }),
/* 78 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(437), __esModule: true };

/***/ }),
/* 79 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass2 = __webpack_require__(29);

var _createClass3 = _interopRequireDefault(_createClass2);

var _defineProperty2 = __webpack_require__(616);

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _getPrototypeOf = __webpack_require__(78);

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__(23);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _possibleConstructorReturn2 = __webpack_require__(98);

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__(101);

var _inherits3 = _interopRequireDefault(_inherits2);

var _from = __webpack_require__(102);

var _from2 = _interopRequireDefault(_from);

var _keys = __webpack_require__(37);

var _keys2 = _interopRequireDefault(_keys);

var _typeof2 = __webpack_require__(13);

var _typeof3 = _interopRequireDefault(_typeof2);

var _stringify = __webpack_require__(36);

var _stringify2 = _interopRequireDefault(_stringify);

var _APIs;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function surroundByTryCatchFactory(func, funcName) {
  //返回函数e
  return function () {
    try {
      return func.apply(func, arguments);
    } catch (e) {
      if ("[object Error]" === Object.prototype.toString.apply(e)) {
        if ("AppServiceSdkKnownError" == e.type || "ConnectSocketError" == e.type) throw e;
        Reporter.errorReport({
          key: "appServiceSDKScriptError",
          error: e,
          extend: funcName
        });
      }
    }
  };
}

function anyTypeToString(data) {
  //把e转成string并返回一个对象
  var dataType = Object.prototype.toString.call(data).split(" ")[1].split("]")[0];
  if ("Array" == dataType || "Object" == dataType) {
    try {
      data = (0, _stringify2.default)(data);
    } catch (e) {
      e.type = "AppServiceSdkKnownError";
      throw e;
    }
  } else {
    data = "String" == dataType || "Number" == dataType || "Boolean" == dataType ? data.toString() : "Date" == dataType ? data.getTime().toString() : "Undefined" == dataType ? "undefined" : "Null" == dataType ? "null" : "";
  }
  return {
    data: data,
    dataType: dataType
  };
}

function stringToAnyType(data, type) {
  //把e解码回来，和前面a相对应

  return data = "String" == type ? data : "Array" == type || "Object" == type ? JSON.parse(data) : "Number" == type ? parseFloat(data) : "Boolean" == type ? "true" == data : "Date" == type ? new Date(parseInt(data)) : "Undefined" == type ? void 0 : "Null" == type ? null : "";
}

function getDataType(data) {
  //get data type
  return Object.prototype.toString.call(data).split(" ")[1].split("]")[0];
}

function isObject(e) {
  return "Object" === getDataType(e);
}

function paramCheck(params, paramTpl) {
  //比较e\t
  var result,
      name = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "parameter",
      tplTpye = getDataType(paramTpl),
      pType = getDataType(params);
  if (pType != tplTpye) return name + " should be " + tplTpye + " instead of " + pType + ";";
  switch (result = "", tplTpye) {
    case "Object":
      for (var i in paramTpl) {
        result += paramCheck(params[i], paramTpl[i], name + "." + i);
      }break;
    case "Array":
      if (params.length < paramTpl.length) return name + " should have at least " + paramTpl.length + " item;";
      for (var a = 0; a < paramTpl.length; ++a) {
        result += paramCheck(params[a], paramTpl[a], name + "[" + a + "]");
      }}
  return result;
}

function getRealRoute(pathname, url) {
  var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
  if (n && (url = addHTMLSuffix(url)), 0 === url.indexOf("/")) return url.substr(1);
  if (0 === url.indexOf("./")) return getRealRoute(pathname, url.substr(2), !1);
  var index,
      urlArrLength,
      urlArr = url.split("/");
  for (index = 0, urlArrLength = urlArr.length; index < urlArrLength && ".." === urlArr[index]; index++) {}
  urlArr.splice(0, index);
  var newUrl = urlArr.join("/"),
      pathArr = pathname.length > 0 ? pathname.split("/") : [];
  pathArr.splice(pathArr.length - index - 1, index + 1);
  var newPathArr = pathArr.concat(urlArr);
  return newPathArr.join("/");
}

function getPlatform() {
  //return platform
  var ua = window.navigator.userAgent.toLowerCase();
  return (/devtools/.test(ua) ? "devtools" : /(iphone|ipad)/.test(ua) ? "ios" : /android/.test(ua) ? "android" : void 0
  );
}

function urlEncodeFormData(data) {
  //把对象生成queryString
  var needEncode = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
  if ("object" !== (typeof data === "undefined" ? "undefined" : (0, _typeof3.default)(data))) return data;
  var tmpArr = [];
  for (var o in data) {
    if (data.hasOwnProperty(o)) {
      if (needEncode) {
        try {
          tmpArr.push(encodeURIComponent(o) + "=" + encodeURIComponent(data[o]));
        } catch (t) {
          tmpArr.push(o + "=" + data[o]);
        }
      } else tmpArr.push(o + "=" + data[o]);
    }
  }return tmpArr.join("&");
}

function addQueryStringToUrl(originalUrl, newParams) {
  //生成url t:param obj
  if ("string" == typeof originalUrl && "object" === (typeof newParams === "undefined" ? "undefined" : (0, _typeof3.default)(newParams)) && (0, _keys2.default)(newParams).length > 0) {
    var urlComponents = originalUrl.split("?"),
        host = urlComponents[0],
        oldParams = (urlComponents[1] || "").split("&").reduce(function (res, cur) {
      if ("string" == typeof cur && cur.length > 0) {
        var curArr = cur.split("="),
            key = curArr[0],
            value = curArr[1];
        res[key] = value;
      }
      return res;
    }, {}),
        refinedNewParams = (0, _keys2.default)(newParams).reduce(function (res, cur) {
      "object" === (0, _typeof3.default)(newParams[cur]) ? res[encodeURIComponent(cur)] = encodeURIComponent((0, _stringify2.default)(newParams[cur])) : res[encodeURIComponent(cur)] = encodeURIComponent(newParams[cur]);
      return res;
    }, {});
    return host + "?" + urlEncodeFormData(assign(oldParams, refinedNewParams));
  }
  return originalUrl;
}

function validateUrl(url) {
  return (/^(http|https):\/\/.*/i.test(url)
  );
}

function assign() {
  //endext 对象合并
  for (var argLeng = arguments.length, args = Array(argLeng), n = 0; n < argLeng; n++) {
    args[n] = arguments[n];
  }
  return args.reduce(function (res, cur) {
    for (var n in cur) {
      res[n] = cur[n];
    }
    return res;
  }, {});
}

function encodeUrlQuery(url) {
  //把url中的参数encode
  if ("string" == typeof url) {
    var urlArr = url.split("?"),
        urlPath = urlArr[0],
        queryParams = (urlArr[1] || "").split("&").reduce(function (res, cur) {
      if ("string" == typeof cur && cur.length > 0) {
        var curArr = cur.split("="),
            key = curArr[0],
            value = curArr[1];
        res[key] = value;
      }
      return res;
    }, {}),
        urlQueryArr = [];
    for (var i in queryParams) {
      queryParams.hasOwnProperty(i) && urlQueryArr.push(i + "=" + encodeURIComponent(queryParams[i]));
    }
    return urlQueryArr.length > 0 ? urlPath + "?" + urlQueryArr.join("&") : url;
  }
  return url;
}

function addHTMLSuffix(url) {
  //给url加上。html的扩展名
  if ("string" != typeof url) throw new A("wx.redirectTo: invalid url:" + url);
  var urlArr = url.split("?");
  urlArr[0] += ".html";
  return "undefined" != typeof urlArr[1] ? urlArr[0] + "?" + urlArr[1] : urlArr[0];
}

function extend(target, obj) {
  //t合并到e对象
  for (var n in obj) {
    target[n] = obj[n];
  }return target;
}

function arrayBufferToBase64(buffer) {
  for (var res = "", arr = new Uint8Array(buffer), arrLeng = arr.byteLength, r = 0; r < arrLeng; r++) {
    res += String.fromCharCode(arr[r]);
  }
  return btoa(res);
}

function base64ToArrayBuffer(str) {
  for (var atobStr = atob(str), leng = atobStr.length, arr = new Uint8Array(leng), r = 0; r < leng; r++) {
    arr[r] = atobStr.charCodeAt(r);
  }return arr.buffer;
}

function blobToArrayBuffer(blobStr, callback) {
  //readAsArrayBuffer t:callback
  var fileReader = new FileReader();
  fileReader.onload = function () {
    callback(this.result);
  };
  fileReader.readAsArrayBuffer(blobStr);
}

function convertObjectValueToString(obj) {
  //把对象元素都转成字符串
  return (0, _keys2.default)(obj).reduce(function (res, cur) {
    "string" == typeof obj[cur] ? res[cur] = obj[cur] : "number" == typeof obj[cur] ? res[cur] = obj[cur] + "" : res[cur] = Object.prototype.toString.apply(obj[cur]);
    return res;
  }, {});
}

function renameProperty(obj, oldName, newName) {
  isObject(obj) !== !1 && oldName != newName && obj.hasOwnProperty(oldName) && (obj[newName] = obj[oldName], delete obj[oldName]);
}

function toArray(arg) {
  // 把e转成array
  if (Array.isArray(arg)) {
    for (var t = 0, n = Array(arg.length); t < arg.length; t++) {
      n[t] = arg[t];
    }return n;
  }
  return (0, _from2.default)(arg);
}

var words = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    btoa = btoa || function (str) {
  for (var curPosFlag, curCodeValue, text = String(str), res = "", i = 0, wordTpl = words; text.charAt(0 | i) || (wordTpl = "=", i % 1); res += wordTpl.charAt(63 & curPosFlag >> 8 - i % 1 * 8)) {
    curCodeValue = text.charCodeAt(i += .75);
    if (curCodeValue > 255) throw new Error('"btoa" failed');
    curPosFlag = curPosFlag << 8 | curCodeValue;
  }
  return res;
},
    atob = atob || function (str) {
  var text = String(str).replace(/=+$/, ""),
      res = "";
  if (text.length % 4 === 1) throw new Error('"atob" failed');
  for (var curFlage, curValue, i = 0, a = 0; curValue = text.charAt(a++); ~curValue && (curFlage = i % 4 ? 64 * curFlage + curValue : curValue, i++ % 4) ? res += String.fromCharCode(255 & curFlage >> (-2 * i & 6)) : 0) {
    curValue = words.indexOf(curValue);
  }return res;
};

var AppServiceSdkKnownError = function (_Error) {
  (0, _inherits3.default)(AppServiceSdkKnownError, _Error);

  function AppServiceSdkKnownError(e) {
    (0, _classCallCheck3.default)(this, AppServiceSdkKnownError);

    var _this2 = (0, _possibleConstructorReturn3.default)(this, (AppServiceSdkKnownError.__proto__ || (0, _getPrototypeOf2.default)(AppServiceSdkKnownError)).call(this, "APP-SERVICE-SDK:" + e));

    _this2.type = "AppServiceSdkKnownError";
    return _this2;
  }

  return AppServiceSdkKnownError;
}(Error);

var Components = {
  //components
  audio: {
    "1.0.0": ["id", "src", "loop", "controls", "poster", "name", "author", "binderror", "bindplay", "bindpause", "bindtimeupdate", "bindended"]
  },
  button: {
    "1.0.0": [{
      size: ["default", "mini"]
    }, {
      type: ["primary", "default", "warn"]
    }, "plain", "disabled", "loading", {
      "form-type": ["submit", "reset"]
    }, "hover-class", "hover-start-time", "hover-stay-time"],
    "1.1.0": [{
      "open-type": ["contact"]
    }],
    "1.2.0": [{
      "open-type": ["share"]
    }],
    "1.4.0": ["session-from"],
    "1.3.0": [{
      "open-type": ["getUserInfo"]
    }]
  },
  canvas: {
    "1.0.0": ["canvas-id", "disable-scroll", "bindtouchstart", "bindtouchmove", "bindtouchend", "bindtouchcancel", "bindlongtap", "binderror"]
  },
  "checkbox-group": {
    "1.0.0": ["bindchange"]
  },
  checkbox: {
    "1.0.0": ["value", "disabled", "checked", "color"]
  },
  "contact-button": {
    "1.0.0": ["size", {
      type: ["default-dark", "default-light"]
    }, "session-from"]
  },
  "cover-view": {
    "1.4.0": []
  },
  "cover-image": {
    "1.4.0": ["src"]
  },
  form: {
    "1.0.0": ["report-submit", "bindsubmit", "bindreset"],
    "1.2.0": ["bindautofill"]
  },
  icon: {
    "1.0.0": [{
      type: ["success", "success_no_circle", "info", "warn", "waiting", "cancel", "download", "search", "clear"]
    }, "size", "color"]
  },
  image: {
    "1.0.0": ["src", {
      mode: ["scaleToFill", "aspectFit", "aspectFill", "widthFix", "top", "bottom", "center", "left", "right", "top left", "top right", "bottom left", "bottom right"]
    }, "binderror", "bindload"]
  },
  input: {
    "1.0.0": ["value", {
      type: ["text", "number", "idcard", "digit"]
    }, "password", "placeholder", "placeholder-style", "placeholder-class", "disabled", "maxlength", "cursor-spacing", "auto-focus", "focus", "bindinput", "bindfocus", "bindblur", "bindconfirm"],
    "1.1.0": [{
      "confirm-type": ["send", "search", "next", "go", "done"]
    }, "confirm-hold"],
    "1.2.0": ["auto-fill"]
  },
  label: {
    "1.0.0": ["for"]
  },
  map: {
    "1.0.0": ["longitude", "latitude", "scale", {
      markers: ["id", "latitude", "longitude", "title", "iconPath", "rotate", "alpha", "width", "height"]
    }, "covers", {
      polyline: ["points", "color", "width", "dottedLine"]
    }, {
      circles: ["latitude", "longitude", "color", "fillColor", "radius", "strokeWidth"]
    }, {
      controls: ["id", "position", "iconPath", "clickable"]
    }, "include-points", "show-location", "bindmarkertap", "bindcontroltap", "bindregionchange", "bindtap"],
    "1.2.0": [{
      markers: ["callout", "label", "anchor"]
    }, {
      polyline: ["arrowLine", "borderColor", "borderWidth"]
    }, "bindcallouttap"]
  },
  modal: {
    "1.0.0": []
  },
  "movable-area": {
    "1.2.0": []
  },
  "movable-view": {
    "1.2.0": ["direction", "inertia", "out-of-bounds", "x", "y", "damping", "friction"]
  },
  navigator: {
    "1.0.0": ["url", {
      "open-type": ["navigate", "redirect", "switchTab"]
    }, "delta", "hover-class", "hover-start-time", "hover-stay-time"],
    "1.1.0": [{
      "open-type": ["reLaunch", "navigateBack"]
    }]
  },
  "open-data": {
    "1.4.0": [{
      type: ["groupName"]
    }, "open-gid"]
  },
  "picker-view": {
    "1.0.0": ["value", "indicator-style", "bindchange"],
    "1.1.0": ["indicator-class"]
  },
  "picker-view-column": {
    "1.0.0": []
  },
  picker: {
    "1.0.0": ["range", "range-key", "value", "bindchange", "disabled", "start", "end", {
      fields: ["year", "month", "day"]
    }, {
      mode: ["selector", "date", "time"]
    }],
    "1.2.0": ["auto-fill"],
    "1.4.0": ["bindcolumnchange", {
      mode: ["multiSelector", "region"]
    }]
  },
  progress: {
    "1.0.0": ["percent", "show-info", "stroke-width", "color", "activeColor", "backgroundColor", "active"]
  },
  "radio-group": {
    "1.0.0": ["bindchange"]
  },
  radio: {
    "1.0.0": ["value", "checked", "disabled", "color"]
  },
  "rich-text": {
    "1.4.0": [{
      nodes: ["name", "attrs", "children"]
    }]
  },
  "scroll-view": {
    "1.0.0": ["scroll-x", "scroll-y", "upper-threshold", "lower-threshold", "scroll-top", "scroll-left", "scroll-into-view", "scroll-with-animation", "enable-back-to-top", "bindscrolltoupper", "bindscrolltolower", "bindscroll"]
  },
  slider: {
    "1.0.0": ["min", "max", "step", "disabled", "value", "color", "selected-color", "activeColor", "backgroundColor", "show-value", "bindchange"]
  },
  swiper: {
    "1.0.0": ["indicator-dots", "autoplay", "current", "interval", "duration", "circular", "vertical", "bindchange"],
    "1.1.0": ["indicator-color", "indicator-active-color"]
  },
  "swiper-item": {
    "1.0.0": []
  },
  "switch": {
    "1.0.0": ["checked", {
      type: ["switch", "checkbox"]
    }, "bindchange", "color"]
  },
  text: {
    "1.0.0": [],
    "1.1.0": ["selectable"],
    "1.4.0": [{
      space: ["ensp", "emsp", "nbsp"]
    }, "decode"]
  },
  textarea: {
    "1.0.0": ["value", "placeholder", "placeholder-style", "placeholder-class", "disabled", "maxlength", "auto-focus", "focus", "auto-height", "fixed", "cursor-spacing", "bindfocus", "bindblur", "bindlinechange", "bindinput", "bindconfirm"],
    "1.2.0": ["auto-fill"]
  },
  video: {
    "1.0.0": ["src", "controls", "danmu-list", "danmu-btn", "enable-danmu", "autoplay", "bindplay", "bindpause", "bindended", "bindtimeupdate", "objectFit", "poster"],
    "1.1.0": ["duration"],
    "1.4.0": ["loop", "muted", "bindfullscreenchange"]
  },
  view: {
    "1.0.0": ["hover-class", "hover-start-time", "hover-stay-time"]
  },
  "web-view": {
    "1.0.0": ["src", "bindmessage"]
  }
};
var APIs = (_APIs = {
  //APIS
  onAccelerometerChange: {
    "1.0.0": [{
      callback: ["x", "y", "z"]
    }]
  },
  startAccelerometer: {
    "1.1.0": []
  },
  stopAccelerometer: {
    "1.1.0": []
  },
  chooseAddress: {
    "1.1.0": [{
      success: ["userName", "postalCode", "provinceName", "cityName", "countyName", "detailInfo", "nationalCode", "telNumber"]
    }]
  },
  createAnimation: {
    "1.0.0": [{
      object: ["duration", {
        timingFunction: ["linear", "ease", "ease-in", "ease-in-out", "ease-out", "step-start", "step-end"]
      }, "delay", "transformOrigin"]
    }]
  },
  createAudioContext: {
    "1.0.0": []
  },
  canIUse: {
    "1.0.0": []
  },
  login: {
    "1.0.0": [{
      success: ["code"]
    }]
  },
  checkSession: {
    "1.0.0": []
  },
  createMapContext: {
    "1.0.0": []
  },
  requestPayment: {
    "1.0.0": [{
      object: ["timeStamp", "nonceStr", "package", "signType", "paySign"]
    }]
  },
  showToast: {
    "1.0.0": [{
      object: ["title", "icon", "duration", "mask"]
    }],
    "1.1.0": [{
      object: ["image"]
    }]
  },
  showLoading: {
    "1.1.0": [{
      object: ["title", "mask"]
    }]
  },
  hideToast: {
    "1.0.0": []
  },
  hideLoading: {
    "1.1.0": []
  },
  showModal: {
    "1.0.0": [{
      object: ["title", "content", "showCancel", "cancelText", "cancelColor", "confirmText", "confirmColor"]
    }, {
      success: ["confirm"]
    }],
    "1.1.0": [{
      success: ["cancel"]
    }]
  },
  showActionSheet: {
    "1.0.0": [{
      object: ["itemList", "itemColor"]
    }, {
      success: ["tapIndex"]
    }]
  },
  arrayBufferToBase64: {
    "1.1.0": []
  },
  base64ToArrayBuffer: {
    "1.1.0": []
  },
  createVideoContext: {
    "1.0.0": []
  },
  authorize: {
    "1.2.0": [{
      object: ["scope"]
    }]
  },
  openBluetoothAdapter: {
    "1.1.0": []
  },
  closeBluetoothAdapter: {
    "1.1.0": []
  },
  getBluetoothAdapterState: {
    "1.1.0": [{
      success: ["discovering", "available"]
    }]
  },
  onBluetoothAdapterStateChange: {
    "1.1.0": [{
      callback: ["available", "discovering"]
    }]
  },
  startBluetoothDevicesDiscovery: {
    "1.1.0": [{
      object: ["services", "allowDuplicatesKey", "interval"]
    }, {
      success: ["isDiscovering"]
    }]
  },
  stopBluetoothDevicesDiscovery: {
    "1.1.0": []
  },
  getBluetoothDevices: {
    "1.1.0": [{
      success: ["devices"]
    }]
  },
  onBluetoothDeviceFound: {
    "1.1.0": [{
      callback: ["devices"]
    }]
  },
  getConnectedBluetoothDevices: {
    "1.1.0": [{
      object: ["services"]
    }, {
      success: ["devices"]
    }]
  },
  createBLEConnection: {
    "1.1.0": [{
      object: ["deviceId"]
    }]
  },
  closeBLEConnection: {
    "1.1.0": [{
      object: ["deviceId"]
    }]
  },
  getBLEDeviceServices: {
    "1.1.0": [{
      object: ["deviceId"]
    }, {
      success: ["services"]
    }]
  },
  getBLEDeviceCharacteristics: {
    "1.1.0": [{
      object: ["deviceId", "serviceId"]
    }, {
      success: ["characteristics"]
    }]
  },
  readBLECharacteristicValue: {
    "1.1.0": [{
      object: ["deviceId", "serviceId", "characteristicId"]
    }, {
      success: ["characteristic"]
    }]
  },
  writeBLECharacteristicValue: {
    "1.1.0": [{
      object: ["deviceId", "serviceId", "characteristicId", "value"]
    }]
  },
  notifyBLECharacteristicValueChange: {
    "1.1.1": [{
      object: ["deviceId", "serviceId", "characteristicId", "state"]
    }]
  },
  onBLEConnectionStateChange: {
    "1.1.1": [{
      callback: ["deviceId", "connected"]
    }]
  },
  onBLECharacteristicValueChange: {
    "1.1.0": [{
      callback: ["deviceId", "serviceId", "characteristicId", "value"]
    }]
  },
  captureScreen: {
    "1.4.0": [{
      success: ["tempFilePath"]
    }]
  },
  addCard: {
    "1.1.0": [{
      object: ["cardList"]
    }, {
      success: ["cardList"]
    }]
  },
  openCard: {
    "1.1.0": [{
      object: ["cardList"]
    }]
  },
  setClipboardData: {
    "1.1.0": [{
      object: ["data"]
    }]
  },
  getClipboardData: {
    "1.1.0": [{
      success: ["data"]
    }]
  },
  onCompassChange: {
    "1.0.0": [{
      callback: ["direction"]
    }]
  },
  startCompass: {
    "1.1.0": []
  },
  stopCompass: {
    "1.1.0": []
  },
  setStorage: {
    "1.0.0": [{
      object: ["key", "data"]
    }]
  },
  getStorage: {
    "1.0.0": [{
      object: ["key"]
    }, {
      success: ["data"]
    }]
  },
  getStorageSync: {
    "1.0.0": []
  },
  getStorageInfo: {
    "1.0.0": [{
      success: ["keys", "currentSize", "limitSize"]
    }]
  },
  removeStorage: {
    "1.0.0": [{
      object: ["key"]
    }]
  },
  removeStorageSync: {
    "1.0.0": []
  },
  clearStorage: {
    "1.0.0": []
  },
  clearStorageSync: {
    "1.0.0": []
  },
  getNetworkType: {
    "1.0.0": [{
      success: ["networkType"]
    }]
  },
  onNetworkStatusChange: {
    "1.1.0": [{
      callback: ["isConnected", {
        networkType: ["wifi", "2g", "3g", "4g", "none", "unknown"]
      }]
    }]
  },
  setScreenBrightness: {
    "1.2.0": [{
      object: ["value"]
    }]
  },
  getScreenBrightness: {
    "1.2.0": [{
      success: ["value"]
    }]
  },
  vibrateLong: {
    "1.2.0": []
  },
  vibrateShort: {
    "1.2.0": []
  },
  getExtConfig: {
    "1.1.0": [{
      success: ["extConfig"]
    }]
  },
  getExtConfigSync: {
    "1.1.0": []
  },
  saveFile: {
    "1.0.0": [{
      object: ["tempFilePath"]
    }, {
      success: ["savedFilePath"]
    }]
  },
  getSavedFileList: {
    "1.0.0": [{
      success: ["fileList"]
    }]
  },
  getSavedFileInfo: {
    "1.0.0": [{
      object: ["filePath"]
    }, {
      success: ["size", "createTime"]
    }]
  },
  removeSavedFile: {
    "1.0.0": [{
      object: ["filePath"]
    }]
  },
  openDocument: {
    "1.0.0": [{
      object: ["filePath"]
    }],
    "1.4.0": [{
      object: ["fileType"]
    }]
  },
  getBackgroundAudioManager: {
    "1.2.0": []
  },
  getFileInfo: {
    "1.4.0": [{
      object: ["filePath", {
        digestAlgorithm: ["md5", "sha1"]
      }]
    }, {
      success: ["size", "digest"]
    }]
  },
  startBeaconDiscovery: {
    "1.2.0": [{
      object: ["uuids"]
    }]
  },
  stopBeaconDiscovery: {
    "1.2.0": []
  },
  getBeacons: {
    "1.2.0": [{
      success: ["beacons"]
    }]
  },
  onBeaconUpdate: {
    "1.2.0": [{
      callback: ["beacons"]
    }]
  },
  onBeaconServiceChange: {
    "1.2.0": [{
      callback: ["available", "discovering"]
    }]
  },
  getLocation: {
    "1.0.0": [{
      object: ["type"]
    }, {
      success: ["latitude", "longitude", "speed", "accuracy"]
    }],
    "1.2.0": [{
      success: ["altitude", "verticalAccuracy", "horizontalAccuracy"]
    }]
  },
  chooseLocation: {
    "1.0.0": [{
      object: ["cancel"]
    }, {
      success: ["name", "address", "latitude", "longitude"]
    }]
  },
  openLocation: {
    "1.0.0": [{
      object: ["latitude", "longitude", "scale", "name", "address"]
    }]
  },
  getBackgroundAudioPlayerState: {
    "1.0.0": [{
      success: ["duration", "currentPosition", "status", "downloadPercent", "dataUrl"]
    }]
  },
  playBackgroundAudio: {
    "1.0.0": [{
      object: ["dataUrl", "title", "coverImgUrl"]
    }]
  },
  pauseBackgroundAudio: {
    "1.0.0": []
  },
  seekBackgroundAudio: {
    "1.0.0": [{
      object: ["position"]
    }]
  },
  stopBackgroundAudio: {
    "1.0.0": []
  },
  onBackgroundAudioPlay: {
    "1.0.0": []
  },
  onBackgroundAudioPause: {
    "1.0.0": []
  },
  onBackgroundAudioStop: {
    "1.0.0": []
  },
  chooseImage: {
    "1.0.0": [{
      object: ["count", "sizeType", "sourceType"]
    }, {
      success: ["tempFilePaths"]
    }],
    "1.2.0": [{
      success: ["tempFiles"]
    }]
  },
  previewImage: {
    "1.0.0": [{
      object: ["current", "urls"]
    }]
  },
  getImageInfo: {
    "1.0.0": [{
      object: ["src"]
    }, {
      success: ["width", "height", "path"]
    }]
  },
  saveImageToPhotosAlbum: {
    "1.2.0": [{
      object: ["filePath"]
    }]
  },
  startRecord: {
    "1.0.0": [{
      success: ["tempFilePath"]
    }]
  },
  stopRecord: {
    "1.0.0": []
  },
  chooseVideo: {
    "1.0.0": [{
      object: ["sourceType", "maxDuration", "camera"]
    }, {
      success: ["tempFilePath", "duration", "size", "height", "width"]
    }]
  },
  saveVideoToPhotosAlbum: {
    "1.2.0": [{
      object: ["filePath"]
    }]
  },
  playVoice: {
    "1.0.0": [{
      object: ["filePath"]
    }]
  },
  pauseVoice: {
    "1.0.0": []
  },
  stopVoice: {
    "1.0.0": []
  },
  navigateBackMiniProgram: {
    "1.3.0": [{
      object: ["extraData"]
    }]
  },
  navigateToMiniProgram: {
    "1.3.0": [{
      object: ["appId", "path", "extraData", "envVersion"]
    }]
  },
  uploadFile: {
    "1.0.0": [{
      object: ["url", "filePath", "name", "header", "formData"]
    }, {
      success: ["data", "statusCode"]
    }]
  },
  downloadFile: {
    "1.0.0": [{
      object: ["url", "header"]
    }]
  },
  request: {
    "1.0.0": [{
      object: ["url", "data", "header", {
        method: ["OPTIONS", "GET", "HEAD", "POST", "PUT", "DELETE", "TRACE", "CONNECT"]
      }, "dataType"]
    }, {
      success: ["data", "statusCode"]
    }],
    "1.2.0": [{
      success: ["header"]
    }]
  },
  connectSocket: {
    "1.0.0": [{
      object: ["url", "data", "header", {
        method: ["OPTIONS", "GET", "HEAD", "POST", "PUT", "DELETE", "TRACE", "CONNECT"]
      }]
    }],
    "1.4.0": [{
      object: ["protocols"]
    }]
  },
  onSocketOpen: {
    "1.0.0": []
  },
  onSocketError: {
    "1.0.0": []
  },
  sendSocketMessage: {
    "1.0.0": [{
      object: ["data"]
    }]
  },
  onSocketMessage: {
    "1.0.0": [{
      callback: ["data"]
    }]
  },
  closeSocket: {
    "1.0.0": [],
    "1.4.0": [{
      object: ["code", "reason"]
    }]
  },
  onSocketClose: {
    "1.0.0": []
  },
  onUserCaptureScreen: {
    "1.4.0": []
  },
  chooseContact: {
    "1.0.0": [{
      success: ["phoneNumber", "displayName"]
    }]
  },
  getUserInfo: {
    "1.0.0": [{
      success: ["userInfo", "rawData", "signature", "encryptedData", "iv"]
    }],
    "1.1.0": [{
      object: ["withCredentials"]
    }],
    "1.4.0": [{
      object: ["lang"]
    }]
  }
}, (0, _defineProperty3.default)(_APIs, "canIUse", {
  "1.0.0": [{
    success: ["useable"]
  }]
}), (0, _defineProperty3.default)(_APIs, "addPhoneContact", {
  "1.2.0": [{
    object: ["photoFilePath", "nickName", "lastName", "middleName", "firstName", "remark", "mobilePhoneNumber", "weChatNumber", "addressCountry", "addressState", "addressCity", "addressStreet", "addressPostalCode", "organization", "title", "workFaxNumber", "workPhoneNumber", "hostNumber", "email", "url", "workAddressCountry", "workAddressState", "workAddressCity", "workAddressStreet", "workAddressPostalCode", "homeFaxNumber", "homePhoneNumber", "homeAddressCountry", "homeAddressState", "homeAddressCity", "homeAddressStreet", "homeAddressPostalCode"]
  }]
}), (0, _defineProperty3.default)(_APIs, "makePhoneCall", {
  "1.0.0": [{
    object: ["phoneNumber"]
  }]
}), (0, _defineProperty3.default)(_APIs, "stopPullDownRefresh", {
  "1.0.0": []
}), (0, _defineProperty3.default)(_APIs, "scanCode", {
  "1.0.0": [{
    success: ["result", "scanType", "charSet", "path"]
  }],
  "1.2.0": [{
    object: ["onlyFromCamera"]
  }]
}), (0, _defineProperty3.default)(_APIs, "pageScrollTo", {
  "1.4.0": [{
    object: ["scrollTop"]
  }]
}), (0, _defineProperty3.default)(_APIs, "setEnableDebug", {
  "1.4.0": [{
    object: ["enableDebug"]
  }]
}), (0, _defineProperty3.default)(_APIs, "setKeepScreenOn", {
  "1.4.0": [{
    object: ["keepScreenOn"]
  }]
}), (0, _defineProperty3.default)(_APIs, "setNavigationBarColor", {
  "1.4.0": [{
    object: ["frontColor", "backgroundColor", "animation", "animation.duration", {
      "animation.timingFunc": ["linear", "easeIn", "easeOut", "easeInOut"]
    }]
  }]
}), (0, _defineProperty3.default)(_APIs, "openSetting", {
  "1.1.0": [{
    success: ["authSetting"]
  }]
}), (0, _defineProperty3.default)(_APIs, "getSetting", {
  "1.2.0": [{
    success: ["authSetting"]
  }]
}), (0, _defineProperty3.default)(_APIs, "showShareMenu", {
  "1.1.0": [{
    object: ["withShareTicket"]
  }]
}), (0, _defineProperty3.default)(_APIs, "hideShareMenu", {
  "1.1.0": []
}), (0, _defineProperty3.default)(_APIs, "updateShareMenu", {
  "1.2.0": [{
    object: ["withShareTicket"]
  }],
  "1.4.0": [{
    object: ["dynamic", "widget"]
  }]
}), (0, _defineProperty3.default)(_APIs, "getShareInfo", {
  "1.1.0": [{
    object: ["shareTicket"]
  }, {
    callback: ["encryptedData", "iv"]
  }]
}), (0, _defineProperty3.default)(_APIs, "getSystemInfo", {
  "1.0.0": [{
    success: ["model", "pixelRatio", "windowWidth", "windowHeight", "language", "version", "system", "platform"]
  }],
  "1.1.0": [{
    success: ["screenWidth", "screenHeight", "SDKVersion"]
  }]
}), (0, _defineProperty3.default)(_APIs, "getSystemInfoSync", {
  "1.0.0": [{
    return: ["model", "pixelRatio", "windowWidth", "windowHeight", "language", "version", "system", "platform"]
  }],
  "1.1.0": [{
    return: ["screenWidth", "screenHeight", "SDKVersion"]
  }]
}), (0, _defineProperty3.default)(_APIs, "navigateTo", {
  "1.0.0": [{
    object: ["url"]
  }]
}), (0, _defineProperty3.default)(_APIs, "redirectTo", {
  "1.0.0": [{
    object: ["url"]
  }]
}), (0, _defineProperty3.default)(_APIs, "reLaunch", {
  "1.1.0": [{
    object: ["url"]
  }]
}), (0, _defineProperty3.default)(_APIs, "switchTab", {
  "1.0.0": [{
    object: ["url"]
  }]
}), (0, _defineProperty3.default)(_APIs, "navigateBack", {
  "1.0.0": [{
    object: ["delta"]
  }]
}), (0, _defineProperty3.default)(_APIs, "setNavigationBarTitle", {
  "1.0.0": [{
    object: ["title"]
  }]
}), (0, _defineProperty3.default)(_APIs, "showNavigationBarLoading", {
  "1.0.0": []
}), (0, _defineProperty3.default)(_APIs, "hideNavigationBarLoading", {
  "1.0.0": []
}), (0, _defineProperty3.default)(_APIs, "setBackgroundColor", {
  "1.0.0": []
}), (0, _defineProperty3.default)(_APIs, "setBackgroundTextStyle", {
  "1.0.0": ["textStyle"]
}), (0, _defineProperty3.default)(_APIs, "setTopBarText", {
  "1.4.2": [{
    object: ["text"]
  }]
}), (0, _defineProperty3.default)(_APIs, "getWeRunData", {
  "1.2.0": [{
    success: ["encryptedData", "iv"]
  }]
}), (0, _defineProperty3.default)(_APIs, "createSelectorQuery", {
  "1.4.0": []
}), (0, _defineProperty3.default)(_APIs, "createCanvasContext", {
  "1.0.0": []
}), (0, _defineProperty3.default)(_APIs, "canvasToTempFilePath", {
  "1.0.0": [{
    object: ["canvasId"]
  }],
  "1.2.0": [{
    object: ["x", "y", "width", "height", "destWidth", "destHeight"]
  }]
}), (0, _defineProperty3.default)(_APIs, "canvasContext", {
  "1.0.0": ["addColorStop", "arc", "beginPath", "bezierCurveTo", "clearActions", "clearRect", "closePath", "createCircularGradient", "createLinearGradient", "drawImage", "draw", "fillRect", "fillText", "fill", "lineTo", "moveTo", "quadraticCurveTo", "rect", "rotate", "save", "scale", "setFillStyle", "setFontSize", "setGlobalAlpha", "setLineCap", "setLineJoin", "setLineWidth", "setMiterLimit", "setShadow", "setStrokeStyle", "strokeRect", "stroke", "translate"],
  "1.1.0": ["setTextAlign"],
  "1.4.0": ["setTextBaseline"]
}), (0, _defineProperty3.default)(_APIs, "animation", {
  "1.0.0": ["opacity", "backgroundColor", "width", "height", "top", "left", "bottom", "right", "rotate", "rotateX", "rotateY", "rotateZ", "rotate3d", "scale", "scaleX", "scaleY", "scaleZ", "scale3d", "translate", "translateX", "translateY", "translateZ", "translate3d", "skew", "skewX", "skewY", "matrix", "matrix3d"]
}), (0, _defineProperty3.default)(_APIs, "audioContext", {
  "1.0.0": ["setSrc", "play", "pause", "seek"]
}), (0, _defineProperty3.default)(_APIs, "mapContext", {
  "1.0.0": ["getCenterLocation", "moveToLocation"],
  "1.2.0": ["translateMarker", "includePoints"],
  "1.4.0": ["getRegion", "getScale"]
}), (0, _defineProperty3.default)(_APIs, "videoContext", {
  "1.0.0": ["play", "pause", "seek", "sendDanmu"],
  "1.4.0": ["playbackRate", "requestFullScreen", "exitFullScreen"]
}), (0, _defineProperty3.default)(_APIs, "backgroundAudioManager", {
  "1.2.0": ["play", "pause", "stop", "seek", "onCanplay", "onPlay", "onPause", "onStop", "onEnded", "onTimeUpdate", "onPrev", "onNext", "onError", "onWaiting", "duration", "currentTime", "paused", "src", "startTime", "buffered", "title", "epname", "singer", "coverImgUrl", "webUrl"]
}), (0, _defineProperty3.default)(_APIs, "uploadTask", {
  "1.4.0": ["onProgressUpdate", "abort"]
}), (0, _defineProperty3.default)(_APIs, "downloadTask", {
  "1.4.0": ["onProgressUpdate", "abort"]
}), (0, _defineProperty3.default)(_APIs, "requestTask", {
  "1.4.0": ["abort"]
}), (0, _defineProperty3.default)(_APIs, "selectorQuery", {
  "1.4.0": ["select", "selectAll", "selectViewport", "exec"]
}), (0, _defineProperty3.default)(_APIs, "onBLEConnectionStateChanged", {
  "1.1.0": [{
    callback: ["deviceId", "connected"]
  }]
}), (0, _defineProperty3.default)(_APIs, "notifyBLECharacteristicValueChanged", {
  "1.1.0": [{
    object: ["deviceId", "serviceId", "characteristicId", "state"]
  }]
}), (0, _defineProperty3.default)(_APIs, "sendBizRedPacket", {
  "1.2.0": [{
    object: ["timeStamp", "nonceStr", "package", "signType", "paySign"]
  }]
}), (0, _defineProperty3.default)(_APIs, "getFinChatSession", {
  "1.0.0": [{
    success: ["userId", "jwt", "accessToken"]
  }]
}), (0, _defineProperty3.default)(_APIs, "walletSignIn", {
  "1.0.0": [{
    success: ["hash"]
  }]
}), (0, _defineProperty3.default)(_APIs, "scanVehicle", {
  "1.0.0": [{
    success: ["success", "data"]
  }]
}), (0, _defineProperty3.default)(_APIs, "shareToWechat", {
  "1.0.0": [{
    success: []
  }]
}), (0, _defineProperty3.default)(_APIs, "setTabBarBadge", {
  "1.0.0": [{
    success: []
  }]
}), (0, _defineProperty3.default)(_APIs, "removeTabBarBadge", {
  "1.0.0": [{
    success: []
  }]
}), (0, _defineProperty3.default)(_APIs, "getMenuButtonBoundingClientRect", {
  "1.0.0": [{
    success: []
  }]
}), _APIs);
//检测组件相关是否存在
function isComponentExist(params) {
  var name = params[0],
      //组件名
  attribute = params[1],
      //属性名
  option = params[2],
      //组件属性可选值
  component = Components[name];
  if (!attribute) {
    return true;
  } else {
    for (var key in component) {
      for (var i = 0; i < component[key].length; i++) {
        if ("string" == typeof component[key][i] && component[key][i] == attribute) {
          return true;
        } else if (component[key][i][attribute]) {
          if (!option) {
            return true;
          } else if (component[key][i][attribute].indexOf(option) > -1) {
            return true;
          }
        }
      }
    }
    return false;
  }
}

//检测API相关是否存在
function isAPIExist(params) {
  var name = params[0],
      //API名
  method = params[1],
      //调用方式：有效值为return, success, object, callback
  param = params[2],
      //组件属性可选值
  options = params[3],
      methods = ["return", "success", "object", "callback"],
      api = APIs[name];
  if (api) {
    if (!method) {
      return true;
    } else if (methods.indexOf(method) < 0) {
      return false;
    } else {
      for (var key in api) {
        for (var i = 0; i < key.length; i++) {
          if ("object" == (0, _typeof3.default)(api[key][i]) && api[key][i][method]) {
            if (!param) {
              return true;
            } else {
              for (var j = 0; j < api[key][i][method].length; j++) {
                if (typeof api[key][i][method][j] == "string" && api[key][i][method][j] == param) {
                  return true;
                } else if ((0, _typeof3.default)(api[key][i][method][j]) == "object" && api[key][i][method][j][param]) {
                  if (!options) {
                    return true;
                  } else if (api[key][i][method][j][param].indexOf(options) > -1) {
                    return true;
                  } else {
                    return false;
                  }
                }
              }
              return true;
            }
          }
        }
        return false;
      }
      return false;
    }
  } else {
    return true;
  }
}

function canIUse(params, version) {
  var name = params[0]; //API或组件名
  if (Components[name]) {
    return isComponentExist(params);
  } else if (APIs[name]) {
    return isAPIExist(params);
  } else {
    return false;
  }
}

function checkParam(e, t) {
  if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

var gSelectorExecIndex = 1;
var gSelectorCallback = {};
/**
 * 
 * @param {*} webviewId 
 * @param {*} reqs {selector: '', single: '', fields: ''}
 * @param {*} callback 
 */
var selectorExec = function selectorExec(webviewId, reqs, callback, wxQuerySelector) {
  var reqId = gSelectorExecIndex++;
  gSelectorCallback[reqId] = callback;
  var isCustomcomponent = wxQuerySelector.isCustomcomponent,
      componentInstanceId = wxQuerySelector.componentInstanceId,
      customComponentId = wxQuerySelector.customComponentId;

  var params = {
    reqId: reqId,
    reqs: reqs,
    isCustomcomponent: isCustomcomponent
  };
  if (isCustomcomponent) {
    params.componentInstanceId = componentInstanceId;
    params.customComponentId = customComponentId;
  }
  ServiceJSBridge.publish('requestComponentInfo', params, [webviewId]);
};
ServiceJSBridge.subscribe('responseComponentInfo', function (componentInfo) {
  var reqId = componentInfo.reqId;
  var callback = gSelectorCallback[reqId];
  if (callback) {
    delete gSelectorCallback[reqId];
    callback(componentInfo.res);
  }
});

var SetSelect = function () {
  function SetSelect(t, n, r) {
    (0, _classCallCheck3.default)(this, SetSelect);

    this._selectorQuery = t, this._selector = n, this._single = r;
  }

  (0, _createClass3.default)(SetSelect, [{
    key: "fields",
    value: function fields(e, callback) {
      this._selectorQuery._push(this._selector, this._single, e, callback);
      return this._selectorQuery;
    }
  }, {
    key: "boundingClientRect",
    value: function boundingClientRect(callback) {
      this._selectorQuery._push(this._selector, this._single, {
        id: true,
        dataset: true,
        rect: true,
        size: true
      }, callback);
      return this._selectorQuery;
    }
  }, {
    key: "scrollOffset",
    value: function scrollOffset(callback) {
      this._selectorQuery._push(this._selector, this._single, {
        id: true,
        dataset: true,
        scrollOffset: true
      }, callback);
      return this._selectorQuery;
    }
  }]);
  return SetSelect;
}();

var wxQuerySelector = function () {
  function wxQuerySelector(t) {
    (0, _classCallCheck3.default)(this, wxQuerySelector);

    this.max = 10;
    this._webviewId = t;
    this._queue = [];
    this._queueCb = [];
    this.isCustomcomponent = false;
  }

  (0, _createClass3.default)(wxQuerySelector, [{
    key: "select",
    value: function select(e) {
      var t = new SetSelect(this, e, true);
      return t;
    }
  }, {
    key: "selectAll",
    value: function selectAll(e) {
      return new SetSelect(this, e, false);
    }
  }, {
    key: "selectViewport",
    value: function selectViewport() {
      return new SetSelect(this, 'viewport', true);
    }
  }, {
    key: "_push",
    value: function _push(e, t, n, callback) {
      this._queue.push({
        selector: e,
        single: t,
        fields: n
      });
      this._queueCb.push(callback || null);
    }
  }, {
    key: "exec",
    value: function exec(callback) {
      var _this = this;
      var fn = function fn(info) {
        var o = _this._queueCb;
        info.forEach(function (value, index) {
          if ('function' == typeof o[index]) {
            o[index].call(_this, value);
          }
        });
        if ('function' == typeof callback) {
          callback.call(_this, info);
        }
      };
      selectorExec(this._webviewId, this._queue, fn, this);
    }
  }, {
    key: "in",
    value: function _in(component) {
      if (component.id && component.instanceId) {
        this.isCustomcomponent = true;
        this.componentInstanceId = component.instanceId;
        this.customComponentId = component.id;
      }
      return this;
    }
  }]);
  return wxQuerySelector;
}();

function transWxmlToHtml(url) {
  if ("string" != typeof url) return url;
  var urlArr = url.split("?");
  return urlArr[0] += ".html", void 0 !== urlArr[1] ? urlArr[0] + "?" + urlArr[1] : urlArr[0];
}

function removeHtmlSuffixFromUrl(url) {
  return "string" == typeof url ? -1 !== url.indexOf("?") ? url.replace(/\.html\?/, "?") : url.replace(/\.html$/, "") : url;
}

exports.default = {
  surroundByTryCatchFactory: surroundByTryCatchFactory,
  getDataType: getDataType,
  isObject: isObject,
  paramCheck: paramCheck,
  getRealRoute: getRealRoute,
  getPlatform: getPlatform,
  urlEncodeFormData: urlEncodeFormData,
  addQueryStringToUrl: addQueryStringToUrl,
  validateUrl: validateUrl,
  assign: assign,
  encodeUrlQuery: encodeUrlQuery,
  transWxmlToHtml: transWxmlToHtml,
  removeHtmlSuffixFromUrl: removeHtmlSuffixFromUrl,
  extend: extend,
  arrayBufferToBase64: arrayBufferToBase64,
  base64ToArrayBuffer: base64ToArrayBuffer,
  blobToArrayBuffer: blobToArrayBuffer,
  convertObjectValueToString: convertObjectValueToString,
  anyTypeToString: surroundByTryCatchFactory(anyTypeToString, "anyTypeToString"),
  stringToAnyType: surroundByTryCatchFactory(stringToAnyType, "stringToAnyType"),
  AppServiceSdkKnownError: AppServiceSdkKnownError,
  renameProperty: renameProperty,
  defaultRunningStatus: "active",
  toArray: toArray,
  canIUse: canIUse,
  wxQuerySelector: wxQuerySelector
};

/***/ }),
/* 80 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $at = __webpack_require__(440)(true);

// 21.1.3.27 String.prototype[@@iterator]()
__webpack_require__(196)(String, 'String', function (iterated) {
  this._t = String(iterated); // target
  this._i = 0;                // next index
// 21.1.5.2.1 %StringIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var index = this._i;
  var point;
  if (index >= O.length) return { value: undefined, done: true };
  point = $at(O, index);
  this._i += point.length;
  return { value: point, done: false };
});


/***/ }),
/* 81 */
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || Function("return this")() || (1,eval)("this");
} catch(e) {
	// This works if the window reference is available
	if(typeof window === "object")
		g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),
/* 82 */
/***/ (function(module, exports, __webpack_require__) {

// false -> Array#indexOf
// true  -> Array#includes
var toIObject = __webpack_require__(20);
var toLength = __webpack_require__(6);
var toAbsoluteIndex = __webpack_require__(49);
module.exports = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = toIObject($this);
    var length = toLength(O.length);
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare
    if (IS_INCLUDES && el != el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare
      if (value != value) return true;
    // Array#indexOf ignores holes, Array#includes - not
    } else for (;length > index; index++) if (IS_INCLUDES || index in O) {
      if (O[index] === el) return IS_INCLUDES || index || 0;
    } return !IS_INCLUDES && -1;
  };
};


/***/ }),
/* 83 */
/***/ (function(module, exports) {

exports.f = Object.getOwnPropertySymbols;


/***/ }),
/* 84 */
/***/ (function(module, exports, __webpack_require__) {

// 7.2.2 IsArray(argument)
var cof = __webpack_require__(26);
module.exports = Array.isArray || function isArray(arg) {
  return cof(arg) == 'Array';
};


/***/ }),
/* 85 */
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(27);
var defined = __webpack_require__(32);
// true  -> String#at
// false -> String#codePointAt
module.exports = function (TO_STRING) {
  return function (that, pos) {
    var s = String(defined(that));
    var i = toInteger(pos);
    var l = s.length;
    var a, b;
    if (i < 0 || i >= l) return TO_STRING ? '' : undefined;
    a = s.charCodeAt(i);
    return a < 0xd800 || a > 0xdbff || i + 1 === l || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff
      ? TO_STRING ? s.charAt(i) : a
      : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
  };
};


/***/ }),
/* 86 */
/***/ (function(module, exports, __webpack_require__) {

// 7.2.8 IsRegExp(argument)
var isObject = __webpack_require__(4);
var cof = __webpack_require__(26);
var MATCH = __webpack_require__(5)('match');
module.exports = function (it) {
  var isRegExp;
  return isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : cof(it) == 'RegExp');
};


/***/ }),
/* 87 */
/***/ (function(module, exports, __webpack_require__) {

var ITERATOR = __webpack_require__(5)('iterator');
var SAFE_CLOSING = false;

try {
  var riter = [7][ITERATOR]();
  riter['return'] = function () { SAFE_CLOSING = true; };
  // eslint-disable-next-line no-throw-literal
  Array.from(riter, function () { throw 2; });
} catch (e) { /* empty */ }

module.exports = function (exec, skipClosing) {
  if (!skipClosing && !SAFE_CLOSING) return false;
  var safe = false;
  try {
    var arr = [7];
    var iter = arr[ITERATOR]();
    iter.next = function () { return { done: safe = true }; };
    arr[ITERATOR] = function () { return iter; };
    exec(arr);
  } catch (e) { /* empty */ }
  return safe;
};


/***/ }),
/* 88 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var classof = __webpack_require__(61);
var builtinExec = RegExp.prototype.exec;

 // `RegExpExec` abstract operation
// https://tc39.github.io/ecma262/#sec-regexpexec
module.exports = function (R, S) {
  var exec = R.exec;
  if (typeof exec === 'function') {
    var result = exec.call(R, S);
    if (typeof result !== 'object') {
      throw new TypeError('RegExp exec method returned something other than an Object or null');
    }
    return result;
  }
  if (classof(R) !== 'RegExp') {
    throw new TypeError('RegExp#exec called on incompatible receiver');
  }
  return builtinExec.call(R, S);
};


/***/ }),
/* 89 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

__webpack_require__(175);
var redefine = __webpack_require__(16);
var hide = __webpack_require__(15);
var fails = __webpack_require__(3);
var defined = __webpack_require__(32);
var wks = __webpack_require__(5);
var regexpExec = __webpack_require__(129);

var SPECIES = wks('species');

var REPLACE_SUPPORTS_NAMED_GROUPS = !fails(function () {
  // #replace needs built-in support for named groups.
  // #match works fine because it just return the exec results, even if it has
  // a "grops" property.
  var re = /./;
  re.exec = function () {
    var result = [];
    result.groups = { a: '7' };
    return result;
  };
  return ''.replace(re, '$<a>') !== '7';
});

var SPLIT_WORKS_WITH_OVERWRITTEN_EXEC = (function () {
  // Chrome 51 has a buggy "split" implementation when RegExp#exec !== nativeExec
  var re = /(?:)/;
  var originalExec = re.exec;
  re.exec = function () { return originalExec.apply(this, arguments); };
  var result = 'ab'.split(re);
  return result.length === 2 && result[0] === 'a' && result[1] === 'b';
})();

module.exports = function (KEY, length, exec) {
  var SYMBOL = wks(KEY);

  var DELEGATES_TO_SYMBOL = !fails(function () {
    // String methods call symbol-named RegEp methods
    var O = {};
    O[SYMBOL] = function () { return 7; };
    return ''[KEY](O) != 7;
  });

  var DELEGATES_TO_EXEC = DELEGATES_TO_SYMBOL ? !fails(function () {
    // Symbol-named RegExp methods call .exec
    var execCalled = false;
    var re = /a/;
    re.exec = function () { execCalled = true; return null; };
    if (KEY === 'split') {
      // RegExp[@@split] doesn't call the regex's exec method, but first creates
      // a new one. We need to return the patched regex when creating the new one.
      re.constructor = {};
      re.constructor[SPECIES] = function () { return re; };
    }
    re[SYMBOL]('');
    return !execCalled;
  }) : undefined;

  if (
    !DELEGATES_TO_SYMBOL ||
    !DELEGATES_TO_EXEC ||
    (KEY === 'replace' && !REPLACE_SUPPORTS_NAMED_GROUPS) ||
    (KEY === 'split' && !SPLIT_WORKS_WITH_OVERWRITTEN_EXEC)
  ) {
    var nativeRegExpMethod = /./[SYMBOL];
    var fns = exec(
      defined,
      SYMBOL,
      ''[KEY],
      function maybeCallNative(nativeMethod, regexp, str, arg2, forceStringMethod) {
        if (regexp.exec === regexpExec) {
          if (DELEGATES_TO_SYMBOL && !forceStringMethod) {
            // The native String method already delegates to @@method (this
            // polyfilled function), leasing to infinite recursion.
            // We avoid it by directly calling the native @@method method.
            return { done: true, value: nativeRegExpMethod.call(regexp, str, arg2) };
          }
          return { done: true, value: nativeMethod.call(str, regexp, arg2) };
        }
        return { done: false };
      }
    );
    var strfn = fns[0];
    var rxfn = fns[1];

    redefine(String.prototype, KEY, strfn);
    hide(RegExp.prototype, SYMBOL, length == 2
      // 21.2.5.8 RegExp.prototype[@@replace](string, replaceValue)
      // 21.2.5.11 RegExp.prototype[@@split](string, limit)
      ? function (string, arg) { return rxfn.call(string, this, arg); }
      // 21.2.5.6 RegExp.prototype[@@match](string)
      // 21.2.5.9 RegExp.prototype[@@search](string)
      : function (string) { return rxfn.call(string, this); }
    );
  }
};


/***/ }),
/* 90 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var navigator = global.navigator;

module.exports = navigator && navigator.userAgent || '';


/***/ }),
/* 91 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(2);
var $export = __webpack_require__(0);
var redefine = __webpack_require__(16);
var redefineAll = __webpack_require__(55);
var meta = __webpack_require__(42);
var forOf = __webpack_require__(54);
var anInstance = __webpack_require__(53);
var isObject = __webpack_require__(4);
var fails = __webpack_require__(3);
var $iterDetect = __webpack_require__(87);
var setToStringTag = __webpack_require__(60);
var inheritIfRequired = __webpack_require__(115);

module.exports = function (NAME, wrapper, methods, common, IS_MAP, IS_WEAK) {
  var Base = global[NAME];
  var C = Base;
  var ADDER = IS_MAP ? 'set' : 'add';
  var proto = C && C.prototype;
  var O = {};
  var fixMethod = function (KEY) {
    var fn = proto[KEY];
    redefine(proto, KEY,
      KEY == 'delete' ? function (a) {
        return IS_WEAK && !isObject(a) ? false : fn.call(this, a === 0 ? 0 : a);
      } : KEY == 'has' ? function has(a) {
        return IS_WEAK && !isObject(a) ? false : fn.call(this, a === 0 ? 0 : a);
      } : KEY == 'get' ? function get(a) {
        return IS_WEAK && !isObject(a) ? undefined : fn.call(this, a === 0 ? 0 : a);
      } : KEY == 'add' ? function add(a) { fn.call(this, a === 0 ? 0 : a); return this; }
        : function set(a, b) { fn.call(this, a === 0 ? 0 : a, b); return this; }
    );
  };
  if (typeof C != 'function' || !(IS_WEAK || proto.forEach && !fails(function () {
    new C().entries().next();
  }))) {
    // create collection constructor
    C = common.getConstructor(wrapper, NAME, IS_MAP, ADDER);
    redefineAll(C.prototype, methods);
    meta.NEED = true;
  } else {
    var instance = new C();
    // early implementations not supports chaining
    var HASNT_CHAINING = instance[ADDER](IS_WEAK ? {} : -0, 1) != instance;
    // V8 ~  Chromium 40- weak-collections throws on primitives, but should return false
    var THROWS_ON_PRIMITIVES = fails(function () { instance.has(1); });
    // most early implementations doesn't supports iterables, most modern - not close it correctly
    var ACCEPT_ITERABLES = $iterDetect(function (iter) { new C(iter); }); // eslint-disable-line no-new
    // for early implementations -0 and +0 not the same
    var BUGGY_ZERO = !IS_WEAK && fails(function () {
      // V8 ~ Chromium 42- fails only with 5+ elements
      var $instance = new C();
      var index = 5;
      while (index--) $instance[ADDER](index, index);
      return !$instance.has(-0);
    });
    if (!ACCEPT_ITERABLES) {
      C = wrapper(function (target, iterable) {
        anInstance(target, C, NAME);
        var that = inheritIfRequired(new Base(), target, C);
        if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
        return that;
      });
      C.prototype = proto;
      proto.constructor = C;
    }
    if (THROWS_ON_PRIMITIVES || BUGGY_ZERO) {
      fixMethod('delete');
      fixMethod('has');
      IS_MAP && fixMethod('get');
    }
    if (BUGGY_ZERO || HASNT_CHAINING) fixMethod(ADDER);
    // weak collections should not contains .clear method
    if (IS_WEAK && proto.clear) delete proto.clear;
  }

  setToStringTag(C, NAME);

  O[NAME] = C;
  $export($export.G + $export.W + $export.F * (C != Base), O);

  if (!IS_WEAK) common.setStrong(C, NAME, IS_MAP);

  return C;
};


/***/ }),
/* 92 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var hide = __webpack_require__(15);
var uid = __webpack_require__(47);
var TYPED = uid('typed_array');
var VIEW = uid('view');
var ABV = !!(global.ArrayBuffer && global.DataView);
var CONSTR = ABV;
var i = 0;
var l = 9;
var Typed;

var TypedArrayConstructors = (
  'Int8Array,Uint8Array,Uint8ClampedArray,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array'
).split(',');

while (i < l) {
  if (Typed = global[TypedArrayConstructors[i++]]) {
    hide(Typed.prototype, TYPED, true);
    hide(Typed.prototype, VIEW, true);
  } else CONSTR = false;
}

module.exports = {
  ABV: ABV,
  CONSTR: CONSTR,
  TYPED: TYPED,
  VIEW: VIEW
};


/***/ }),
/* 93 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// Forced replacement prototype accessors methods
module.exports = __webpack_require__(41) || !__webpack_require__(3)(function () {
  var K = Math.random();
  // In FF throws only define methods
  // eslint-disable-next-line no-undef, no-useless-call
  __defineSetter__.call(null, K, function () { /* empty */ });
  delete __webpack_require__(2)[K];
});


/***/ }),
/* 94 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-setmap-offrom/
var $export = __webpack_require__(0);

module.exports = function (COLLECTION) {
  $export($export.S, COLLECTION, { of: function of() {
    var length = arguments.length;
    var A = new Array(length);
    while (length--) A[length] = arguments[length];
    return new this(A);
  } });
};


/***/ }),
/* 95 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-setmap-offrom/
var $export = __webpack_require__(0);
var aFunction = __webpack_require__(11);
var ctx = __webpack_require__(25);
var forOf = __webpack_require__(54);

module.exports = function (COLLECTION) {
  $export($export.S, COLLECTION, { from: function from(source /* , mapFn, thisArg */) {
    var mapFn = arguments[1];
    var mapping, A, n, cb;
    aFunction(this);
    mapping = mapFn !== undefined;
    if (mapping) aFunction(mapFn);
    if (source == undefined) return new this();
    A = [];
    if (mapping) {
      n = 0;
      cb = ctx(mapFn, arguments[2], 2);
      forOf(source, false, function (nextItem) {
        A.push(cb(nextItem, n++));
      });
    } else {
      forOf(source, false, A.push, A);
    }
    return new this(A);
  } });
};


/***/ }),
/* 96 */
/***/ (function(module, exports) {

var id = 0;
var px = Math.random();
module.exports = function (key) {
  return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
};


/***/ }),
/* 97 */
/***/ (function(module, exports) {

module.exports = function (it) {
  if (typeof it != 'function') throw TypeError(it + ' is not a function!');
  return it;
};


/***/ }),
/* 98 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _typeof2 = __webpack_require__(13);

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return call && ((typeof call === "undefined" ? "undefined" : (0, _typeof3.default)(call)) === "object" || typeof call === "function") ? call : self;
};

/***/ }),
/* 99 */
/***/ (function(module, exports, __webpack_require__) {

var def = __webpack_require__(40).f;
var has = __webpack_require__(57);
var TAG = __webpack_require__(14)('toStringTag');

module.exports = function (it, tag, stat) {
  if (it && !has(it = stat ? it : it.prototype, TAG)) def(it, TAG, { configurable: true, value: tag });
};


/***/ }),
/* 100 */
/***/ (function(module, exports) {

exports.f = {}.propertyIsEnumerable;


/***/ }),
/* 101 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _setPrototypeOf = __webpack_require__(218);

var _setPrototypeOf2 = _interopRequireDefault(_setPrototypeOf);

var _create = __webpack_require__(30);

var _create2 = _interopRequireDefault(_create);

var _typeof2 = __webpack_require__(13);

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === "undefined" ? "undefined" : (0, _typeof3.default)(superClass)));
  }

  subClass.prototype = (0, _create2.default)(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      enumerable: false,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf2.default ? (0, _setPrototypeOf2.default)(subClass, superClass) : subClass.__proto__ = superClass;
};

/***/ }),
/* 102 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(458), __esModule: true };

/***/ }),
/* 103 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _utils = __webpack_require__(79);

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function invoke() {
    //ServiceJSBridge.invoke
    ServiceJSBridge.invoke.apply(ServiceJSBridge, arguments);
}

function on() {
    //ServiceJSBridge.on
    ServiceJSBridge.on.apply(ServiceJSBridge, arguments);
}

function publish() {
    //ServiceJSBridge.publish
    var args = Array.prototype.slice.call(arguments);
    args[1] = {
        data: args[1],
        options: {
            timestamp: Date.now()
        }
    };
    ServiceJSBridge.publish.apply(ServiceJSBridge, args);
}

function subscribe() {
    //ServiceJSBridge.subscribe
    var args = Array.prototype.slice.call(arguments),
        callback = args[1];
    args[1] = function (params, viewId) {
        var data = params.data,
            options = params.options,
            timeMark = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
            timestamp = options && options.timestamp || 0,
            curTime = Date.now();
        "function" == typeof callback && callback(data, viewId);
        Reporter.speedReport({
            key: "webview2AppService",
            data: data || {},
            timeMark: {
                startTime: timestamp,
                endTime: curTime,
                nativeTime: timeMark.nativeTime || 0
            }
        });
    };
    ServiceJSBridge.subscribe.apply(ServiceJSBridge, args);
}

function invokeMethod(apiName) {
    var options = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
        innerFns = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
        params = {};
    for (var i in options) {
        "function" == typeof options[i] && (params[i] = Reporter.surroundThirdByTryCatch(options[i], "at api " + apiName + " " + i + " callback function"), delete options[i]);
    }
    var sysEventFns = {};
    for (var s in innerFns) {
        "function" == typeof innerFns[s] && (sysEventFns[s] = _utils2.default.surroundByTryCatchFactory(innerFns[s], "at api " + apiName + " " + s + " callback function"));
    }
    invoke(apiName, options, function (res) {
        res.errMsg = res.errMsg || apiName + ":ok";
        console.log([apiName, 'response', res]);
        var isOk = 0 === res.errMsg.indexOf(apiName + ":ok"),
            isCancel = 0 === res.errMsg.indexOf(apiName + ":cancel"),
            isFail = 0 === res.errMsg.indexOf(apiName + ":fail");
        if ("function" == typeof sysEventFns.beforeAll && sysEventFns.beforeAll(res), isOk) {
            "function" == typeof sysEventFns.beforeSuccess && sysEventFns.beforeSuccess(res), "function" == typeof params.success && params.success(res), "function" == typeof sysEventFns.afterSuccess && sysEventFns.afterSuccess(res);
        } else if (isCancel) {
            res.errMsg = res.errMsg.replace(apiName + ":cancel", apiName + ":fail cancel"), "function" == typeof params.fail && params.fail(res), "function" == typeof sysEventFns.beforeCancel && sysEventFns.beforeCancel(res), "function" == typeof params.cancel && params.cancel(res), "function" == typeof sysEventFns.afterCancel && sysEventFns.afterCancel(res);
        } else if (isFail) {
            "function" == typeof sysEventFns.beforeFail && sysEventFns.beforeFail(res), "function" == typeof params.fail && params.fail(res);
            var rt = !0;
            "function" == typeof sysEventFns.afterFail && (rt = sysEventFns.afterFail(res)), rt !== !1 && Reporter.reportIDKey({
                key: apiName + "_fail"
            });
        }
        "function" == typeof params.complete && params.complete(res), "function" == typeof sysEventFns.afterAll && sysEventFns.afterAll(res);
    });
    Reporter.reportIDKey({
        key: apiName
    });
}
function noop() {}
function onMethod(apiName, callback) {
    //onMethod
    on(apiName, _utils2.default.surroundByTryCatchFactory(callback, "at api " + apiName + " callback function"));
}
function beforeInvoke(apiName, params, paramTpl) {
    var res = _utils2.default.paramCheck(params, paramTpl);
    return !res || (beforeInvokeFail(apiName, params, "parameter error: " + res), !1);
}

function beforeInvokeFail(apiName) {
    var params = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
        errMsg = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "",
        err = apiName + ":fail " + errMsg;
    console.error(err);
    var fail = Reporter.surroundThirdByTryCatch(params.fail || noop, "at api " + apiName + " fail callback function"),
        complete = Reporter.surroundThirdByTryCatch(params.complete || noop, "at api " + apiName + " complete callback function");
    fail({ errMsg: err });
    complete({ errMsg: err });
}

function checkUrlInConfig(apiName, url, params) {
    var path = url.replace(/\.html\?.*|\.html$/, "");
    return -1 !== __wxConfig.pages.indexOf(path) || (beforeInvokeFail(apiName, params, 'url "' + _utils2.default.removeHtmlSuffixFromUrl(url) + '" is not in app.json'), !1);
}

exports.default = {
    invoke: invoke,
    on: on,
    publish: publish,
    subscribe: subscribe,
    invokeMethod: invokeMethod,
    onMethod: onMethod,
    noop: noop,
    beforeInvoke: beforeInvoke,
    beforeInvokeFail: beforeInvokeFail,
    checkUrlInConfig: checkUrlInConfig
};

/***/ }),
/* 104 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(443);
var global = __webpack_require__(12);
var hide = __webpack_require__(58);
var Iterators = __webpack_require__(67);
var TO_STRING_TAG = __webpack_require__(14)('toStringTag');

var DOMIterables = ('CSSRuleList,CSSStyleDeclaration,CSSValueList,ClientRectList,DOMRectList,DOMStringList,' +
  'DOMTokenList,DataTransferItemList,FileList,HTMLAllCollection,HTMLCollection,HTMLFormElement,HTMLSelectElement,' +
  'MediaList,MimeTypeArray,NamedNodeMap,NodeList,PaintRequestList,Plugin,PluginArray,SVGLengthList,SVGNumberList,' +
  'SVGPathSegList,SVGPointList,SVGStringList,SVGTransformList,SourceBufferList,StyleSheetList,TextTrackCueList,' +
  'TextTrackList,TouchList').split(',');

for (var i = 0; i < DOMIterables.length; i++) {
  var NAME = DOMIterables[i];
  var Collection = global[NAME];
  var proto = Collection && Collection.prototype;
  if (proto && !proto[TO_STRING_TAG]) hide(proto, TO_STRING_TAG, NAME);
  Iterators[NAME] = Iterators.Array;
}


/***/ }),
/* 105 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(463), __esModule: true };

/***/ }),
/* 106 */,
/* 107 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends2 = __webpack_require__(225);

var _extends3 = _interopRequireDefault(_extends2);

var _defineProperty = __webpack_require__(105);

var _defineProperty2 = _interopRequireDefault(_defineProperty);

var _typeof2 = __webpack_require__(13);

var _typeof3 = _interopRequireDefault(_typeof2);

var _keys = __webpack_require__(37);

var _keys2 = _interopRequireDefault(_keys);

var _getPrototypeOf = __webpack_require__(78);

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__(23);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _possibleConstructorReturn2 = __webpack_require__(98);

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__(101);

var _inherits3 = _interopRequireDefault(_inherits2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var isDevTools = function isDevTools() {
  return true;
};
var addHtmlSuffixToUrl = function addHtmlSuffixToUrl(url) {
  // 给url增加.html后缀
  if (typeof url !== 'string') {
    return url;
  }
  var uri = url.split('?')[0],
      query = url.split('?')[1];
  uri += '.html';
  if (typeof query !== 'undefined') {
    return uri + '?' + query;
  } else {
    return uri;
  }
};
var removeHtmlSuffixFromUrl = function removeHtmlSuffixFromUrl(url) {
  // 去除url后面的.html
  if (typeof url === 'string' && url.indexOf('.html') === url.length - 4) {
    return url.substring(0, url.length - 5);
  } else {
    return url;
  }
};

var hasOwnProperty = Object.prototype.hasOwnProperty;

var toString = Object.prototype.toString;

var AppServiceEngineKnownError = function (_Error) {
  (0, _inherits3.default)(AppServiceEngineKnownError, _Error);

  function AppServiceEngineKnownError(e) {
    (0, _classCallCheck3.default)(this, AppServiceEngineKnownError);

    var _this = (0, _possibleConstructorReturn3.default)(this, (AppServiceEngineKnownError.__proto__ || (0, _getPrototypeOf2.default)(AppServiceEngineKnownError)).call(this, 'APP-SERVICE-Engine:' + e));

    _this.type = 'AppServiceEngineKnownError';
    return _this;
  }

  return AppServiceEngineKnownError;
}(Error);

var pageEngine = {
  getPlatform: function getPlatform() {
    // get platform
    return 'devtools';
  },
  safeInvoke: function safeInvoke() {
    // do page method
    var res = void 0,
        args = Array.prototype.slice.call(arguments),
        fn = args[0];
    args = args.slice(1);
    try {
      var startTime = Date.now();
      res = this[fn].apply(this, args);
      var doTime = Date.now() - startTime;
      doTime > 1e3 && Reporter.slowReport({
        key: 'pageInvoke',
        cost: doTime,
        extend: 'at ' + this.__route__ + ' page ' + fn + ' function'
      });
    } catch (e) {
      Reporter.thirdErrorReport({
        error: e,
        extend: 'at "' + this.__route__ + '" page ' + fn + ' function'
      });
    }
    return res;
  },
  isEmptyObject: function isEmptyObject(obj) {
    for (var t in obj) {
      if (obj.hasOwnProperty(t)) {
        return false;
      }
    }
    return true;
  },
  extend: function extend(target, obj) {
    for (var keys = (0, _keys2.default)(obj), o = keys.length; o--;) {
      target[keys[o]] = obj[keys[o]];
    }
    return target;
  },
  noop: function noop() {},
  getDataType: function getDataType(param) {
    return Object.prototype.toString.call(param).split(' ')[1].split(']')[0];
  },
  isObject: function isObject(param) {
    return param !== null && (typeof param === 'undefined' ? 'undefined' : (0, _typeof3.default)(param)) === 'object';
  },
  hasOwn: function hasOwn(obj, attr) {
    return hasOwnProperty.call(obj, attr);
  },
  def: function def(obj, attr, value, enumerable) {
    (0, _defineProperty2.default)(obj, attr, {
      value: value,
      enumerable: !!enumerable,
      writable: true,
      configurable: true
    });
  },
  isPlainObject: function isPlainObject(e) {
    return toString.call(e) === '[object Object]';
  },
  error: function error(title, err) {
    console.group(new Date() + ' ' + title);
    console.error(err);
    console.groupEnd();
  },
  warn: function warn(title, _warn) {
    console.group(new Date() + ' ' + title);
    console.warn(_warn);
    console.groupEnd();
  },
  info: function info(msg) {
    __wxConfig__ && __wxConfig__.debug && console.info(msg);
  },
  surroundByTryCatch: function surroundByTryCatch(fn, extend) {
    var self = this;
    return function () {
      try {
        return fn.apply(fn, arguments);
      } catch (e) {
        console.log(e);
        self.errorReport(e, extend);
        return function () {};
      }
    };
  },
  errorReport: function errorReport(err, extend) {
    // d
    if (Object.prototype.toString.apply(err) === '[object Error]') {
      if (err.type === 'AppServiceEngineKnownError') {
        throw err;
      }
      Reporter.errorReport({
        key: 'jsEnginScriptError',
        error: err,
        extend: extend
      });
    }
  },
  publish: function publish() {
    var params = Array.prototype.slice.call(arguments),
        defaultOpt = {
      options: {
        timestamp: Date.now()
      }
    };
    params[1] ? params[1].options = this.extend(params[1].options || {}, defaultOpt.options) : params[1] = defaultOpt;
    ServiceJSBridge.publish.apply(ServiceJSBridge, params);
  },
  AppServiceEngineKnownError: AppServiceEngineKnownError
};

var cloneObj = function cloneObj(obj) {
  var res = void 0;
  if ((typeof obj === 'undefined' ? 'undefined' : (0, _typeof3.default)(obj)) === 'object') {
    res = Array.isArray(obj) ? [] : {};
    for (var key in obj) {
      if (obj.hasOwnProperty(key)) {
        var element = obj[key];
        if ((typeof element === 'undefined' ? 'undefined' : (0, _typeof3.default)(element)) === 'object' && element !== null) {
          res[key] = cloneObj(element);
        } else {
          res[key] = element;
        }
      }
    }
  } else {
    res = obj;
  }
  return res;
};

function randomString(n) {
  var str = 'abcdefghijklmnopqrstuvwxyz9876543210';
  var tmp = '',
      i = 0,
      l = str.length;
  for (i = 0; i < n; i++) {
    tmp += str.charAt(Math.floor(Math.random() * l));
  }
  return tmp;
}

function deepEqual(x, y) {
  // 指向同一内存时
  if (x === y) {
    return true;
  } else if ((typeof x === 'undefined' ? 'undefined' : (0, _typeof3.default)(x)) == "object" && x != null && (typeof y === 'undefined' ? 'undefined' : (0, _typeof3.default)(y)) == "object" && y != null) {
    if ((0, _keys2.default)(x).length != (0, _keys2.default)(y).length) return false;

    for (var prop in x) {
      if (y.hasOwnProperty(prop)) {
        if (!deepEqual(x[prop], y[prop])) return false;
      } else return false;
    }

    return true;
  } else return false;
}

function getFullPath(fullPath, relativePath) {
  if (relativePath.startsWith('/')) return relativePath;
  var fullPathList = fullPath.split('/');
  var relativePathList = relativePath.split('/');
  fullPathList.pop();
  while (relativePathList[0] === '.' || relativePathList[0] === '..') {
    relativePathList[0] === '..' && fullPathList.pop();
    relativePathList.shift();
  }
  return fullPathList.concat(relativePathList).join('/');
}

// export default Object.assi{},{},pageEngine,htmlSuffix);
exports.default = (0, _extends3.default)({}, pageEngine, {
  isDevTools: isDevTools,
  addHtmlSuffixToUrl: addHtmlSuffixToUrl,
  removeHtmlSuffixFromUrl: removeHtmlSuffixFromUrl,
  cloneObj: cloneObj,
  randomString: randomString,
  deepEqual: deepEqual,
  getFullPath: getFullPath
});

/***/ }),
/* 108 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
var document = __webpack_require__(2).document;
// typeof document.createElement is 'object' in old IE
var is = isObject(document) && isObject(document.createElement);
module.exports = function (it) {
  return is ? document.createElement(it) : {};
};


/***/ }),
/* 109 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var core = __webpack_require__(24);
var LIBRARY = __webpack_require__(41);
var wksExt = __webpack_require__(157);
var defineProperty = __webpack_require__(9).f;
module.exports = function (name) {
  var $Symbol = core.Symbol || (core.Symbol = LIBRARY ? {} : global.Symbol || {});
  if (name.charAt(0) != '_' && !(name in $Symbol)) defineProperty($Symbol, name, { value: wksExt.f(name) });
};


/***/ }),
/* 110 */
/***/ (function(module, exports, __webpack_require__) {

var shared = __webpack_require__(68)('keys');
var uid = __webpack_require__(47);
module.exports = function (key) {
  return shared[key] || (shared[key] = uid(key));
};


/***/ }),
/* 111 */
/***/ (function(module, exports) {

// IE 8- don't enum bug keys
module.exports = (
  'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'
).split(',');


/***/ }),
/* 112 */
/***/ (function(module, exports, __webpack_require__) {

var document = __webpack_require__(2).document;
module.exports = document && document.documentElement;


/***/ }),
/* 113 */
/***/ (function(module, exports, __webpack_require__) {

// Works with __proto__ only. Old v8 can't work with null proto objects.
/* eslint-disable no-proto */
var isObject = __webpack_require__(4);
var anObject = __webpack_require__(1);
var check = function (O, proto) {
  anObject(O);
  if (!isObject(proto) && proto !== null) throw TypeError(proto + ": can't set as prototype!");
};
module.exports = {
  set: Object.setPrototypeOf || ('__proto__' in {} ? // eslint-disable-line
    function (test, buggy, set) {
      try {
        set = __webpack_require__(25)(Function.call, __webpack_require__(21).f(Object.prototype, '__proto__').set, 2);
        set(test, []);
        buggy = !(test instanceof Array);
      } catch (e) { buggy = true; }
      return function setPrototypeOf(O, proto) {
        check(O, proto);
        if (buggy) O.__proto__ = proto;
        else set(O, proto);
        return O;
      };
    }({}, false) : undefined),
  check: check
};


/***/ }),
/* 114 */
/***/ (function(module, exports) {

module.exports = '\x09\x0A\x0B\x0C\x0D\x20\xA0\u1680\u180E\u2000\u2001\u2002\u2003' +
  '\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF';


/***/ }),
/* 115 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
var setPrototypeOf = __webpack_require__(113).set;
module.exports = function (that, target, C) {
  var S = target.constructor;
  var P;
  if (S !== C && typeof S == 'function' && (P = S.prototype) !== C.prototype && isObject(P) && setPrototypeOf) {
    setPrototypeOf(that, P);
  } return that;
};


/***/ }),
/* 116 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var toInteger = __webpack_require__(27);
var defined = __webpack_require__(32);

module.exports = function repeat(count) {
  var str = String(defined(this));
  var res = '';
  var n = toInteger(count);
  if (n < 0 || n == Infinity) throw RangeError("Count can't be negative");
  for (;n > 0; (n >>>= 1) && (str += str)) if (n & 1) res += str;
  return res;
};


/***/ }),
/* 117 */
/***/ (function(module, exports) {

// 20.2.2.28 Math.sign(x)
module.exports = Math.sign || function sign(x) {
  // eslint-disable-next-line no-self-compare
  return (x = +x) == 0 || x != x ? x : x < 0 ? -1 : 1;
};


/***/ }),
/* 118 */
/***/ (function(module, exports) {

// 20.2.2.14 Math.expm1(x)
var $expm1 = Math.expm1;
module.exports = (!$expm1
  // Old FF bug
  || $expm1(10) > 22025.465794806719 || $expm1(10) < 22025.4657948067165168
  // Tor Browser bug
  || $expm1(-2e-17) != -2e-17
) ? function expm1(x) {
  return (x = +x) == 0 ? x : x > -1e-6 && x < 1e-6 ? x + x * x / 2 : Math.exp(x) - 1;
} : $expm1;


/***/ }),
/* 119 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var LIBRARY = __webpack_require__(41);
var $export = __webpack_require__(0);
var redefine = __webpack_require__(16);
var hide = __webpack_require__(15);
var Iterators = __webpack_require__(63);
var $iterCreate = __webpack_require__(120);
var setToStringTag = __webpack_require__(60);
var getPrototypeOf = __webpack_require__(22);
var ITERATOR = __webpack_require__(5)('iterator');
var BUGGY = !([].keys && 'next' in [].keys()); // Safari has buggy iterators w/o `next`
var FF_ITERATOR = '@@iterator';
var KEYS = 'keys';
var VALUES = 'values';

var returnThis = function () { return this; };

module.exports = function (Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED) {
  $iterCreate(Constructor, NAME, next);
  var getMethod = function (kind) {
    if (!BUGGY && kind in proto) return proto[kind];
    switch (kind) {
      case KEYS: return function keys() { return new Constructor(this, kind); };
      case VALUES: return function values() { return new Constructor(this, kind); };
    } return function entries() { return new Constructor(this, kind); };
  };
  var TAG = NAME + ' Iterator';
  var DEF_VALUES = DEFAULT == VALUES;
  var VALUES_BUG = false;
  var proto = Base.prototype;
  var $native = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT];
  var $default = $native || getMethod(DEFAULT);
  var $entries = DEFAULT ? !DEF_VALUES ? $default : getMethod('entries') : undefined;
  var $anyNative = NAME == 'Array' ? proto.entries || $native : $native;
  var methods, key, IteratorPrototype;
  // Fix native
  if ($anyNative) {
    IteratorPrototype = getPrototypeOf($anyNative.call(new Base()));
    if (IteratorPrototype !== Object.prototype && IteratorPrototype.next) {
      // Set @@toStringTag to native iterators
      setToStringTag(IteratorPrototype, TAG, true);
      // fix for some old engines
      if (!LIBRARY && typeof IteratorPrototype[ITERATOR] != 'function') hide(IteratorPrototype, ITERATOR, returnThis);
    }
  }
  // fix Array#{values, @@iterator}.name in V8 / FF
  if (DEF_VALUES && $native && $native.name !== VALUES) {
    VALUES_BUG = true;
    $default = function values() { return $native.call(this); };
  }
  // Define iterator
  if ((!LIBRARY || FORCED) && (BUGGY || VALUES_BUG || !proto[ITERATOR])) {
    hide(proto, ITERATOR, $default);
  }
  // Plug for library
  Iterators[NAME] = $default;
  Iterators[TAG] = returnThis;
  if (DEFAULT) {
    methods = {
      values: DEF_VALUES ? $default : getMethod(VALUES),
      keys: IS_SET ? $default : getMethod(KEYS),
      entries: $entries
    };
    if (FORCED) for (key in methods) {
      if (!(key in proto)) redefine(proto, key, methods[key]);
    } else $export($export.P + $export.F * (BUGGY || VALUES_BUG), NAME, methods);
  }
  return methods;
};


/***/ }),
/* 120 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var create = __webpack_require__(50);
var descriptor = __webpack_require__(46);
var setToStringTag = __webpack_require__(60);
var IteratorPrototype = {};

// 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
__webpack_require__(15)(IteratorPrototype, __webpack_require__(5)('iterator'), function () { return this; });

module.exports = function (Constructor, NAME, next) {
  Constructor.prototype = create(IteratorPrototype, { next: descriptor(1, next) });
  setToStringTag(Constructor, NAME + ' Iterator');
};


/***/ }),
/* 121 */
/***/ (function(module, exports, __webpack_require__) {

// helper for String#{startsWith, endsWith, includes}
var isRegExp = __webpack_require__(86);
var defined = __webpack_require__(32);

module.exports = function (that, searchString, NAME) {
  if (isRegExp(searchString)) throw TypeError('String#' + NAME + " doesn't accept regex!");
  return String(defined(that));
};


/***/ }),
/* 122 */
/***/ (function(module, exports, __webpack_require__) {

var MATCH = __webpack_require__(5)('match');
module.exports = function (KEY) {
  var re = /./;
  try {
    '/./'[KEY](re);
  } catch (e) {
    try {
      re[MATCH] = false;
      return !'/./'[KEY](re);
    } catch (f) { /* empty */ }
  } return true;
};


/***/ }),
/* 123 */
/***/ (function(module, exports, __webpack_require__) {

// check on default Array iterator
var Iterators = __webpack_require__(63);
var ITERATOR = __webpack_require__(5)('iterator');
var ArrayProto = Array.prototype;

module.exports = function (it) {
  return it !== undefined && (Iterators.Array === it || ArrayProto[ITERATOR] === it);
};


/***/ }),
/* 124 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $defineProperty = __webpack_require__(9);
var createDesc = __webpack_require__(46);

module.exports = function (object, index, value) {
  if (index in object) $defineProperty.f(object, index, createDesc(0, value));
  else object[index] = value;
};


/***/ }),
/* 125 */
/***/ (function(module, exports, __webpack_require__) {

var classof = __webpack_require__(61);
var ITERATOR = __webpack_require__(5)('iterator');
var Iterators = __webpack_require__(63);
module.exports = __webpack_require__(24).getIteratorMethod = function (it) {
  if (it != undefined) return it[ITERATOR]
    || it['@@iterator']
    || Iterators[classof(it)];
};


/***/ }),
/* 126 */
/***/ (function(module, exports, __webpack_require__) {

// 9.4.2.3 ArraySpeciesCreate(originalArray, length)
var speciesConstructor = __webpack_require__(320);

module.exports = function (original, length) {
  return new (speciesConstructor(original))(length);
};


/***/ }),
/* 127 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 22.1.3.6 Array.prototype.fill(value, start = 0, end = this.length)

var toObject = __webpack_require__(10);
var toAbsoluteIndex = __webpack_require__(49);
var toLength = __webpack_require__(6);
module.exports = function fill(value /* , start = 0, end = @length */) {
  var O = toObject(this);
  var length = toLength(O.length);
  var aLen = arguments.length;
  var index = toAbsoluteIndex(aLen > 1 ? arguments[1] : undefined, length);
  var end = aLen > 2 ? arguments[2] : undefined;
  var endPos = end === undefined ? length : toAbsoluteIndex(end, length);
  while (endPos > index) O[index++] = value;
  return O;
};


/***/ }),
/* 128 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var addToUnscopables = __webpack_require__(43);
var step = __webpack_require__(174);
var Iterators = __webpack_require__(63);
var toIObject = __webpack_require__(20);

// 22.1.3.4 Array.prototype.entries()
// 22.1.3.13 Array.prototype.keys()
// 22.1.3.29 Array.prototype.values()
// 22.1.3.30 Array.prototype[@@iterator]()
module.exports = __webpack_require__(119)(Array, 'Array', function (iterated, kind) {
  this._t = toIObject(iterated); // target
  this._i = 0;                   // next index
  this._k = kind;                // kind
// 22.1.5.2.1 %ArrayIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var kind = this._k;
  var index = this._i++;
  if (!O || index >= O.length) {
    this._t = undefined;
    return step(1);
  }
  if (kind == 'keys') return step(0, index);
  if (kind == 'values') return step(0, O[index]);
  return step(0, [index, O[index]]);
}, 'values');

// argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
Iterators.Arguments = Iterators.Array;

addToUnscopables('keys');
addToUnscopables('values');
addToUnscopables('entries');


/***/ }),
/* 129 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var regexpFlags = __webpack_require__(71);

var nativeExec = RegExp.prototype.exec;
// This always refers to the native implementation, because the
// String#replace polyfill uses ./fix-regexp-well-known-symbol-logic.js,
// which loads this file before patching the method.
var nativeReplace = String.prototype.replace;

var patchedExec = nativeExec;

var LAST_INDEX = 'lastIndex';

var UPDATES_LAST_INDEX_WRONG = (function () {
  var re1 = /a/,
      re2 = /b*/g;
  nativeExec.call(re1, 'a');
  nativeExec.call(re2, 'a');
  return re1[LAST_INDEX] !== 0 || re2[LAST_INDEX] !== 0;
})();

// nonparticipating capturing group, copied from es5-shim's String#split patch.
var NPCG_INCLUDED = /()??/.exec('')[1] !== undefined;

var PATCH = UPDATES_LAST_INDEX_WRONG || NPCG_INCLUDED;

if (PATCH) {
  patchedExec = function exec(str) {
    var re = this;
    var lastIndex, reCopy, match, i;

    if (NPCG_INCLUDED) {
      reCopy = new RegExp('^' + re.source + '$(?!\\s)', regexpFlags.call(re));
    }
    if (UPDATES_LAST_INDEX_WRONG) lastIndex = re[LAST_INDEX];

    match = nativeExec.call(re, str);

    if (UPDATES_LAST_INDEX_WRONG && match) {
      re[LAST_INDEX] = re.global ? match.index + match[0].length : lastIndex;
    }
    if (NPCG_INCLUDED && match && match.length > 1) {
      // Fix browsers whose `exec` methods don't consistently return `undefined`
      // for NPCG, like IE8. NOTE: This doesn' work for /(.?)?/
      // eslint-disable-next-line no-loop-func
      nativeReplace.call(match[0], reCopy, function () {
        for (i = 1; i < arguments.length - 2; i++) {
          if (arguments[i] === undefined) match[i] = undefined;
        }
      });
    }

    return match;
  };
}

module.exports = patchedExec;


/***/ }),
/* 130 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var at = __webpack_require__(85)(true);

 // `AdvanceStringIndex` abstract operation
// https://tc39.github.io/ecma262/#sec-advancestringindex
module.exports = function (S, index, unicode) {
  return index + (unicode ? at(S, index).length : 1);
};


/***/ }),
/* 131 */
/***/ (function(module, exports, __webpack_require__) {

var ctx = __webpack_require__(25);
var invoke = __webpack_require__(164);
var html = __webpack_require__(112);
var cel = __webpack_require__(108);
var global = __webpack_require__(2);
var process = global.process;
var setTask = global.setImmediate;
var clearTask = global.clearImmediate;
var MessageChannel = global.MessageChannel;
var Dispatch = global.Dispatch;
var counter = 0;
var queue = {};
var ONREADYSTATECHANGE = 'onreadystatechange';
var defer, channel, port;
var run = function () {
  var id = +this;
  // eslint-disable-next-line no-prototype-builtins
  if (queue.hasOwnProperty(id)) {
    var fn = queue[id];
    delete queue[id];
    fn();
  }
};
var listener = function (event) {
  run.call(event.data);
};
// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
if (!setTask || !clearTask) {
  setTask = function setImmediate(fn) {
    var args = [];
    var i = 1;
    while (arguments.length > i) args.push(arguments[i++]);
    queue[++counter] = function () {
      // eslint-disable-next-line no-new-func
      invoke(typeof fn == 'function' ? fn : Function(fn), args);
    };
    defer(counter);
    return counter;
  };
  clearTask = function clearImmediate(id) {
    delete queue[id];
  };
  // Node.js 0.8-
  if (__webpack_require__(26)(process) == 'process') {
    defer = function (id) {
      process.nextTick(ctx(run, id, 1));
    };
  // Sphere (JS game engine) Dispatch API
  } else if (Dispatch && Dispatch.now) {
    defer = function (id) {
      Dispatch.now(ctx(run, id, 1));
    };
  // Browsers with MessageChannel, includes WebWorkers
  } else if (MessageChannel) {
    channel = new MessageChannel();
    port = channel.port2;
    channel.port1.onmessage = listener;
    defer = ctx(port.postMessage, port, 1);
  // Browsers with postMessage, skip WebWorkers
  // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
  } else if (global.addEventListener && typeof postMessage == 'function' && !global.importScripts) {
    defer = function (id) {
      global.postMessage(id + '', '*');
    };
    global.addEventListener('message', listener, false);
  // IE8-
  } else if (ONREADYSTATECHANGE in cel('script')) {
    defer = function (id) {
      html.appendChild(cel('script'))[ONREADYSTATECHANGE] = function () {
        html.removeChild(this);
        run.call(id);
      };
    };
  // Rest old browsers
  } else {
    defer = function (id) {
      setTimeout(ctx(run, id, 1), 0);
    };
  }
}
module.exports = {
  set: setTask,
  clear: clearTask
};


/***/ }),
/* 132 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var macrotask = __webpack_require__(131).set;
var Observer = global.MutationObserver || global.WebKitMutationObserver;
var process = global.process;
var Promise = global.Promise;
var isNode = __webpack_require__(26)(process) == 'process';

module.exports = function () {
  var head, last, notify;

  var flush = function () {
    var parent, fn;
    if (isNode && (parent = process.domain)) parent.exit();
    while (head) {
      fn = head.fn;
      head = head.next;
      try {
        fn();
      } catch (e) {
        if (head) notify();
        else last = undefined;
        throw e;
      }
    } last = undefined;
    if (parent) parent.enter();
  };

  // Node.js
  if (isNode) {
    notify = function () {
      process.nextTick(flush);
    };
  // browsers with MutationObserver, except iOS Safari - https://github.com/zloirock/core-js/issues/339
  } else if (Observer && !(global.navigator && global.navigator.standalone)) {
    var toggle = true;
    var node = document.createTextNode('');
    new Observer(flush).observe(node, { characterData: true }); // eslint-disable-line no-new
    notify = function () {
      node.data = toggle = !toggle;
    };
  // environments with maybe non-completely correct, but existent Promise
  } else if (Promise && Promise.resolve) {
    // Promise.resolve without an argument throws an error in LG WebOS 2
    var promise = Promise.resolve(undefined);
    notify = function () {
      promise.then(flush);
    };
  // for other environments - macrotask based on:
  // - setImmediate
  // - MessageChannel
  // - window.postMessag
  // - onreadystatechange
  // - setTimeout
  } else {
    notify = function () {
      // strange IE + webpack dev server bug - use .call(global)
      macrotask.call(global, flush);
    };
  }

  return function (fn) {
    var task = { fn: fn, next: undefined };
    if (last) last.next = task;
    if (!head) {
      head = task;
      notify();
    } last = task;
  };
};


/***/ }),
/* 133 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 25.4.1.5 NewPromiseCapability(C)
var aFunction = __webpack_require__(11);

function PromiseCapability(C) {
  var resolve, reject;
  this.promise = new C(function ($$resolve, $$reject) {
    if (resolve !== undefined || reject !== undefined) throw TypeError('Bad Promise constructor');
    resolve = $$resolve;
    reject = $$reject;
  });
  this.resolve = aFunction(resolve);
  this.reject = aFunction(reject);
}

module.exports.f = function (C) {
  return new PromiseCapability(C);
};


/***/ }),
/* 134 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(2);
var DESCRIPTORS = __webpack_require__(8);
var LIBRARY = __webpack_require__(41);
var $typed = __webpack_require__(92);
var hide = __webpack_require__(15);
var redefineAll = __webpack_require__(55);
var fails = __webpack_require__(3);
var anInstance = __webpack_require__(53);
var toInteger = __webpack_require__(27);
var toLength = __webpack_require__(6);
var toIndex = __webpack_require__(184);
var gOPN = __webpack_require__(51).f;
var dP = __webpack_require__(9).f;
var arrayFill = __webpack_require__(127);
var setToStringTag = __webpack_require__(60);
var ARRAY_BUFFER = 'ArrayBuffer';
var DATA_VIEW = 'DataView';
var PROTOTYPE = 'prototype';
var WRONG_LENGTH = 'Wrong length!';
var WRONG_INDEX = 'Wrong index!';
var $ArrayBuffer = global[ARRAY_BUFFER];
var $DataView = global[DATA_VIEW];
var Math = global.Math;
var RangeError = global.RangeError;
// eslint-disable-next-line no-shadow-restricted-names
var Infinity = global.Infinity;
var BaseBuffer = $ArrayBuffer;
var abs = Math.abs;
var pow = Math.pow;
var floor = Math.floor;
var log = Math.log;
var LN2 = Math.LN2;
var BUFFER = 'buffer';
var BYTE_LENGTH = 'byteLength';
var BYTE_OFFSET = 'byteOffset';
var $BUFFER = DESCRIPTORS ? '_b' : BUFFER;
var $LENGTH = DESCRIPTORS ? '_l' : BYTE_LENGTH;
var $OFFSET = DESCRIPTORS ? '_o' : BYTE_OFFSET;

// IEEE754 conversions based on https://github.com/feross/ieee754
function packIEEE754(value, mLen, nBytes) {
  var buffer = new Array(nBytes);
  var eLen = nBytes * 8 - mLen - 1;
  var eMax = (1 << eLen) - 1;
  var eBias = eMax >> 1;
  var rt = mLen === 23 ? pow(2, -24) - pow(2, -77) : 0;
  var i = 0;
  var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
  var e, m, c;
  value = abs(value);
  // eslint-disable-next-line no-self-compare
  if (value != value || value === Infinity) {
    // eslint-disable-next-line no-self-compare
    m = value != value ? 1 : 0;
    e = eMax;
  } else {
    e = floor(log(value) / LN2);
    if (value * (c = pow(2, -e)) < 1) {
      e--;
      c *= 2;
    }
    if (e + eBias >= 1) {
      value += rt / c;
    } else {
      value += rt * pow(2, 1 - eBias);
    }
    if (value * c >= 2) {
      e++;
      c /= 2;
    }
    if (e + eBias >= eMax) {
      m = 0;
      e = eMax;
    } else if (e + eBias >= 1) {
      m = (value * c - 1) * pow(2, mLen);
      e = e + eBias;
    } else {
      m = value * pow(2, eBias - 1) * pow(2, mLen);
      e = 0;
    }
  }
  for (; mLen >= 8; buffer[i++] = m & 255, m /= 256, mLen -= 8);
  e = e << mLen | m;
  eLen += mLen;
  for (; eLen > 0; buffer[i++] = e & 255, e /= 256, eLen -= 8);
  buffer[--i] |= s * 128;
  return buffer;
}
function unpackIEEE754(buffer, mLen, nBytes) {
  var eLen = nBytes * 8 - mLen - 1;
  var eMax = (1 << eLen) - 1;
  var eBias = eMax >> 1;
  var nBits = eLen - 7;
  var i = nBytes - 1;
  var s = buffer[i--];
  var e = s & 127;
  var m;
  s >>= 7;
  for (; nBits > 0; e = e * 256 + buffer[i], i--, nBits -= 8);
  m = e & (1 << -nBits) - 1;
  e >>= -nBits;
  nBits += mLen;
  for (; nBits > 0; m = m * 256 + buffer[i], i--, nBits -= 8);
  if (e === 0) {
    e = 1 - eBias;
  } else if (e === eMax) {
    return m ? NaN : s ? -Infinity : Infinity;
  } else {
    m = m + pow(2, mLen);
    e = e - eBias;
  } return (s ? -1 : 1) * m * pow(2, e - mLen);
}

function unpackI32(bytes) {
  return bytes[3] << 24 | bytes[2] << 16 | bytes[1] << 8 | bytes[0];
}
function packI8(it) {
  return [it & 0xff];
}
function packI16(it) {
  return [it & 0xff, it >> 8 & 0xff];
}
function packI32(it) {
  return [it & 0xff, it >> 8 & 0xff, it >> 16 & 0xff, it >> 24 & 0xff];
}
function packF64(it) {
  return packIEEE754(it, 52, 8);
}
function packF32(it) {
  return packIEEE754(it, 23, 4);
}

function addGetter(C, key, internal) {
  dP(C[PROTOTYPE], key, { get: function () { return this[internal]; } });
}

function get(view, bytes, index, isLittleEndian) {
  var numIndex = +index;
  var intIndex = toIndex(numIndex);
  if (intIndex + bytes > view[$LENGTH]) throw RangeError(WRONG_INDEX);
  var store = view[$BUFFER]._b;
  var start = intIndex + view[$OFFSET];
  var pack = store.slice(start, start + bytes);
  return isLittleEndian ? pack : pack.reverse();
}
function set(view, bytes, index, conversion, value, isLittleEndian) {
  var numIndex = +index;
  var intIndex = toIndex(numIndex);
  if (intIndex + bytes > view[$LENGTH]) throw RangeError(WRONG_INDEX);
  var store = view[$BUFFER]._b;
  var start = intIndex + view[$OFFSET];
  var pack = conversion(+value);
  for (var i = 0; i < bytes; i++) store[start + i] = pack[isLittleEndian ? i : bytes - i - 1];
}

if (!$typed.ABV) {
  $ArrayBuffer = function ArrayBuffer(length) {
    anInstance(this, $ArrayBuffer, ARRAY_BUFFER);
    var byteLength = toIndex(length);
    this._b = arrayFill.call(new Array(byteLength), 0);
    this[$LENGTH] = byteLength;
  };

  $DataView = function DataView(buffer, byteOffset, byteLength) {
    anInstance(this, $DataView, DATA_VIEW);
    anInstance(buffer, $ArrayBuffer, DATA_VIEW);
    var bufferLength = buffer[$LENGTH];
    var offset = toInteger(byteOffset);
    if (offset < 0 || offset > bufferLength) throw RangeError('Wrong offset!');
    byteLength = byteLength === undefined ? bufferLength - offset : toLength(byteLength);
    if (offset + byteLength > bufferLength) throw RangeError(WRONG_LENGTH);
    this[$BUFFER] = buffer;
    this[$OFFSET] = offset;
    this[$LENGTH] = byteLength;
  };

  if (DESCRIPTORS) {
    addGetter($ArrayBuffer, BYTE_LENGTH, '_l');
    addGetter($DataView, BUFFER, '_b');
    addGetter($DataView, BYTE_LENGTH, '_l');
    addGetter($DataView, BYTE_OFFSET, '_o');
  }

  redefineAll($DataView[PROTOTYPE], {
    getInt8: function getInt8(byteOffset) {
      return get(this, 1, byteOffset)[0] << 24 >> 24;
    },
    getUint8: function getUint8(byteOffset) {
      return get(this, 1, byteOffset)[0];
    },
    getInt16: function getInt16(byteOffset /* , littleEndian */) {
      var bytes = get(this, 2, byteOffset, arguments[1]);
      return (bytes[1] << 8 | bytes[0]) << 16 >> 16;
    },
    getUint16: function getUint16(byteOffset /* , littleEndian */) {
      var bytes = get(this, 2, byteOffset, arguments[1]);
      return bytes[1] << 8 | bytes[0];
    },
    getInt32: function getInt32(byteOffset /* , littleEndian */) {
      return unpackI32(get(this, 4, byteOffset, arguments[1]));
    },
    getUint32: function getUint32(byteOffset /* , littleEndian */) {
      return unpackI32(get(this, 4, byteOffset, arguments[1])) >>> 0;
    },
    getFloat32: function getFloat32(byteOffset /* , littleEndian */) {
      return unpackIEEE754(get(this, 4, byteOffset, arguments[1]), 23, 4);
    },
    getFloat64: function getFloat64(byteOffset /* , littleEndian */) {
      return unpackIEEE754(get(this, 8, byteOffset, arguments[1]), 52, 8);
    },
    setInt8: function setInt8(byteOffset, value) {
      set(this, 1, byteOffset, packI8, value);
    },
    setUint8: function setUint8(byteOffset, value) {
      set(this, 1, byteOffset, packI8, value);
    },
    setInt16: function setInt16(byteOffset, value /* , littleEndian */) {
      set(this, 2, byteOffset, packI16, value, arguments[2]);
    },
    setUint16: function setUint16(byteOffset, value /* , littleEndian */) {
      set(this, 2, byteOffset, packI16, value, arguments[2]);
    },
    setInt32: function setInt32(byteOffset, value /* , littleEndian */) {
      set(this, 4, byteOffset, packI32, value, arguments[2]);
    },
    setUint32: function setUint32(byteOffset, value /* , littleEndian */) {
      set(this, 4, byteOffset, packI32, value, arguments[2]);
    },
    setFloat32: function setFloat32(byteOffset, value /* , littleEndian */) {
      set(this, 4, byteOffset, packF32, value, arguments[2]);
    },
    setFloat64: function setFloat64(byteOffset, value /* , littleEndian */) {
      set(this, 8, byteOffset, packF64, value, arguments[2]);
    }
  });
} else {
  if (!fails(function () {
    $ArrayBuffer(1);
  }) || !fails(function () {
    new $ArrayBuffer(-1); // eslint-disable-line no-new
  }) || fails(function () {
    new $ArrayBuffer(); // eslint-disable-line no-new
    new $ArrayBuffer(1.5); // eslint-disable-line no-new
    new $ArrayBuffer(NaN); // eslint-disable-line no-new
    return $ArrayBuffer.name != ARRAY_BUFFER;
  })) {
    $ArrayBuffer = function ArrayBuffer(length) {
      anInstance(this, $ArrayBuffer);
      return new BaseBuffer(toIndex(length));
    };
    var ArrayBufferProto = $ArrayBuffer[PROTOTYPE] = BaseBuffer[PROTOTYPE];
    for (var keys = gOPN(BaseBuffer), j = 0, key; keys.length > j;) {
      if (!((key = keys[j++]) in $ArrayBuffer)) hide($ArrayBuffer, key, BaseBuffer[key]);
    }
    if (!LIBRARY) ArrayBufferProto.constructor = $ArrayBuffer;
  }
  // iOS Safari 7.x bug
  var view = new $DataView(new $ArrayBuffer(2));
  var $setInt8 = $DataView[PROTOTYPE].setInt8;
  view.setInt8(0, 2147483648);
  view.setInt8(1, 2147483649);
  if (view.getInt8(0) || !view.getInt8(1)) redefineAll($DataView[PROTOTYPE], {
    setInt8: function setInt8(byteOffset, value) {
      $setInt8.call(this, byteOffset, value << 24 >> 24);
    },
    setUint8: function setUint8(byteOffset, value) {
      $setInt8.call(this, byteOffset, value << 24 >> 24);
    }
  }, true);
}
setToStringTag($ArrayBuffer, ARRAY_BUFFER);
setToStringTag($DataView, DATA_VIEW);
hide($DataView[PROTOTYPE], $typed.VIEW, true);
exports[ARRAY_BUFFER] = $ArrayBuffer;
exports[DATA_VIEW] = $DataView;


/***/ }),
/* 135 */
/***/ (function(module, exports) {

// 7.2.1 RequireObjectCoercible(argument)
module.exports = function (it) {
  if (it == undefined) throw TypeError("Can't call method on  " + it);
  return it;
};


/***/ }),
/* 136 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.15 ToLength
var toInteger = __webpack_require__(137);
var min = Math.min;
module.exports = function (it) {
  return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
};


/***/ }),
/* 137 */
/***/ (function(module, exports) {

// 7.1.4 ToInteger
var ceil = Math.ceil;
var floor = Math.floor;
module.exports = function (it) {
  return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
};


/***/ }),
/* 138 */
/***/ (function(module, exports, __webpack_require__) {

var shared = __webpack_require__(139)('keys');
var uid = __webpack_require__(96);
module.exports = function (key) {
  return shared[key] || (shared[key] = uid(key));
};


/***/ }),
/* 139 */
/***/ (function(module, exports, __webpack_require__) {

var core = __webpack_require__(7);
var global = __webpack_require__(12);
var SHARED = '__core-js_shared__';
var store = global[SHARED] || (global[SHARED] = {});

(module.exports = function (key, value) {
  return store[key] || (store[key] = value !== undefined ? value : {});
})('versions', []).push({
  version: core.version,
  mode: __webpack_require__(76) ? 'pure' : 'global',
  copyright: '© 2019 Denis Pushkarev (zloirock.ru)'
});


/***/ }),
/* 140 */
/***/ (function(module, exports) {

// IE 8- don't enum bug keys
module.exports = (
  'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'
).split(',');


/***/ }),
/* 141 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(44);
var document = __webpack_require__(12).document;
// typeof document.createElement is 'object' in old IE
var is = isObject(document) && isObject(document.createElement);
module.exports = function (it) {
  return is ? document.createElement(it) : {};
};


/***/ }),
/* 142 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.1 ToPrimitive(input [, PreferredType])
var isObject = __webpack_require__(44);
// instead of the ES6 spec version, we didn't implement @@toPrimitive case
// and the second argument - flag - preferred type is a string
module.exports = function (it, S) {
  if (!isObject(it)) return it;
  var fn, val;
  if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
  if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  throw TypeError("Can't convert object to primitive value");
};


/***/ }),
/* 143 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
var anObject = __webpack_require__(35);
var dPs = __webpack_require__(442);
var enumBugKeys = __webpack_require__(140);
var IE_PROTO = __webpack_require__(138)('IE_PROTO');
var Empty = function () { /* empty */ };
var PROTOTYPE = 'prototype';

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var createDict = function () {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = __webpack_require__(141)('iframe');
  var i = enumBugKeys.length;
  var lt = '<';
  var gt = '>';
  var iframeDocument;
  iframe.style.display = 'none';
  __webpack_require__(198).appendChild(iframe);
  iframe.src = 'javascript:'; // eslint-disable-line no-script-url
  // createDict = iframe.contentWindow.Object;
  // html.removeChild(iframe);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
  iframeDocument.close();
  createDict = iframeDocument.F;
  while (i--) delete createDict[PROTOTYPE][enumBugKeys[i]];
  return createDict();
};

module.exports = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    Empty[PROTOTYPE] = anObject(O);
    result = new Empty();
    Empty[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = createDict();
  return Properties === undefined ? result : dPs(result, Properties);
};


/***/ }),
/* 144 */
/***/ (function(module, exports, __webpack_require__) {

exports.f = __webpack_require__(14);


/***/ }),
/* 145 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(12);
var core = __webpack_require__(7);
var LIBRARY = __webpack_require__(76);
var wksExt = __webpack_require__(144);
var defineProperty = __webpack_require__(40).f;
module.exports = function (name) {
  var $Symbol = core.Symbol || (core.Symbol = LIBRARY ? {} : global.Symbol || {});
  if (name.charAt(0) != '_' && !(name in $Symbol)) defineProperty($Symbol, name, { value: wksExt.f(name) });
};


/***/ }),
/* 146 */
/***/ (function(module, exports) {

exports.f = Object.getOwnPropertySymbols;


/***/ }),
/* 147 */
/***/ (function(module, exports, __webpack_require__) {

var classof = __webpack_require__(154);
var ITERATOR = __webpack_require__(14)('iterator');
var Iterators = __webpack_require__(67);
module.exports = __webpack_require__(7).getIteratorMethod = function (it) {
  if (it != undefined) return it[ITERATOR]
    || it['@@iterator']
    || Iterators[classof(it)];
};


/***/ }),
/* 148 */,
/* 149 */
/***/ (function(module, exports, __webpack_require__) {

var ctx = __webpack_require__(64);
var invoke = __webpack_require__(474);
var html = __webpack_require__(198);
var cel = __webpack_require__(141);
var global = __webpack_require__(12);
var process = global.process;
var setTask = global.setImmediate;
var clearTask = global.clearImmediate;
var MessageChannel = global.MessageChannel;
var Dispatch = global.Dispatch;
var counter = 0;
var queue = {};
var ONREADYSTATECHANGE = 'onreadystatechange';
var defer, channel, port;
var run = function () {
  var id = +this;
  // eslint-disable-next-line no-prototype-builtins
  if (queue.hasOwnProperty(id)) {
    var fn = queue[id];
    delete queue[id];
    fn();
  }
};
var listener = function (event) {
  run.call(event.data);
};
// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
if (!setTask || !clearTask) {
  setTask = function setImmediate(fn) {
    var args = [];
    var i = 1;
    while (arguments.length > i) args.push(arguments[i++]);
    queue[++counter] = function () {
      // eslint-disable-next-line no-new-func
      invoke(typeof fn == 'function' ? fn : Function(fn), args);
    };
    defer(counter);
    return counter;
  };
  clearTask = function clearImmediate(id) {
    delete queue[id];
  };
  // Node.js 0.8-
  if (__webpack_require__(75)(process) == 'process') {
    defer = function (id) {
      process.nextTick(ctx(run, id, 1));
    };
  // Sphere (JS game engine) Dispatch API
  } else if (Dispatch && Dispatch.now) {
    defer = function (id) {
      Dispatch.now(ctx(run, id, 1));
    };
  // Browsers with MessageChannel, includes WebWorkers
  } else if (MessageChannel) {
    channel = new MessageChannel();
    port = channel.port2;
    channel.port1.onmessage = listener;
    defer = ctx(port.postMessage, port, 1);
  // Browsers with postMessage, skip WebWorkers
  // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
  } else if (global.addEventListener && typeof postMessage == 'function' && !global.importScripts) {
    defer = function (id) {
      global.postMessage(id + '', '*');
    };
    global.addEventListener('message', listener, false);
  // IE8-
  } else if (ONREADYSTATECHANGE in cel('script')) {
    defer = function (id) {
      html.appendChild(cel('script'))[ONREADYSTATECHANGE] = function () {
        html.removeChild(this);
        run.call(id);
      };
    };
  // Rest old browsers
  } else {
    defer = function (id) {
      setTimeout(ctx(run, id, 1), 0);
    };
  }
}
module.exports = {
  set: setTask,
  clear: clearTask
};


/***/ }),
/* 150 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 25.4.1.5 NewPromiseCapability(C)
var aFunction = __webpack_require__(97);

function PromiseCapability(C) {
  var resolve, reject;
  this.promise = new C(function ($$resolve, $$reject) {
    if (resolve !== undefined || reject !== undefined) throw TypeError('Bad Promise constructor');
    resolve = $$resolve;
    reject = $$reject;
  });
  this.resolve = aFunction(resolve);
  this.reject = aFunction(reject);
}

module.exports.f = function (C) {
  return new PromiseCapability(C);
};


/***/ }),
/* 151 */
/***/ (function(module, exports, __webpack_require__) {


/**
 * Expose `Emitter`.
 */

if (true) {
  module.exports = Emitter;
}

/**
 * Initialize a new `Emitter`.
 *
 * @api public
 */

function Emitter(obj) {
  if (obj) return mixin(obj);
};

/**
 * Mixin the emitter properties.
 *
 * @param {Object} obj
 * @return {Object}
 * @api private
 */

function mixin(obj) {
  for (var key in Emitter.prototype) {
    obj[key] = Emitter.prototype[key];
  }
  return obj;
}

/**
 * Listen on the given `event` with `fn`.
 *
 * @param {String} event
 * @param {Function} fn
 * @return {Emitter}
 * @api public
 */

Emitter.prototype.on =
Emitter.prototype.addEventListener = function(event, fn){
  this._callbacks = this._callbacks || {};
  (this._callbacks['$' + event] = this._callbacks['$' + event] || [])
    .push(fn);
  return this;
};

/**
 * Adds an `event` listener that will be invoked a single
 * time then automatically removed.
 *
 * @param {String} event
 * @param {Function} fn
 * @return {Emitter}
 * @api public
 */

Emitter.prototype.once = function(event, fn){
  function on() {
    this.off(event, on);
    fn.apply(this, arguments);
  }

  on.fn = fn;
  this.on(event, on);
  return this;
};

/**
 * Remove the given callback for `event` or all
 * registered callbacks.
 *
 * @param {String} event
 * @param {Function} fn
 * @return {Emitter}
 * @api public
 */

Emitter.prototype.off =
Emitter.prototype.removeListener =
Emitter.prototype.removeAllListeners =
Emitter.prototype.removeEventListener = function(event, fn){
  this._callbacks = this._callbacks || {};

  // all
  if (0 == arguments.length) {
    this._callbacks = {};
    return this;
  }

  // specific event
  var callbacks = this._callbacks['$' + event];
  if (!callbacks) return this;

  // remove all handlers
  if (1 == arguments.length) {
    delete this._callbacks['$' + event];
    return this;
  }

  // remove specific handler
  var cb;
  for (var i = 0; i < callbacks.length; i++) {
    cb = callbacks[i];
    if (cb === fn || cb.fn === fn) {
      callbacks.splice(i, 1);
      break;
    }
  }

  // Remove event specific arrays for event types that no
  // one is subscribed for to avoid memory leak.
  if (callbacks.length === 0) {
    delete this._callbacks['$' + event];
  }

  return this;
};

/**
 * Emit `event` with the given args.
 *
 * @param {String} event
 * @param {Mixed} ...
 * @return {Emitter}
 */

Emitter.prototype.emit = function(event){
  this._callbacks = this._callbacks || {};

  var args = new Array(arguments.length - 1)
    , callbacks = this._callbacks['$' + event];

  for (var i = 1; i < arguments.length; i++) {
    args[i - 1] = arguments[i];
  }

  if (callbacks) {
    callbacks = callbacks.slice(0);
    for (var i = 0, len = callbacks.length; i < len; ++i) {
      callbacks[i].apply(this, args);
    }
  }

  return this;
};

/**
 * Return array of callbacks for `event`.
 *
 * @param {String} event
 * @return {Array}
 * @api public
 */

Emitter.prototype.listeners = function(event){
  this._callbacks = this._callbacks || {};
  return this._callbacks['$' + event] || [];
};

/**
 * Check if this emitter has `event` handlers.
 *
 * @param {String} event
 * @return {Boolean}
 * @api public
 */

Emitter.prototype.hasListeners = function(event){
  return !! this.listeners(event).length;
};


/***/ }),
/* 152 */
/***/ (function(module, exports, __webpack_require__) {

// most Object methods by ES6 should accept primitives
var $export = __webpack_require__(18);
var core = __webpack_require__(7);
var fails = __webpack_require__(65);
module.exports = function (KEY, exec) {
  var fn = (core.Object || {})[KEY] || Object[KEY];
  var exp = {};
  exp[KEY] = exec(fn);
  $export($export.S + $export.F * fails(function () { fn(1); }), 'Object', exp);
};


/***/ }),
/* 153 */
/***/ (function(module, exports, __webpack_require__) {

var pIE = __webpack_require__(100);
var createDesc = __webpack_require__(77);
var toIObject = __webpack_require__(59);
var toPrimitive = __webpack_require__(142);
var has = __webpack_require__(57);
var IE8_DOM_DEFINE = __webpack_require__(194);
var gOPD = Object.getOwnPropertyDescriptor;

exports.f = __webpack_require__(45) ? gOPD : function getOwnPropertyDescriptor(O, P) {
  O = toIObject(O);
  P = toPrimitive(P, true);
  if (IE8_DOM_DEFINE) try {
    return gOPD(O, P);
  } catch (e) { /* empty */ }
  if (has(O, P)) return createDesc(!pIE.f.call(O, P), O[P]);
};


/***/ }),
/* 154 */
/***/ (function(module, exports, __webpack_require__) {

// getting tag from 19.1.3.6 Object.prototype.toString()
var cof = __webpack_require__(75);
var TAG = __webpack_require__(14)('toStringTag');
// ES3 wrong here
var ARG = cof(function () { return arguments; }()) == 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function (it, key) {
  try {
    return it[key];
  } catch (e) { /* empty */ }
};

module.exports = function (it) {
  var O, T, B;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
    // @@toStringTag case
    : typeof (T = tryGet(O = Object(it), TAG)) == 'string' ? T
    // builtinTag case
    : ARG ? cof(O)
    // ES3 arguments fallback
    : (B = cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
};


/***/ }),
/* 155 */,
/* 156 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = !__webpack_require__(8) && !__webpack_require__(3)(function () {
  return Object.defineProperty(__webpack_require__(108)('div'), 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),
/* 157 */
/***/ (function(module, exports, __webpack_require__) {

exports.f = __webpack_require__(5);


/***/ }),
/* 158 */
/***/ (function(module, exports, __webpack_require__) {

var has = __webpack_require__(19);
var toIObject = __webpack_require__(20);
var arrayIndexOf = __webpack_require__(82)(false);
var IE_PROTO = __webpack_require__(110)('IE_PROTO');

module.exports = function (object, names) {
  var O = toIObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) if (key != IE_PROTO) has(O, key) && result.push(key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (has(O, key = names[i++])) {
    ~arrayIndexOf(result, key) || result.push(key);
  }
  return result;
};


/***/ }),
/* 159 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(9);
var anObject = __webpack_require__(1);
var getKeys = __webpack_require__(48);

module.exports = __webpack_require__(8) ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var keys = getKeys(Properties);
  var length = keys.length;
  var i = 0;
  var P;
  while (length > i) dP.f(O, P = keys[i++], Properties[P]);
  return O;
};


/***/ }),
/* 160 */
/***/ (function(module, exports, __webpack_require__) {

// fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
var toIObject = __webpack_require__(20);
var gOPN = __webpack_require__(51).f;
var toString = {}.toString;

var windowNames = typeof window == 'object' && window && Object.getOwnPropertyNames
  ? Object.getOwnPropertyNames(window) : [];

var getWindowNames = function (it) {
  try {
    return gOPN(it);
  } catch (e) {
    return windowNames.slice();
  }
};

module.exports.f = function getOwnPropertyNames(it) {
  return windowNames && toString.call(it) == '[object Window]' ? getWindowNames(it) : gOPN(toIObject(it));
};


/***/ }),
/* 161 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 19.1.2.1 Object.assign(target, source, ...)
var getKeys = __webpack_require__(48);
var gOPS = __webpack_require__(83);
var pIE = __webpack_require__(70);
var toObject = __webpack_require__(10);
var IObject = __webpack_require__(69);
var $assign = Object.assign;

// should work with symbols and should have deterministic property order (V8 bug)
module.exports = !$assign || __webpack_require__(3)(function () {
  var A = {};
  var B = {};
  // eslint-disable-next-line no-undef
  var S = Symbol();
  var K = 'abcdefghijklmnopqrst';
  A[S] = 7;
  K.split('').forEach(function (k) { B[k] = k; });
  return $assign({}, A)[S] != 7 || Object.keys($assign({}, B)).join('') != K;
}) ? function assign(target, source) { // eslint-disable-line no-unused-vars
  var T = toObject(target);
  var aLen = arguments.length;
  var index = 1;
  var getSymbols = gOPS.f;
  var isEnum = pIE.f;
  while (aLen > index) {
    var S = IObject(arguments[index++]);
    var keys = getSymbols ? getKeys(S).concat(getSymbols(S)) : getKeys(S);
    var length = keys.length;
    var j = 0;
    var key;
    while (length > j) if (isEnum.call(S, key = keys[j++])) T[key] = S[key];
  } return T;
} : $assign;


/***/ }),
/* 162 */
/***/ (function(module, exports) {

// 7.2.9 SameValue(x, y)
module.exports = Object.is || function is(x, y) {
  // eslint-disable-next-line no-self-compare
  return x === y ? x !== 0 || 1 / x === 1 / y : x != x && y != y;
};


/***/ }),
/* 163 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var aFunction = __webpack_require__(11);
var isObject = __webpack_require__(4);
var invoke = __webpack_require__(164);
var arraySlice = [].slice;
var factories = {};

var construct = function (F, len, args) {
  if (!(len in factories)) {
    for (var n = [], i = 0; i < len; i++) n[i] = 'a[' + i + ']';
    // eslint-disable-next-line no-new-func
    factories[len] = Function('F,a', 'return new F(' + n.join(',') + ')');
  } return factories[len](F, args);
};

module.exports = Function.bind || function bind(that /* , ...args */) {
  var fn = aFunction(this);
  var partArgs = arraySlice.call(arguments, 1);
  var bound = function (/* args... */) {
    var args = partArgs.concat(arraySlice.call(arguments));
    return this instanceof bound ? construct(fn, args.length, args) : invoke(fn, args, that);
  };
  if (isObject(fn.prototype)) bound.prototype = fn.prototype;
  return bound;
};


/***/ }),
/* 164 */
/***/ (function(module, exports) {

// fast apply, http://jsperf.lnkit.com/fast-apply/5
module.exports = function (fn, args, that) {
  var un = that === undefined;
  switch (args.length) {
    case 0: return un ? fn()
                      : fn.call(that);
    case 1: return un ? fn(args[0])
                      : fn.call(that, args[0]);
    case 2: return un ? fn(args[0], args[1])
                      : fn.call(that, args[0], args[1]);
    case 3: return un ? fn(args[0], args[1], args[2])
                      : fn.call(that, args[0], args[1], args[2]);
    case 4: return un ? fn(args[0], args[1], args[2], args[3])
                      : fn.call(that, args[0], args[1], args[2], args[3]);
  } return fn.apply(that, args);
};


/***/ }),
/* 165 */
/***/ (function(module, exports, __webpack_require__) {

var $parseInt = __webpack_require__(2).parseInt;
var $trim = __webpack_require__(62).trim;
var ws = __webpack_require__(114);
var hex = /^[-+]?0[xX]/;

module.exports = $parseInt(ws + '08') !== 8 || $parseInt(ws + '0x16') !== 22 ? function parseInt(str, radix) {
  var string = $trim(String(str), 3);
  return $parseInt(string, (radix >>> 0) || (hex.test(string) ? 16 : 10));
} : $parseInt;


/***/ }),
/* 166 */
/***/ (function(module, exports, __webpack_require__) {

var $parseFloat = __webpack_require__(2).parseFloat;
var $trim = __webpack_require__(62).trim;

module.exports = 1 / $parseFloat(__webpack_require__(114) + '-0') !== -Infinity ? function parseFloat(str) {
  var string = $trim(String(str), 3);
  var result = $parseFloat(string);
  return result === 0 && string.charAt(0) == '-' ? -0 : result;
} : $parseFloat;


/***/ }),
/* 167 */
/***/ (function(module, exports, __webpack_require__) {

var cof = __webpack_require__(26);
module.exports = function (it, msg) {
  if (typeof it != 'number' && cof(it) != 'Number') throw TypeError(msg);
  return +it;
};


/***/ }),
/* 168 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.3 Number.isInteger(number)
var isObject = __webpack_require__(4);
var floor = Math.floor;
module.exports = function isInteger(it) {
  return !isObject(it) && isFinite(it) && floor(it) === it;
};


/***/ }),
/* 169 */
/***/ (function(module, exports) {

// 20.2.2.20 Math.log1p(x)
module.exports = Math.log1p || function log1p(x) {
  return (x = +x) > -1e-8 && x < 1e-8 ? x - x * x / 2 : Math.log(1 + x);
};


/***/ }),
/* 170 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.16 Math.fround(x)
var sign = __webpack_require__(117);
var pow = Math.pow;
var EPSILON = pow(2, -52);
var EPSILON32 = pow(2, -23);
var MAX32 = pow(2, 127) * (2 - EPSILON32);
var MIN32 = pow(2, -126);

var roundTiesToEven = function (n) {
  return n + 1 / EPSILON - 1 / EPSILON;
};

module.exports = Math.fround || function fround(x) {
  var $abs = Math.abs(x);
  var $sign = sign(x);
  var a, result;
  if ($abs < MIN32) return $sign * roundTiesToEven($abs / MIN32 / EPSILON32) * MIN32 * EPSILON32;
  a = (1 + EPSILON32 / EPSILON) * $abs;
  result = a - (a - $abs);
  // eslint-disable-next-line no-self-compare
  if (result > MAX32 || result != result) return $sign * Infinity;
  return $sign * result;
};


/***/ }),
/* 171 */
/***/ (function(module, exports, __webpack_require__) {

// call something on iterator step with safe closing on error
var anObject = __webpack_require__(1);
module.exports = function (iterator, fn, value, entries) {
  try {
    return entries ? fn(anObject(value)[0], value[1]) : fn(value);
  // 7.4.6 IteratorClose(iterator, completion)
  } catch (e) {
    var ret = iterator['return'];
    if (ret !== undefined) anObject(ret.call(iterator));
    throw e;
  }
};


/***/ }),
/* 172 */
/***/ (function(module, exports, __webpack_require__) {

var aFunction = __webpack_require__(11);
var toObject = __webpack_require__(10);
var IObject = __webpack_require__(69);
var toLength = __webpack_require__(6);

module.exports = function (that, callbackfn, aLen, memo, isRight) {
  aFunction(callbackfn);
  var O = toObject(that);
  var self = IObject(O);
  var length = toLength(O.length);
  var index = isRight ? length - 1 : 0;
  var i = isRight ? -1 : 1;
  if (aLen < 2) for (;;) {
    if (index in self) {
      memo = self[index];
      index += i;
      break;
    }
    index += i;
    if (isRight ? index < 0 : length <= index) {
      throw TypeError('Reduce of empty array with no initial value');
    }
  }
  for (;isRight ? index >= 0 : length > index; index += i) if (index in self) {
    memo = callbackfn(memo, self[index], index, O);
  }
  return memo;
};


/***/ }),
/* 173 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 22.1.3.3 Array.prototype.copyWithin(target, start, end = this.length)

var toObject = __webpack_require__(10);
var toAbsoluteIndex = __webpack_require__(49);
var toLength = __webpack_require__(6);

module.exports = [].copyWithin || function copyWithin(target /* = 0 */, start /* = 0, end = @length */) {
  var O = toObject(this);
  var len = toLength(O.length);
  var to = toAbsoluteIndex(target, len);
  var from = toAbsoluteIndex(start, len);
  var end = arguments.length > 2 ? arguments[2] : undefined;
  var count = Math.min((end === undefined ? len : toAbsoluteIndex(end, len)) - from, len - to);
  var inc = 1;
  if (from < to && to < from + count) {
    inc = -1;
    from += count - 1;
    to += count - 1;
  }
  while (count-- > 0) {
    if (from in O) O[to] = O[from];
    else delete O[to];
    to += inc;
    from += inc;
  } return O;
};


/***/ }),
/* 174 */
/***/ (function(module, exports) {

module.exports = function (done, value) {
  return { value: value, done: !!done };
};


/***/ }),
/* 175 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var regexpExec = __webpack_require__(129);
__webpack_require__(0)({
  target: 'RegExp',
  proto: true,
  forced: regexpExec !== /./.exec
}, {
  exec: regexpExec
});


/***/ }),
/* 176 */
/***/ (function(module, exports, __webpack_require__) {

// 21.2.5.3 get RegExp.prototype.flags()
if (__webpack_require__(8) && /./g.flags != 'g') __webpack_require__(9).f(RegExp.prototype, 'flags', {
  configurable: true,
  get: __webpack_require__(71)
});


/***/ }),
/* 177 */
/***/ (function(module, exports) {

module.exports = function (exec) {
  try {
    return { e: false, v: exec() };
  } catch (e) {
    return { e: true, v: e };
  }
};


/***/ }),
/* 178 */
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(1);
var isObject = __webpack_require__(4);
var newPromiseCapability = __webpack_require__(133);

module.exports = function (C, x) {
  anObject(C);
  if (isObject(x) && x.constructor === C) return x;
  var promiseCapability = newPromiseCapability.f(C);
  var resolve = promiseCapability.resolve;
  resolve(x);
  return promiseCapability.promise;
};


/***/ }),
/* 179 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var strong = __webpack_require__(180);
var validate = __webpack_require__(56);
var MAP = 'Map';

// 23.1 Map Objects
module.exports = __webpack_require__(91)(MAP, function (get) {
  return function Map() { return get(this, arguments.length > 0 ? arguments[0] : undefined); };
}, {
  // 23.1.3.6 Map.prototype.get(key)
  get: function get(key) {
    var entry = strong.getEntry(validate(this, MAP), key);
    return entry && entry.v;
  },
  // 23.1.3.9 Map.prototype.set(key, value)
  set: function set(key, value) {
    return strong.def(validate(this, MAP), key === 0 ? 0 : key, value);
  }
}, strong, true);


/***/ }),
/* 180 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var dP = __webpack_require__(9).f;
var create = __webpack_require__(50);
var redefineAll = __webpack_require__(55);
var ctx = __webpack_require__(25);
var anInstance = __webpack_require__(53);
var forOf = __webpack_require__(54);
var $iterDefine = __webpack_require__(119);
var step = __webpack_require__(174);
var setSpecies = __webpack_require__(52);
var DESCRIPTORS = __webpack_require__(8);
var fastKey = __webpack_require__(42).fastKey;
var validate = __webpack_require__(56);
var SIZE = DESCRIPTORS ? '_s' : 'size';

var getEntry = function (that, key) {
  // fast case
  var index = fastKey(key);
  var entry;
  if (index !== 'F') return that._i[index];
  // frozen object case
  for (entry = that._f; entry; entry = entry.n) {
    if (entry.k == key) return entry;
  }
};

module.exports = {
  getConstructor: function (wrapper, NAME, IS_MAP, ADDER) {
    var C = wrapper(function (that, iterable) {
      anInstance(that, C, NAME, '_i');
      that._t = NAME;         // collection type
      that._i = create(null); // index
      that._f = undefined;    // first entry
      that._l = undefined;    // last entry
      that[SIZE] = 0;         // size
      if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
    });
    redefineAll(C.prototype, {
      // 23.1.3.1 Map.prototype.clear()
      // 23.2.3.2 Set.prototype.clear()
      clear: function clear() {
        for (var that = validate(this, NAME), data = that._i, entry = that._f; entry; entry = entry.n) {
          entry.r = true;
          if (entry.p) entry.p = entry.p.n = undefined;
          delete data[entry.i];
        }
        that._f = that._l = undefined;
        that[SIZE] = 0;
      },
      // 23.1.3.3 Map.prototype.delete(key)
      // 23.2.3.4 Set.prototype.delete(value)
      'delete': function (key) {
        var that = validate(this, NAME);
        var entry = getEntry(that, key);
        if (entry) {
          var next = entry.n;
          var prev = entry.p;
          delete that._i[entry.i];
          entry.r = true;
          if (prev) prev.n = next;
          if (next) next.p = prev;
          if (that._f == entry) that._f = next;
          if (that._l == entry) that._l = prev;
          that[SIZE]--;
        } return !!entry;
      },
      // 23.2.3.6 Set.prototype.forEach(callbackfn, thisArg = undefined)
      // 23.1.3.5 Map.prototype.forEach(callbackfn, thisArg = undefined)
      forEach: function forEach(callbackfn /* , that = undefined */) {
        validate(this, NAME);
        var f = ctx(callbackfn, arguments.length > 1 ? arguments[1] : undefined, 3);
        var entry;
        while (entry = entry ? entry.n : this._f) {
          f(entry.v, entry.k, this);
          // revert to the last existing entry
          while (entry && entry.r) entry = entry.p;
        }
      },
      // 23.1.3.7 Map.prototype.has(key)
      // 23.2.3.7 Set.prototype.has(value)
      has: function has(key) {
        return !!getEntry(validate(this, NAME), key);
      }
    });
    if (DESCRIPTORS) dP(C.prototype, 'size', {
      get: function () {
        return validate(this, NAME)[SIZE];
      }
    });
    return C;
  },
  def: function (that, key, value) {
    var entry = getEntry(that, key);
    var prev, index;
    // change existing entry
    if (entry) {
      entry.v = value;
    // create new entry
    } else {
      that._l = entry = {
        i: index = fastKey(key, true), // <- index
        k: key,                        // <- key
        v: value,                      // <- value
        p: prev = that._l,             // <- previous entry
        n: undefined,                  // <- next entry
        r: false                       // <- removed
      };
      if (!that._f) that._f = entry;
      if (prev) prev.n = entry;
      that[SIZE]++;
      // add to index
      if (index !== 'F') that._i[index] = entry;
    } return that;
  },
  getEntry: getEntry,
  setStrong: function (C, NAME, IS_MAP) {
    // add .keys, .values, .entries, [@@iterator]
    // 23.1.3.4, 23.1.3.8, 23.1.3.11, 23.1.3.12, 23.2.3.5, 23.2.3.8, 23.2.3.10, 23.2.3.11
    $iterDefine(C, NAME, function (iterated, kind) {
      this._t = validate(iterated, NAME); // target
      this._k = kind;                     // kind
      this._l = undefined;                // previous
    }, function () {
      var that = this;
      var kind = that._k;
      var entry = that._l;
      // revert to the last existing entry
      while (entry && entry.r) entry = entry.p;
      // get next entry
      if (!that._t || !(that._l = entry = entry ? entry.n : that._t._f)) {
        // or finish the iteration
        that._t = undefined;
        return step(1);
      }
      // return step by kind
      if (kind == 'keys') return step(0, entry.k);
      if (kind == 'values') return step(0, entry.v);
      return step(0, [entry.k, entry.v]);
    }, IS_MAP ? 'entries' : 'values', !IS_MAP, true);

    // add [@@species], 23.1.2.2, 23.2.2.2
    setSpecies(NAME);
  }
};


/***/ }),
/* 181 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var strong = __webpack_require__(180);
var validate = __webpack_require__(56);
var SET = 'Set';

// 23.2 Set Objects
module.exports = __webpack_require__(91)(SET, function (get) {
  return function Set() { return get(this, arguments.length > 0 ? arguments[0] : undefined); };
}, {
  // 23.2.3.1 Set.prototype.add(value)
  add: function add(value) {
    return strong.def(validate(this, SET), value = value === 0 ? 0 : value, value);
  }
}, strong);


/***/ }),
/* 182 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(2);
var each = __webpack_require__(34)(0);
var redefine = __webpack_require__(16);
var meta = __webpack_require__(42);
var assign = __webpack_require__(161);
var weak = __webpack_require__(183);
var isObject = __webpack_require__(4);
var validate = __webpack_require__(56);
var NATIVE_WEAK_MAP = __webpack_require__(56);
var IS_IE11 = !global.ActiveXObject && 'ActiveXObject' in global;
var WEAK_MAP = 'WeakMap';
var getWeak = meta.getWeak;
var isExtensible = Object.isExtensible;
var uncaughtFrozenStore = weak.ufstore;
var InternalMap;

var wrapper = function (get) {
  return function WeakMap() {
    return get(this, arguments.length > 0 ? arguments[0] : undefined);
  };
};

var methods = {
  // 23.3.3.3 WeakMap.prototype.get(key)
  get: function get(key) {
    if (isObject(key)) {
      var data = getWeak(key);
      if (data === true) return uncaughtFrozenStore(validate(this, WEAK_MAP)).get(key);
      return data ? data[this._i] : undefined;
    }
  },
  // 23.3.3.5 WeakMap.prototype.set(key, value)
  set: function set(key, value) {
    return weak.def(validate(this, WEAK_MAP), key, value);
  }
};

// 23.3 WeakMap Objects
var $WeakMap = module.exports = __webpack_require__(91)(WEAK_MAP, wrapper, methods, weak, true, true);

// IE11 WeakMap frozen keys fix
if (NATIVE_WEAK_MAP && IS_IE11) {
  InternalMap = weak.getConstructor(wrapper, WEAK_MAP);
  assign(InternalMap.prototype, methods);
  meta.NEED = true;
  each(['delete', 'has', 'get', 'set'], function (key) {
    var proto = $WeakMap.prototype;
    var method = proto[key];
    redefine(proto, key, function (a, b) {
      // store frozen objects on internal weakmap shim
      if (isObject(a) && !isExtensible(a)) {
        if (!this._f) this._f = new InternalMap();
        var result = this._f[key](a, b);
        return key == 'set' ? this : result;
      // store all the rest on native weakmap
      } return method.call(this, a, b);
    });
  });
}


/***/ }),
/* 183 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var redefineAll = __webpack_require__(55);
var getWeak = __webpack_require__(42).getWeak;
var anObject = __webpack_require__(1);
var isObject = __webpack_require__(4);
var anInstance = __webpack_require__(53);
var forOf = __webpack_require__(54);
var createArrayMethod = __webpack_require__(34);
var $has = __webpack_require__(19);
var validate = __webpack_require__(56);
var arrayFind = createArrayMethod(5);
var arrayFindIndex = createArrayMethod(6);
var id = 0;

// fallback for uncaught frozen keys
var uncaughtFrozenStore = function (that) {
  return that._l || (that._l = new UncaughtFrozenStore());
};
var UncaughtFrozenStore = function () {
  this.a = [];
};
var findUncaughtFrozen = function (store, key) {
  return arrayFind(store.a, function (it) {
    return it[0] === key;
  });
};
UncaughtFrozenStore.prototype = {
  get: function (key) {
    var entry = findUncaughtFrozen(this, key);
    if (entry) return entry[1];
  },
  has: function (key) {
    return !!findUncaughtFrozen(this, key);
  },
  set: function (key, value) {
    var entry = findUncaughtFrozen(this, key);
    if (entry) entry[1] = value;
    else this.a.push([key, value]);
  },
  'delete': function (key) {
    var index = arrayFindIndex(this.a, function (it) {
      return it[0] === key;
    });
    if (~index) this.a.splice(index, 1);
    return !!~index;
  }
};

module.exports = {
  getConstructor: function (wrapper, NAME, IS_MAP, ADDER) {
    var C = wrapper(function (that, iterable) {
      anInstance(that, C, NAME, '_i');
      that._t = NAME;      // collection type
      that._i = id++;      // collection id
      that._l = undefined; // leak store for uncaught frozen objects
      if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
    });
    redefineAll(C.prototype, {
      // 23.3.3.2 WeakMap.prototype.delete(key)
      // 23.4.3.3 WeakSet.prototype.delete(value)
      'delete': function (key) {
        if (!isObject(key)) return false;
        var data = getWeak(key);
        if (data === true) return uncaughtFrozenStore(validate(this, NAME))['delete'](key);
        return data && $has(data, this._i) && delete data[this._i];
      },
      // 23.3.3.4 WeakMap.prototype.has(key)
      // 23.4.3.4 WeakSet.prototype.has(value)
      has: function has(key) {
        if (!isObject(key)) return false;
        var data = getWeak(key);
        if (data === true) return uncaughtFrozenStore(validate(this, NAME)).has(key);
        return data && $has(data, this._i);
      }
    });
    return C;
  },
  def: function (that, key, value) {
    var data = getWeak(anObject(key), true);
    if (data === true) uncaughtFrozenStore(that).set(key, value);
    else data[that._i] = value;
    return that;
  },
  ufstore: uncaughtFrozenStore
};


/***/ }),
/* 184 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/ecma262/#sec-toindex
var toInteger = __webpack_require__(27);
var toLength = __webpack_require__(6);
module.exports = function (it) {
  if (it === undefined) return 0;
  var number = toInteger(it);
  var length = toLength(number);
  if (number !== length) throw RangeError('Wrong length!');
  return length;
};


/***/ }),
/* 185 */
/***/ (function(module, exports, __webpack_require__) {

// all object keys, includes non-enumerable and symbols
var gOPN = __webpack_require__(51);
var gOPS = __webpack_require__(83);
var anObject = __webpack_require__(1);
var Reflect = __webpack_require__(2).Reflect;
module.exports = Reflect && Reflect.ownKeys || function ownKeys(it) {
  var keys = gOPN.f(anObject(it));
  var getSymbols = gOPS.f;
  return getSymbols ? keys.concat(getSymbols(it)) : keys;
};


/***/ }),
/* 186 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-flatMap/#sec-FlattenIntoArray
var isArray = __webpack_require__(84);
var isObject = __webpack_require__(4);
var toLength = __webpack_require__(6);
var ctx = __webpack_require__(25);
var IS_CONCAT_SPREADABLE = __webpack_require__(5)('isConcatSpreadable');

function flattenIntoArray(target, original, source, sourceLen, start, depth, mapper, thisArg) {
  var targetIndex = start;
  var sourceIndex = 0;
  var mapFn = mapper ? ctx(mapper, thisArg, 3) : false;
  var element, spreadable;

  while (sourceIndex < sourceLen) {
    if (sourceIndex in source) {
      element = mapFn ? mapFn(source[sourceIndex], sourceIndex, original) : source[sourceIndex];

      spreadable = false;
      if (isObject(element)) {
        spreadable = element[IS_CONCAT_SPREADABLE];
        spreadable = spreadable !== undefined ? !!spreadable : isArray(element);
      }

      if (spreadable && depth > 0) {
        targetIndex = flattenIntoArray(target, original, element, toLength(element.length), targetIndex, depth - 1) - 1;
      } else {
        if (targetIndex >= 0x1fffffffffffff) throw TypeError();
        target[targetIndex] = element;
      }

      targetIndex++;
    }
    sourceIndex++;
  }
  return targetIndex;
}

module.exports = flattenIntoArray;


/***/ }),
/* 187 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-string-pad-start-end
var toLength = __webpack_require__(6);
var repeat = __webpack_require__(116);
var defined = __webpack_require__(32);

module.exports = function (that, maxLength, fillString, left) {
  var S = String(defined(that));
  var stringLength = S.length;
  var fillStr = fillString === undefined ? ' ' : String(fillString);
  var intMaxLength = toLength(maxLength);
  if (intMaxLength <= stringLength || fillStr == '') return S;
  var fillLen = intMaxLength - stringLength;
  var stringFiller = repeat.call(fillStr, Math.ceil(fillLen / fillStr.length));
  if (stringFiller.length > fillLen) stringFiller = stringFiller.slice(0, fillLen);
  return left ? stringFiller + S : S + stringFiller;
};


/***/ }),
/* 188 */
/***/ (function(module, exports, __webpack_require__) {

var getKeys = __webpack_require__(48);
var toIObject = __webpack_require__(20);
var isEnum = __webpack_require__(70).f;
module.exports = function (isEntries) {
  return function (it) {
    var O = toIObject(it);
    var keys = getKeys(O);
    var length = keys.length;
    var i = 0;
    var result = [];
    var key;
    while (length > i) if (isEnum.call(O, key = keys[i++])) {
      result.push(isEntries ? [key, O[key]] : O[key]);
    } return result;
  };
};


/***/ }),
/* 189 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/DavidBruant/Map-Set.prototype.toJSON
var classof = __webpack_require__(61);
var from = __webpack_require__(190);
module.exports = function (NAME) {
  return function toJSON() {
    if (classof(this) != NAME) throw TypeError(NAME + "#toJSON isn't generic");
    return from(this);
  };
};


/***/ }),
/* 190 */
/***/ (function(module, exports, __webpack_require__) {

var forOf = __webpack_require__(54);

module.exports = function (iter, ITERATOR) {
  var result = [];
  forOf(iter, false, result.push, result, ITERATOR);
  return result;
};


/***/ }),
/* 191 */
/***/ (function(module, exports) {

// https://rwaldron.github.io/proposal-math-extensions/
module.exports = Math.scale || function scale(x, inLow, inHigh, outLow, outHigh) {
  if (
    arguments.length === 0
      // eslint-disable-next-line no-self-compare
      || x != x
      // eslint-disable-next-line no-self-compare
      || inLow != inLow
      // eslint-disable-next-line no-self-compare
      || inHigh != inHigh
      // eslint-disable-next-line no-self-compare
      || outLow != outLow
      // eslint-disable-next-line no-self-compare
      || outHigh != outHigh
  ) return NaN;
  if (x === Infinity || x === -Infinity) return x;
  return (x - inLow) * (outHigh - outLow) / (inHigh - inLow) + outLow;
};


/***/ }),
/* 192 */
/***/ (function(module, exports, __webpack_require__) {

var has = __webpack_require__(57);
var toIObject = __webpack_require__(59);
var arrayIndexOf = __webpack_require__(434)(false);
var IE_PROTO = __webpack_require__(138)('IE_PROTO');

module.exports = function (object, names) {
  var O = toIObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) if (key != IE_PROTO) has(O, key) && result.push(key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (has(O, key = names[i++])) {
    ~arrayIndexOf(result, key) || result.push(key);
  }
  return result;
};


/***/ }),
/* 193 */
/***/ (function(module, exports, __webpack_require__) {

// fallback for non-array-like ES3 and non-enumerable old V8 strings
var cof = __webpack_require__(75);
// eslint-disable-next-line no-prototype-builtins
module.exports = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
  return cof(it) == 'String' ? it.split('') : Object(it);
};


/***/ }),
/* 194 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = !__webpack_require__(45) && !__webpack_require__(65)(function () {
  return Object.defineProperty(__webpack_require__(141)('div'), 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),
/* 195 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)
var has = __webpack_require__(57);
var toObject = __webpack_require__(73);
var IE_PROTO = __webpack_require__(138)('IE_PROTO');
var ObjectProto = Object.prototype;

module.exports = Object.getPrototypeOf || function (O) {
  O = toObject(O);
  if (has(O, IE_PROTO)) return O[IE_PROTO];
  if (typeof O.constructor == 'function' && O instanceof O.constructor) {
    return O.constructor.prototype;
  } return O instanceof Object ? ObjectProto : null;
};


/***/ }),
/* 196 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var LIBRARY = __webpack_require__(76);
var $export = __webpack_require__(18);
var redefine = __webpack_require__(197);
var hide = __webpack_require__(58);
var Iterators = __webpack_require__(67);
var $iterCreate = __webpack_require__(441);
var setToStringTag = __webpack_require__(99);
var getPrototypeOf = __webpack_require__(195);
var ITERATOR = __webpack_require__(14)('iterator');
var BUGGY = !([].keys && 'next' in [].keys()); // Safari has buggy iterators w/o `next`
var FF_ITERATOR = '@@iterator';
var KEYS = 'keys';
var VALUES = 'values';

var returnThis = function () { return this; };

module.exports = function (Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED) {
  $iterCreate(Constructor, NAME, next);
  var getMethod = function (kind) {
    if (!BUGGY && kind in proto) return proto[kind];
    switch (kind) {
      case KEYS: return function keys() { return new Constructor(this, kind); };
      case VALUES: return function values() { return new Constructor(this, kind); };
    } return function entries() { return new Constructor(this, kind); };
  };
  var TAG = NAME + ' Iterator';
  var DEF_VALUES = DEFAULT == VALUES;
  var VALUES_BUG = false;
  var proto = Base.prototype;
  var $native = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT];
  var $default = $native || getMethod(DEFAULT);
  var $entries = DEFAULT ? !DEF_VALUES ? $default : getMethod('entries') : undefined;
  var $anyNative = NAME == 'Array' ? proto.entries || $native : $native;
  var methods, key, IteratorPrototype;
  // Fix native
  if ($anyNative) {
    IteratorPrototype = getPrototypeOf($anyNative.call(new Base()));
    if (IteratorPrototype !== Object.prototype && IteratorPrototype.next) {
      // Set @@toStringTag to native iterators
      setToStringTag(IteratorPrototype, TAG, true);
      // fix for some old engines
      if (!LIBRARY && typeof IteratorPrototype[ITERATOR] != 'function') hide(IteratorPrototype, ITERATOR, returnThis);
    }
  }
  // fix Array#{values, @@iterator}.name in V8 / FF
  if (DEF_VALUES && $native && $native.name !== VALUES) {
    VALUES_BUG = true;
    $default = function values() { return $native.call(this); };
  }
  // Define iterator
  if ((!LIBRARY || FORCED) && (BUGGY || VALUES_BUG || !proto[ITERATOR])) {
    hide(proto, ITERATOR, $default);
  }
  // Plug for library
  Iterators[NAME] = $default;
  Iterators[TAG] = returnThis;
  if (DEFAULT) {
    methods = {
      values: DEF_VALUES ? $default : getMethod(VALUES),
      keys: IS_SET ? $default : getMethod(KEYS),
      entries: $entries
    };
    if (FORCED) for (key in methods) {
      if (!(key in proto)) redefine(proto, key, methods[key]);
    } else $export($export.P + $export.F * (BUGGY || VALUES_BUG), NAME, methods);
  }
  return methods;
};


/***/ }),
/* 197 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(58);


/***/ }),
/* 198 */
/***/ (function(module, exports, __webpack_require__) {

var document = __webpack_require__(12).document;
module.exports = document && document.documentElement;


/***/ }),
/* 199 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(446), __esModule: true };

/***/ }),
/* 200 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.7 / 15.2.3.4 Object.getOwnPropertyNames(O)
var $keys = __webpack_require__(192);
var hiddenKeys = __webpack_require__(140).concat('length', 'prototype');

exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return $keys(O, hiddenKeys);
};


/***/ }),
/* 201 */
/***/ (function(module, exports) {



/***/ }),
/* 202 */
/***/ (function(module, exports, __webpack_require__) {

// call something on iterator step with safe closing on error
var anObject = __webpack_require__(35);
module.exports = function (iterator, fn, value, entries) {
  try {
    return entries ? fn(anObject(value)[0], value[1]) : fn(value);
  // 7.4.6 IteratorClose(iterator, completion)
  } catch (e) {
    var ret = iterator['return'];
    if (ret !== undefined) anObject(ret.call(iterator));
    throw e;
  }
};


/***/ }),
/* 203 */
/***/ (function(module, exports, __webpack_require__) {

// check on default Array iterator
var Iterators = __webpack_require__(67);
var ITERATOR = __webpack_require__(14)('iterator');
var ArrayProto = Array.prototype;

module.exports = function (it) {
  return it !== undefined && (Iterators.Array === it || ArrayProto[ITERATOR] === it);
};


/***/ }),
/* 204 */
/***/ (function(module, exports, __webpack_require__) {

var ITERATOR = __webpack_require__(14)('iterator');
var SAFE_CLOSING = false;

try {
  var riter = [7][ITERATOR]();
  riter['return'] = function () { SAFE_CLOSING = true; };
  // eslint-disable-next-line no-throw-literal
  Array.from(riter, function () { throw 2; });
} catch (e) { /* empty */ }

module.exports = function (exec, skipClosing) {
  if (!skipClosing && !SAFE_CLOSING) return false;
  var safe = false;
  try {
    var arr = [7];
    var iter = arr[ITERATOR]();
    iter.next = function () { return { done: safe = true }; };
    arr[ITERATOR] = function () { return iter; };
    exec(arr);
  } catch (e) { /* empty */ }
  return safe;
};


/***/ }),
/* 205 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(461), __esModule: true };

/***/ }),
/* 206 */,
/* 207 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(470), __esModule: true };

/***/ }),
/* 208 */
/***/ (function(module, exports, __webpack_require__) {

// 7.3.20 SpeciesConstructor(O, defaultConstructor)
var anObject = __webpack_require__(35);
var aFunction = __webpack_require__(97);
var SPECIES = __webpack_require__(14)('species');
module.exports = function (O, D) {
  var C = anObject(O).constructor;
  var S;
  return C === undefined || (S = anObject(C)[SPECIES]) == undefined ? D : aFunction(S);
};


/***/ }),
/* 209 */
/***/ (function(module, exports) {

module.exports = function (exec) {
  try {
    return { e: false, v: exec() };
  } catch (e) {
    return { e: true, v: e };
  }
};


/***/ }),
/* 210 */
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(35);
var isObject = __webpack_require__(44);
var newPromiseCapability = __webpack_require__(150);

module.exports = function (C, x) {
  anObject(C);
  if (isObject(x) && x.constructor === C) return x;
  var promiseCapability = newPromiseCapability.f(C);
  var resolve = promiseCapability.resolve;
  resolve(x);
  return promiseCapability.promise;
};


/***/ }),
/* 211 */,
/* 212 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof2 = __webpack_require__(13);

var _typeof3 = _interopRequireDefault(_typeof2);

var _keys = __webpack_require__(37);

var _keys2 = _interopRequireDefault(_keys);

var _promise = __webpack_require__(207);

var _promise2 = _interopRequireDefault(_promise);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var isArray = Array.isArray ? Array.isArray : function _isArray(obj) {
    return Object.prototype.toString.call(obj) === "[object Array]";
};
var defaultMaxListeners = 10;

function init() {
    this._events = {};
    if (this._conf) {
        configure.call(this, this._conf);
    }
}

function configure(conf) {
    if (conf) {
        this._conf = conf;

        conf.delimiter && (this.delimiter = conf.delimiter);
        this._maxListeners = conf.maxListeners !== undefined ? conf.maxListeners : defaultMaxListeners;

        conf.wildcard && (this.wildcard = conf.wildcard);
        conf.newListener && (this.newListener = conf.newListener);
        conf.verboseMemoryLeak && (this.verboseMemoryLeak = conf.verboseMemoryLeak);

        if (this.wildcard) {
            this.listenerTree = {};
        }
    } else {
        this._maxListeners = defaultMaxListeners;
    }
}

function logPossibleMemoryLeak(count, eventName) {
    var errorMsg = '(node) warning: possible EventEmitter memory ' + 'leak detected. ' + count + ' listeners added. ' + 'Use emitter.setMaxListeners() to increase limit.';

    if (this.verboseMemoryLeak) {
        errorMsg += ' Event name: ' + eventName + '.';
    }

    if (typeof process !== 'undefined' && process.emitWarning) {
        var e = new Error(errorMsg);
        e.name = 'MaxListenersExceededWarning';
        e.emitter = this;
        e.count = count;
        process.emitWarning(e);
    } else {
        console.error(errorMsg);

        if (console.trace) {
            console.trace();
        }
    }
}

function EventEmitter(conf) {
    this._events = {};
    this.newListener = false;
    this.verboseMemoryLeak = false;
    configure.call(this, conf);
}
EventEmitter.EventEmitter2 = EventEmitter; // backwards compatibility for exporting EventEmitter property

//
// Attention, function return type now is array, always !
// It has zero elements if no any matches found and one or more
// elements (leafs) if there are matches
//
function searchListenerTree(handlers, type, tree, i) {
    if (!tree) {
        return [];
    }
    var listeners = [],
        leaf,
        len,
        branch,
        xTree,
        xxTree,
        isolatedBranch,
        endReached,
        typeLength = type.length,
        currentType = type[i],
        nextType = type[i + 1];
    if (i === typeLength && tree._listeners) {
        //
        // If at the end of the event(s) list and the tree has listeners
        // invoke those listeners.
        //
        if (typeof tree._listeners === 'function') {
            handlers && handlers.push(tree._listeners);
            return [tree];
        } else {
            for (leaf = 0, len = tree._listeners.length; leaf < len; leaf++) {
                handlers && handlers.push(tree._listeners[leaf]);
            }
            return [tree];
        }
    }

    if (currentType === '*' || currentType === '**' || tree[currentType]) {
        //
        // If the event emitted is '*' at this part
        // or there is a concrete match at this patch
        //
        if (currentType === '*') {
            for (branch in tree) {
                if (branch !== '_listeners' && tree.hasOwnProperty(branch)) {
                    listeners = listeners.concat(searchListenerTree(handlers, type, tree[branch], i + 1));
                }
            }
            return listeners;
        } else if (currentType === '**') {
            endReached = i + 1 === typeLength || i + 2 === typeLength && nextType === '*';
            if (endReached && tree._listeners) {
                // The next element has a _listeners, add it to the handlers.
                listeners = listeners.concat(searchListenerTree(handlers, type, tree, typeLength));
            }

            for (branch in tree) {
                if (branch !== '_listeners' && tree.hasOwnProperty(branch)) {
                    if (branch === '*' || branch === '**') {
                        if (tree[branch]._listeners && !endReached) {
                            listeners = listeners.concat(searchListenerTree(handlers, type, tree[branch], typeLength));
                        }
                        listeners = listeners.concat(searchListenerTree(handlers, type, tree[branch], i));
                    } else if (branch === nextType) {
                        listeners = listeners.concat(searchListenerTree(handlers, type, tree[branch], i + 2));
                    } else {
                        // No match on this one, shift into the tree but not in the type array.
                        listeners = listeners.concat(searchListenerTree(handlers, type, tree[branch], i));
                    }
                }
            }
            return listeners;
        }

        listeners = listeners.concat(searchListenerTree(handlers, type, tree[currentType], i + 1));
    }

    xTree = tree['*'];
    if (xTree) {
        //
        // If the listener tree will allow any match for this part,
        // then recursively explore all branches of the tree
        //
        searchListenerTree(handlers, type, xTree, i + 1);
    }

    xxTree = tree['**'];
    if (xxTree) {
        if (i < typeLength) {
            if (xxTree._listeners) {
                // If we have a listener on a '**', it will catch all, so add its handler.
                searchListenerTree(handlers, type, xxTree, typeLength);
            }

            // Build arrays of matching next branches and others.
            for (branch in xxTree) {
                if (branch !== '_listeners' && xxTree.hasOwnProperty(branch)) {
                    if (branch === nextType) {
                        // We know the next element will match, so jump twice.
                        searchListenerTree(handlers, type, xxTree[branch], i + 2);
                    } else if (branch === currentType) {
                        // Current node matches, move into the tree.
                        searchListenerTree(handlers, type, xxTree[branch], i + 1);
                    } else {
                        isolatedBranch = {};
                        isolatedBranch[branch] = xxTree[branch];
                        searchListenerTree(handlers, type, { '**': isolatedBranch }, i + 1);
                    }
                }
            }
        } else if (xxTree._listeners) {
            // We have reached the end and still on a '**'
            searchListenerTree(handlers, type, xxTree, typeLength);
        } else if (xxTree['*'] && xxTree['*']._listeners) {
            searchListenerTree(handlers, type, xxTree['*'], typeLength);
        }
    }

    return listeners;
}

function growListenerTree(type, listener) {

    type = typeof type === 'string' ? type.split(this.delimiter) : type.slice();

    //
    // Looks for two consecutive '**', if so, don't add the event at all.
    //
    for (var i = 0, len = type.length; i + 1 < len; i++) {
        if (type[i] === '**' && type[i + 1] === '**') {
            return;
        }
    }

    var tree = this.listenerTree;
    var name = type.shift();

    while (name !== undefined) {

        if (!tree[name]) {
            tree[name] = {};
        }

        tree = tree[name];

        if (type.length === 0) {

            if (!tree._listeners) {
                tree._listeners = listener;
            } else {
                if (typeof tree._listeners === 'function') {
                    tree._listeners = [tree._listeners];
                }

                tree._listeners.push(listener);

                if (!tree._listeners.warned && this._maxListeners > 0 && tree._listeners.length > this._maxListeners) {
                    tree._listeners.warned = true;
                    logPossibleMemoryLeak.call(this, tree._listeners.length, name);
                }
            }
            return true;
        }
        name = type.shift();
    }
    return true;
}

// By default EventEmitters will print a warning if more than
// 10 listeners are added to it. This is a useful default which
// helps finding memory leaks.
//
// Obviously not all Emitters should be limited to 10. This function allows
// that to be increased. Set to zero for unlimited.

EventEmitter.prototype.delimiter = '.';

EventEmitter.prototype.setMaxListeners = function (n) {
    if (n !== undefined) {
        this._maxListeners = n;
        if (!this._conf) this._conf = {};
        this._conf.maxListeners = n;
    }
};

EventEmitter.prototype.event = '';

EventEmitter.prototype.once = function (event, fn) {
    return this._once(event, fn, false);
};

EventEmitter.prototype.prependOnceListener = function (event, fn) {
    return this._once(event, fn, true);
};

EventEmitter.prototype._once = function (event, fn, prepend) {
    this._many(event, 1, fn, prepend);
    return this;
};

EventEmitter.prototype.many = function (event, ttl, fn) {
    return this._many(event, ttl, fn, false);
};

EventEmitter.prototype.prependMany = function (event, ttl, fn) {
    return this._many(event, ttl, fn, true);
};

EventEmitter.prototype._many = function (event, ttl, fn, prepend) {
    var self = this;

    if (typeof fn !== 'function') {
        throw new Error('many only accepts instances of Function');
    }

    function listener() {
        if (--ttl === 0) {
            self.off(event, listener);
        }
        return fn.apply(this, arguments);
    }

    listener._origin = fn;

    this._on(event, listener, prepend);

    return self;
};

EventEmitter.prototype.emit = function () {

    this._events || init.call(this);

    var type = arguments[0];

    if (type === 'newListener' && !this.newListener) {
        if (!this._events.newListener) {
            return false;
        }
    }

    var al = arguments.length;
    var args, l, i, j;
    var handler;

    if (this._all && this._all.length) {
        handler = this._all.slice();
        if (al > 3) {
            args = new Array(al);
            for (j = 0; j < al; j++) {
                args[j] = arguments[j];
            }
        }

        for (i = 0, l = handler.length; i < l; i++) {
            this.event = type;
            switch (al) {
                case 1:
                    handler[i].call(this, type);
                    break;
                case 2:
                    handler[i].call(this, type, arguments[1]);
                    break;
                case 3:
                    handler[i].call(this, type, arguments[1], arguments[2]);
                    break;
                default:
                    handler[i].apply(this, args);
            }
        }
    }

    if (this.wildcard) {
        handler = [];
        var ns = typeof type === 'string' ? type.split(this.delimiter) : type.slice();
        searchListenerTree.call(this, handler, ns, this.listenerTree, 0);
    } else {
        handler = this._events[type];
        if (typeof handler === 'function') {
            this.event = type;
            switch (al) {
                case 1:
                    handler.call(this);
                    break;
                case 2:
                    handler.call(this, arguments[1]);
                    break;
                case 3:
                    handler.call(this, arguments[1], arguments[2]);
                    break;
                default:
                    args = new Array(al - 1);
                    for (j = 1; j < al; j++) {
                        args[j - 1] = arguments[j];
                    }handler.apply(this, args);
            }
            return true;
        } else if (handler) {
            // need to make copy of handlers because list can change in the middle
            // of emit call
            handler = handler.slice();
        }
    }

    if (handler && handler.length) {
        if (al > 3) {
            args = new Array(al - 1);
            for (j = 1; j < al; j++) {
                args[j - 1] = arguments[j];
            }
        }
        for (i = 0, l = handler.length; i < l; i++) {
            this.event = type;
            switch (al) {
                case 1:
                    handler[i].call(this);
                    break;
                case 2:
                    handler[i].call(this, arguments[1]);
                    break;
                case 3:
                    handler[i].call(this, arguments[1], arguments[2]);
                    break;
                default:
                    handler[i].apply(this, args);
            }
        }
        return true;
    } else if (!this._all && type === 'error') {
        if (arguments[1] instanceof Error) {
            throw arguments[1]; // Unhandled 'error' event
        } else {
            throw new Error("Uncaught, unspecified 'error' event.");
        }
        return false;
    }

    return !!this._all;
};

EventEmitter.prototype.emitAsync = function () {

    this._events || init.call(this);

    var type = arguments[0];

    if (type === 'newListener' && !this.newListener) {
        if (!this._events.newListener) {
            return _promise2.default.resolve([false]);
        }
    }

    var promises = [];

    var al = arguments.length;
    var args, l, i, j;
    var handler;

    if (this._all) {
        if (al > 3) {
            args = new Array(al);
            for (j = 1; j < al; j++) {
                args[j] = arguments[j];
            }
        }
        for (i = 0, l = this._all.length; i < l; i++) {
            this.event = type;
            switch (al) {
                case 1:
                    promises.push(this._all[i].call(this, type));
                    break;
                case 2:
                    promises.push(this._all[i].call(this, type, arguments[1]));
                    break;
                case 3:
                    promises.push(this._all[i].call(this, type, arguments[1], arguments[2]));
                    break;
                default:
                    promises.push(this._all[i].apply(this, args));
            }
        }
    }

    if (this.wildcard) {
        handler = [];
        var ns = typeof type === 'string' ? type.split(this.delimiter) : type.slice();
        searchListenerTree.call(this, handler, ns, this.listenerTree, 0);
    } else {
        handler = this._events[type];
    }

    if (typeof handler === 'function') {
        this.event = type;
        switch (al) {
            case 1:
                promises.push(handler.call(this));
                break;
            case 2:
                promises.push(handler.call(this, arguments[1]));
                break;
            case 3:
                promises.push(handler.call(this, arguments[1], arguments[2]));
                break;
            default:
                args = new Array(al - 1);
                for (j = 1; j < al; j++) {
                    args[j - 1] = arguments[j];
                }promises.push(handler.apply(this, args));
        }
    } else if (handler && handler.length) {
        handler = handler.slice();
        if (al > 3) {
            args = new Array(al - 1);
            for (j = 1; j < al; j++) {
                args[j - 1] = arguments[j];
            }
        }
        for (i = 0, l = handler.length; i < l; i++) {
            this.event = type;
            switch (al) {
                case 1:
                    promises.push(handler[i].call(this));
                    break;
                case 2:
                    promises.push(handler[i].call(this, arguments[1]));
                    break;
                case 3:
                    promises.push(handler[i].call(this, arguments[1], arguments[2]));
                    break;
                default:
                    promises.push(handler[i].apply(this, args));
            }
        }
    } else if (!this._all && type === 'error') {
        if (arguments[1] instanceof Error) {
            return _promise2.default.reject(arguments[1]); // Unhandled 'error' event
        } else {
            return _promise2.default.reject("Uncaught, unspecified 'error' event.");
        }
    }

    return _promise2.default.all(promises);
};

EventEmitter.prototype.on = function (type, listener) {
    return this._on(type, listener, false);
};

EventEmitter.prototype.prependListener = function (type, listener) {
    return this._on(type, listener, true);
};

EventEmitter.prototype.onAny = function (fn) {
    return this._onAny(fn, false);
};

EventEmitter.prototype.prependAny = function (fn) {
    return this._onAny(fn, true);
};

EventEmitter.prototype.addListener = EventEmitter.prototype.on;

EventEmitter.prototype._onAny = function (fn, prepend) {
    if (typeof fn !== 'function') {
        throw new Error('onAny only accepts instances of Function');
    }

    if (!this._all) {
        this._all = [];
    }

    // Add the function to the event listener collection.
    if (prepend) {
        this._all.unshift(fn);
    } else {
        this._all.push(fn);
    }

    return this;
};

EventEmitter.prototype._on = function (type, listener, prepend) {
    if (typeof type === 'function') {
        this._onAny(type, listener);
        return this;
    }

    if (typeof listener !== 'function') {
        throw new Error('on only accepts instances of Function');
    }
    this._events || init.call(this);

    // To avoid recursion in the case that type == "newListeners"! Before
    // adding it to the listeners, first emit "newListeners".
    this.emit('newListener', type, listener);

    if (this.wildcard) {
        growListenerTree.call(this, type, listener);
        return this;
    }

    if (!this._events[type]) {
        // Optimize the case of one listener. Don't need the extra array object.
        this._events[type] = listener;
    } else {
        if (typeof this._events[type] === 'function') {
            // Change to array.
            this._events[type] = [this._events[type]];
        }

        // If we've already got an array, just add
        if (prepend) {
            this._events[type].unshift(listener);
        } else {
            this._events[type].push(listener);
        }

        // Check for listener leak
        if (!this._events[type].warned && this._maxListeners > 0 && this._events[type].length > this._maxListeners) {
            this._events[type].warned = true;
            logPossibleMemoryLeak.call(this, this._events[type].length, type);
        }
    }

    return this;
};

EventEmitter.prototype.off = function (type, listener) {
    if (typeof listener !== 'function') {
        throw new Error('removeListener only takes instances of Function');
    }

    var handlers,
        leafs = [];

    if (this.wildcard) {
        var ns = typeof type === 'string' ? type.split(this.delimiter) : type.slice();
        leafs = searchListenerTree.call(this, null, ns, this.listenerTree, 0);
    } else {
        // does not use listeners(), so no side effect of creating _events[type]
        if (!this._events[type]) return this;
        handlers = this._events[type];
        leafs.push({ _listeners: handlers });
    }

    for (var iLeaf = 0; iLeaf < leafs.length; iLeaf++) {
        var leaf = leafs[iLeaf];
        handlers = leaf._listeners;
        if (isArray(handlers)) {

            var position = -1;

            for (var i = 0, length = handlers.length; i < length; i++) {
                if (handlers[i] === listener || handlers[i].listener && handlers[i].listener === listener || handlers[i]._origin && handlers[i]._origin === listener) {
                    position = i;
                    break;
                }
            }

            if (position < 0) {
                continue;
            }

            if (this.wildcard) {
                leaf._listeners.splice(position, 1);
            } else {
                this._events[type].splice(position, 1);
            }

            if (handlers.length === 0) {
                if (this.wildcard) {
                    delete leaf._listeners;
                } else {
                    delete this._events[type];
                }
            }

            this.emit("removeListener", type, listener);

            return this;
        } else if (handlers === listener || handlers.listener && handlers.listener === listener || handlers._origin && handlers._origin === listener) {
            if (this.wildcard) {
                delete leaf._listeners;
            } else {
                delete this._events[type];
            }

            this.emit("removeListener", type, listener);
        }
    }

    function recursivelyGarbageCollect(root) {
        if (root === undefined) {
            return;
        }
        var keys = (0, _keys2.default)(root);
        for (var i in keys) {
            var key = keys[i];
            var obj = root[key];
            if (obj instanceof Function || (typeof obj === 'undefined' ? 'undefined' : (0, _typeof3.default)(obj)) !== "object" || obj === null) continue;
            if ((0, _keys2.default)(obj).length > 0) {
                recursivelyGarbageCollect(root[key]);
            }
            if ((0, _keys2.default)(obj).length === 0) {
                delete root[key];
            }
        }
    }
    recursivelyGarbageCollect(this.listenerTree);

    return this;
};

EventEmitter.prototype.offAny = function (fn) {
    var i = 0,
        l = 0,
        fns;
    if (fn && this._all && this._all.length > 0) {
        fns = this._all;
        for (i = 0, l = fns.length; i < l; i++) {
            if (fn === fns[i]) {
                fns.splice(i, 1);
                this.emit("removeListenerAny", fn);
                return this;
            }
        }
    } else {
        fns = this._all;
        for (i = 0, l = fns.length; i < l; i++) {
            this.emit("removeListenerAny", fns[i]);
        }this._all = [];
    }
    return this;
};

EventEmitter.prototype.removeListener = EventEmitter.prototype.off;

EventEmitter.prototype.removeAllListeners = function (type) {
    if (arguments.length === 0) {
        !this._events || init.call(this);
        return this;
    }

    if (this.wildcard) {
        var ns = typeof type === 'string' ? type.split(this.delimiter) : type.slice();
        var leafs = searchListenerTree.call(this, null, ns, this.listenerTree, 0);

        for (var iLeaf = 0; iLeaf < leafs.length; iLeaf++) {
            var leaf = leafs[iLeaf];
            leaf._listeners = null;
        }
    } else if (this._events) {
        this._events[type] = null;
    }
    return this;
};

EventEmitter.prototype.listeners = function (type) {
    if (this.wildcard) {
        var handlers = [];
        var ns = typeof type === 'string' ? type.split(this.delimiter) : type.slice();
        searchListenerTree.call(this, handlers, ns, this.listenerTree, 0);
        return handlers;
    }

    this._events || init.call(this);

    if (!this._events[type]) this._events[type] = [];
    if (!isArray(this._events[type])) {
        this._events[type] = [this._events[type]];
    }
    return this._events[type];
};

EventEmitter.prototype.eventNames = function () {
    return (0, _keys2.default)(this._events);
};

EventEmitter.prototype.listenerCount = function (type) {
    return this.listeners(type).length;
};

EventEmitter.prototype.listenersAny = function () {

    if (this._all) {
        return this._all;
    } else {
        return [];
    }
};

exports.default = EventEmitter;
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(221)))

/***/ }),
/* 213 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
// module6

exports.default = {
    LOG_LIMIT: 1024,
    AppStatus: {
        FORE_GROUND: 0,
        BACK_GROUND: 1,
        LOCLOCKK: 2
    }
};

/***/ }),
/* 214 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _create = __webpack_require__(30);

var _create2 = _interopRequireDefault(_create);

var _keys = __webpack_require__(37);

var _keys2 = _interopRequireDefault(_keys);

var _assign = __webpack_require__(66);

var _assign2 = _interopRequireDefault(_assign);

var _utils = __webpack_require__(107);

var _utils2 = _interopRequireDefault(_utils);

var _iteratorHandle = __webpack_require__(632);

var _iteratorHandle2 = _interopRequireDefault(_iteratorHandle);

var _parseBehavior = __webpack_require__(486);

var _parseBehavior2 = _interopRequireDefault(_parseBehavior);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var componentInstances = {};

function setComponentInstances(customComponentId, componentInstanceId, webviewId, componentInstance) {
  if (!customComponentId || !componentInstanceId || !webviewId) return;
  if (!componentInstances[webviewId]) componentInstances[webviewId] = {};
  if (!componentInstances[webviewId][customComponentId]) componentInstances[webviewId][customComponentId] = {};
  componentInstances[webviewId][customComponentId][componentInstanceId] = componentInstance;
}

function getComponentInstances(customComponentId, componentInstanceId, webviewId) {
  if (!customComponentId || !componentInstanceId || !webviewId) return;
  if (!componentInstances[webviewId] || !componentInstances[webviewId][customComponentId]) return;
  return componentInstances[webviewId][customComponentId][componentInstanceId];
}

function deleteComponentInstances(customComponentId, componentInstanceId, webviewId) {
  delete componentInstances[webviewId][customComponentId][componentInstanceId];
}

function deleteComponentInstancesByWebviewId(webviewId) {
  delete componentInstances[webviewId];
}

function doComponentLifeTimeByWebviewId(webviewId, type) {
  if (!webviewId || !type || !componentInstances[webviewId]) return;
  var instances = componentInstances[webviewId];
  for (var customComponentId in instances) {
    if (instances.hasOwnProperty(customComponentId)) {
      for (var componentInstanceId in instances[customComponentId]) {
        if (instances[customComponentId].hasOwnProperty(componentInstanceId)) {
          doComponentLifeTime(instances[customComponentId][componentInstanceId], type);
        }
      }
    }
  }
}

var doComponentLifeTime = function doComponentLifeTime(component, type, params) {
  if (component.lifetimes && component.lifetimes[type]) {
    Array.isArray(component.lifetimes[type]) && component.lifetimes[type].forEach(function (i) {
      return i(params);
    });
    typeof component.lifetimes[type] === 'function' && component.lifetimes[type](params);
  } else {
    Array.isArray(component[type]) && component[type].forEach(function (i) {
      return i(params);
    });
    typeof component[type] === 'function' && component[type](params);
  }
};
var lifetimesMap = {
  'onLoad': "created",
  'onShow': "attached",
  'onReady': "ready",
  // 'onHide': "detached",
  'onUnload': "detached"
};
var doPageLifeTime = function doPageLifeTime(page, type, param) {
  if (!page.isTruePage && lifetimesMap[type]) {
    doComponentLifeTime(page, lifetimesMap[type] || '', page.__query__);
  }
  typeof page[type] === 'function' && page[type]((0, _assign2.default)(page.__query__, param));
};

function makeReporterFunction(sourceObj, targetObj, eventName) {
  return function () {
    var res = void 0;
    var func = void 0;
    var funcName = void 0;
    if (sourceObj) {
      func = sourceObj[eventName] ? sourceObj[eventName] : _utils2.default.noop;
      funcName = eventName;
    } else {
      func = eventName;
      funcName = func.name;
    }
    try {
      var startTime = Date.now();
      res = func.apply(targetObj, arguments);
      var runTime = Date.now() - startTime;
      runTime > 1e3 && Reporter.slowReport({
        key: "pageInvoke",
        cost: runTime,
        extend: "at " + targetObj.__route__ + " page " + funcName + " function"
      });
    } catch (err) {
      Reporter.thirdErrorReport({
        error: err,
        extend: 'at "' + targetObj.__route__ + '" page ' + funcName + " function"
      });
    }
    return res;
  };
}

var sysEventKeys = ["onLoad", "onReady", "onShow", "onRouteEnd", "onHide", "onUnload", "onShareAppMessage"];
var componentSysEventKeys = ["created", "attached", "ready", "moved", "detached", "error", "onShareAppMessage"];
var isSysAttr = function isSysAttr(key) {
  //校验e是否为系统事件或属性
  for (var i = 0; i < sysEventKeys.length; ++i) {
    if (sysEventKeys[i] === key) {
      return true;
    }
  }
  return "data" === key;
};
var baseAttrs = ["__wxWebviewId__", "__route__"];

var isBaseAttr = function isBaseAttr(name) {
  return baseAttrs.indexOf(name) !== -1;
};

var copyComponentObjByKey = function copyComponentObjByKey(curCom, comObj, attrName) {
  // 定义页面其它方法与属性
  if (isBaseAttr(attrName)) {
    _utils2.default.warn('关键字保护', "Component's " + attrName + ' is write-protected');
    return;
  }
  if (!isSysAttr(attrName)) {
    if (attrName === 'methods') {
      var methods = comObj[attrName];

      curCom['methods'] = curCom['methods'] || {};
      for (var k in methods) {
        if ('Function' === _utils2.default.getDataType(methods[k])) {
          curCom[k] = curCom['methods'][k] = makeReporterFunction(methods, curCom, k);
        }
      }
    } else if (attrName === 'lifetimes') {
      curCom[attrName] = {};
      for (var lifetime in comObj[attrName]) {
        var hooks = comObj[attrName][lifetime];
        hooks = Array.isArray(hooks) ? hooks : [hooks];
        curCom[attrName][lifetime] = hooks.map(function (i) {
          return makeReporterFunction(null, curCom, i);
        });
      }
    } else if (componentSysEventKeys.includes(attrName)) {
      if (Array.isArray(comObj[attrName]) && _parseBehavior2.default.LIFECYCLE_HOOKS.includes(attrName)) {
        curCom[attrName] = comObj[attrName].map(function (i) {
          return makeReporterFunction(null, curCom, i);
        });
      } else {
        curCom[attrName] = makeReporterFunction(comObj, curCom, attrName);
      }
    } else if (attrName === 'relations') {
      (0, _keys2.default)(curCom[attrName]).forEach(function (key) {
        var relation = curCom[attrName];
        (0, _keys2.default)(relation[key] || {}).forEach(function (itemKey) {
          var relationItem = relation[key][itemKey];
          if (typeof relationItem === 'function') {
            relation[key][itemKey] = makeReporterFunction(null, curCom, relationItem);
          }
        });
      });
    }
  }
};

var copyPageObjByKey = function copyPageObjByKey(curPage, pageObj, attrName) {
  //定义页面其它方法与属性
  if (isBaseAttr(attrName)) {
    _utils2.default.warn("关键字保护", "Page's " + attrName + " is write-protected");
  } else if (!isSysAttr(attrName)) {
    if (_utils2.default.getDataType(pageObj[attrName]) === 'Function') {
      curPage[attrName] = makeReporterFunction(pageObj, curPage, attrName);
    } else {
      curPage[attrName] = (0, _iteratorHandle2.default)(pageObj[attrName]);
    }
  }
};

var copyPageObjBySysEvent = function copyPageObjBySysEvent(curPage, pageObj) {
  sysEventKeys.forEach(function (eventName) {
    //定义页面事件
    curPage[eventName] = makeReporterFunction(pageObj, curPage, eventName);
  });
};

var setBaseAttrs = function setBaseAttrs(curPage, pageBaseAttr) {
  baseAttrs.forEach(function (key) {
    curPage.__defineSetter__(key, function () {
      _utils2.default.warn("关键字保护", "should not change the protected attribute " + key);
    });
    curPage.__defineGetter__(key, function () {
      return pageBaseAttr[key];
    });
  });
};

function _getBehaviorProp(behaviors, propName, component) {
  var prop = behaviors.map(function (i) {
    return i[propName];
  }).filter(function (i) {
    return i;
  }).reduce(function (obj, i) {
    return (0, _assign2.default)(obj, i);
  }, {});
  return (0, _assign2.default)({}, prop, component[propName]);
}

function initBehaviors(comObj) {
  if (comObj.behaviors && Array.isArray(comObj.behaviors)) {
    var behaviors = comObj.behaviors.map(function (i) {
      return _parseBehavior2.default.getBehavior(i);
    });
    comObj.data = _getBehaviorProp(behaviors, 'data', comObj);
    comObj.properties = _getBehaviorProp(behaviors, 'properties', comObj);
    comObj.methods = _getBehaviorProp(behaviors, 'methods', comObj);
    _parseBehavior2.default.LIFECYCLE_HOOKS.forEach(function (i) {
      var lifeHook = void 0;
      var hasLifeTimes = false;
      if (comObj.lifetimes && typeof comObj.lifetimes[i] === 'function') {
        lifeHook = [comObj.lifetimes[i]];
        hasLifeTimes = true;
      } else {
        if (typeof comObj[i] === 'function') {
          lifeHook = [comObj[i]];
        } else if (!Array.isArray(comObj[i])) {
          lifeHook = [];
        }
      }
      behaviors.forEach(function (behavior) {
        if (hasLifeTimes) {
          comObj.lifetimes[i] = (behavior[i] || []).concat(lifeHook);
        } else {
          comObj[i] = (behavior[i] || []).concat(lifeHook);
        }
      });
    });
  }
}

function initRelations(curPage, comObj, slotCustomComponentId, slotComponentInstanceId, webviewId) {
  if (comObj.relations) {
    var id = curPage.id,
        instanceId = curPage.instanceId;

    curPage.relations = (0, _create2.default)(null);
    (0, _keys2.default)(comObj.relations).forEach(function (i) {
      var path = _utils2.default.getFullPath(id, i); // 相对路径转绝对路径后的目标组件
      var type = comObj.relations[i].type;

      curPage.relations[path] = comObj.relations[i];
      curPage.relationInstance[path] = [];
      if (type === 'parent' && slotCustomComponentId && slotComponentInstanceId && path === slotCustomComponentId) {
        var parentComponent = getComponentInstances(slotCustomComponentId, slotComponentInstanceId, webviewId);

        curPage.relations[path].instance = {
          id: slotCustomComponentId,
          instanceId: slotComponentInstanceId
        };
        curPage.relationInstance[path].push({
          id: slotCustomComponentId,
          instanceId: slotComponentInstanceId
        });

        if (Array.isArray(parentComponent.relationInstance[id])) {
          parentComponent.relationInstance[id].push({
            id: id,
            instanceId: instanceId
          });
        }
        if (parentComponent.id === path && !parentComponent.relations[id]) {
          parentComponent.relations[id] = {
            type: "child"
          };
        }
      }
    });
  }
}

var relationMap = {
  'attached': 'linked',
  'moved': 'linkChanged',
  'detached': 'unlinked'
};

function doRelationFunc(component, type, webviewId) {
  (0, _keys2.default)(component.relations || []).forEach(function (key) {
    var relation = component.relations[key];
    if (relation.type === 'parent' && relation.instance) {
      var _relation$instance = relation.instance,
          id = _relation$instance.id,
          instanceId = _relation$instance.instanceId;

      var parentComponent = getComponentInstances(id, instanceId, webviewId);
      var parentRelation = parentComponent.relations[component.id];
      if (parentRelation) {
        var parenFunc = parentRelation[relationMap[type]];
        typeof parenFunc === 'function' && parenFunc(component);
      }
      var childFunc = relation[relationMap[type]];
      typeof childFunc === 'function' && childFunc(parentComponent);
    }
  });
}

var idSelectorMap = {};
var classSelectorMap = {};

function setSelectorMap(component, webviewId) {
  if (!idSelectorMap[webviewId]) idSelectorMap[webviewId] = {};
  if (!classSelectorMap[webviewId]) classSelectorMap[webviewId] = {};
  var _component$selectors = component.selectors,
      id = _component$selectors.id,
      className = _component$selectors.className;

  var data = {
    customComponentId: component.id,
    componentInstanceId: component.instanceId
  };
  if (id) {
    if (!idSelectorMap[webviewId][id]) idSelectorMap[webviewId][id] = [];
    idSelectorMap[webviewId][id].push(data);
  }
  if (className) {
    className.split(' ').filter(function (i) {
      return i;
    }).forEach(function (i) {
      if (!classSelectorMap[webviewId][i]) classSelectorMap[webviewId][i] = [];
      classSelectorMap[webviewId][i].push(data);
    });
  }
}

function getSelectComponent(selector, webviewId) {
  var map = void 0;
  if (selector.startsWith('.')) {
    map = classSelectorMap;
  } else if (selector.startsWith('#')) {
    map = idSelectorMap;
  }
  if (!map) return null;
  var list = map[webviewId][selector.substr(1)];
  if (!list) return null;
  return list.map(function (i) {
    return getComponentInstances(i.customComponentId, i.componentInstanceId, webviewId);
  }).filter(function (i) {
    return i;
  });
}

function deleteSelectorMapByWebviewId(webviewId) {
  delete idSelectorMap[webviewId];
  delete classSelectorMap[webviewId];
}

exports.default = {
  doComponentLifeTime: doComponentLifeTime,
  doPageLifeTime: doPageLifeTime,
  copyComponentObjByKey: copyComponentObjByKey,
  copyPageObjByKey: copyPageObjByKey,
  copyPageObjBySysEvent: copyPageObjBySysEvent,
  setBaseAttrs: setBaseAttrs,
  setComponentInstances: setComponentInstances,
  getComponentInstances: getComponentInstances,
  deleteComponentInstances: deleteComponentInstances,
  deleteComponentInstancesByWebviewId: deleteComponentInstancesByWebviewId,
  doComponentLifeTimeByWebviewId: doComponentLifeTimeByWebviewId,
  initBehaviors: initBehaviors,
  initRelations: initRelations,
  doRelationFunc: doRelationFunc,
  setSelectorMap: setSelectorMap,
  getSelectComponent: getSelectComponent,
  deleteSelectorMapByWebviewId: deleteSelectorMapByWebviewId
};

/***/ }),
/* 215 */,
/* 216 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(439), __esModule: true };

/***/ }),
/* 217 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// ECMAScript 6 symbols shim
var global = __webpack_require__(12);
var has = __webpack_require__(57);
var DESCRIPTORS = __webpack_require__(45);
var $export = __webpack_require__(18);
var redefine = __webpack_require__(197);
var META = __webpack_require__(447).KEY;
var $fails = __webpack_require__(65);
var shared = __webpack_require__(139);
var setToStringTag = __webpack_require__(99);
var uid = __webpack_require__(96);
var wks = __webpack_require__(14);
var wksExt = __webpack_require__(144);
var wksDefine = __webpack_require__(145);
var enumKeys = __webpack_require__(448);
var isArray = __webpack_require__(449);
var anObject = __webpack_require__(35);
var isObject = __webpack_require__(44);
var toIObject = __webpack_require__(59);
var toPrimitive = __webpack_require__(142);
var createDesc = __webpack_require__(77);
var _create = __webpack_require__(143);
var gOPNExt = __webpack_require__(450);
var $GOPD = __webpack_require__(153);
var $DP = __webpack_require__(40);
var $keys = __webpack_require__(74);
var gOPD = $GOPD.f;
var dP = $DP.f;
var gOPN = gOPNExt.f;
var $Symbol = global.Symbol;
var $JSON = global.JSON;
var _stringify = $JSON && $JSON.stringify;
var PROTOTYPE = 'prototype';
var HIDDEN = wks('_hidden');
var TO_PRIMITIVE = wks('toPrimitive');
var isEnum = {}.propertyIsEnumerable;
var SymbolRegistry = shared('symbol-registry');
var AllSymbols = shared('symbols');
var OPSymbols = shared('op-symbols');
var ObjectProto = Object[PROTOTYPE];
var USE_NATIVE = typeof $Symbol == 'function';
var QObject = global.QObject;
// Don't use setters in Qt Script, https://github.com/zloirock/core-js/issues/173
var setter = !QObject || !QObject[PROTOTYPE] || !QObject[PROTOTYPE].findChild;

// fallback for old Android, https://code.google.com/p/v8/issues/detail?id=687
var setSymbolDesc = DESCRIPTORS && $fails(function () {
  return _create(dP({}, 'a', {
    get: function () { return dP(this, 'a', { value: 7 }).a; }
  })).a != 7;
}) ? function (it, key, D) {
  var protoDesc = gOPD(ObjectProto, key);
  if (protoDesc) delete ObjectProto[key];
  dP(it, key, D);
  if (protoDesc && it !== ObjectProto) dP(ObjectProto, key, protoDesc);
} : dP;

var wrap = function (tag) {
  var sym = AllSymbols[tag] = _create($Symbol[PROTOTYPE]);
  sym._k = tag;
  return sym;
};

var isSymbol = USE_NATIVE && typeof $Symbol.iterator == 'symbol' ? function (it) {
  return typeof it == 'symbol';
} : function (it) {
  return it instanceof $Symbol;
};

var $defineProperty = function defineProperty(it, key, D) {
  if (it === ObjectProto) $defineProperty(OPSymbols, key, D);
  anObject(it);
  key = toPrimitive(key, true);
  anObject(D);
  if (has(AllSymbols, key)) {
    if (!D.enumerable) {
      if (!has(it, HIDDEN)) dP(it, HIDDEN, createDesc(1, {}));
      it[HIDDEN][key] = true;
    } else {
      if (has(it, HIDDEN) && it[HIDDEN][key]) it[HIDDEN][key] = false;
      D = _create(D, { enumerable: createDesc(0, false) });
    } return setSymbolDesc(it, key, D);
  } return dP(it, key, D);
};
var $defineProperties = function defineProperties(it, P) {
  anObject(it);
  var keys = enumKeys(P = toIObject(P));
  var i = 0;
  var l = keys.length;
  var key;
  while (l > i) $defineProperty(it, key = keys[i++], P[key]);
  return it;
};
var $create = function create(it, P) {
  return P === undefined ? _create(it) : $defineProperties(_create(it), P);
};
var $propertyIsEnumerable = function propertyIsEnumerable(key) {
  var E = isEnum.call(this, key = toPrimitive(key, true));
  if (this === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return false;
  return E || !has(this, key) || !has(AllSymbols, key) || has(this, HIDDEN) && this[HIDDEN][key] ? E : true;
};
var $getOwnPropertyDescriptor = function getOwnPropertyDescriptor(it, key) {
  it = toIObject(it);
  key = toPrimitive(key, true);
  if (it === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return;
  var D = gOPD(it, key);
  if (D && has(AllSymbols, key) && !(has(it, HIDDEN) && it[HIDDEN][key])) D.enumerable = true;
  return D;
};
var $getOwnPropertyNames = function getOwnPropertyNames(it) {
  var names = gOPN(toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (!has(AllSymbols, key = names[i++]) && key != HIDDEN && key != META) result.push(key);
  } return result;
};
var $getOwnPropertySymbols = function getOwnPropertySymbols(it) {
  var IS_OP = it === ObjectProto;
  var names = gOPN(IS_OP ? OPSymbols : toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (has(AllSymbols, key = names[i++]) && (IS_OP ? has(ObjectProto, key) : true)) result.push(AllSymbols[key]);
  } return result;
};

// 19.4.1.1 Symbol([description])
if (!USE_NATIVE) {
  $Symbol = function Symbol() {
    if (this instanceof $Symbol) throw TypeError('Symbol is not a constructor!');
    var tag = uid(arguments.length > 0 ? arguments[0] : undefined);
    var $set = function (value) {
      if (this === ObjectProto) $set.call(OPSymbols, value);
      if (has(this, HIDDEN) && has(this[HIDDEN], tag)) this[HIDDEN][tag] = false;
      setSymbolDesc(this, tag, createDesc(1, value));
    };
    if (DESCRIPTORS && setter) setSymbolDesc(ObjectProto, tag, { configurable: true, set: $set });
    return wrap(tag);
  };
  redefine($Symbol[PROTOTYPE], 'toString', function toString() {
    return this._k;
  });

  $GOPD.f = $getOwnPropertyDescriptor;
  $DP.f = $defineProperty;
  __webpack_require__(200).f = gOPNExt.f = $getOwnPropertyNames;
  __webpack_require__(100).f = $propertyIsEnumerable;
  __webpack_require__(146).f = $getOwnPropertySymbols;

  if (DESCRIPTORS && !__webpack_require__(76)) {
    redefine(ObjectProto, 'propertyIsEnumerable', $propertyIsEnumerable, true);
  }

  wksExt.f = function (name) {
    return wrap(wks(name));
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, { Symbol: $Symbol });

for (var es6Symbols = (
  // 19.4.2.2, 19.4.2.3, 19.4.2.4, 19.4.2.6, 19.4.2.8, 19.4.2.9, 19.4.2.10, 19.4.2.11, 19.4.2.12, 19.4.2.13, 19.4.2.14
  'hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables'
).split(','), j = 0; es6Symbols.length > j;)wks(es6Symbols[j++]);

for (var wellKnownSymbols = $keys(wks.store), k = 0; wellKnownSymbols.length > k;) wksDefine(wellKnownSymbols[k++]);

$export($export.S + $export.F * !USE_NATIVE, 'Symbol', {
  // 19.4.2.1 Symbol.for(key)
  'for': function (key) {
    return has(SymbolRegistry, key += '')
      ? SymbolRegistry[key]
      : SymbolRegistry[key] = $Symbol(key);
  },
  // 19.4.2.5 Symbol.keyFor(sym)
  keyFor: function keyFor(sym) {
    if (!isSymbol(sym)) throw TypeError(sym + ' is not a symbol!');
    for (var key in SymbolRegistry) if (SymbolRegistry[key] === sym) return key;
  },
  useSetter: function () { setter = true; },
  useSimple: function () { setter = false; }
});

$export($export.S + $export.F * !USE_NATIVE, 'Object', {
  // 19.1.2.2 Object.create(O [, Properties])
  create: $create,
  // 19.1.2.4 Object.defineProperty(O, P, Attributes)
  defineProperty: $defineProperty,
  // 19.1.2.3 Object.defineProperties(O, Properties)
  defineProperties: $defineProperties,
  // 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
  getOwnPropertyDescriptor: $getOwnPropertyDescriptor,
  // 19.1.2.7 Object.getOwnPropertyNames(O)
  getOwnPropertyNames: $getOwnPropertyNames,
  // 19.1.2.8 Object.getOwnPropertySymbols(O)
  getOwnPropertySymbols: $getOwnPropertySymbols
});

// 24.3.2 JSON.stringify(value [, replacer [, space]])
$JSON && $export($export.S + $export.F * (!USE_NATIVE || $fails(function () {
  var S = $Symbol();
  // MS Edge converts symbol values to JSON as {}
  // WebKit converts symbol values to JSON as null
  // V8 throws on boxed symbols
  return _stringify([S]) != '[null]' || _stringify({ a: S }) != '{}' || _stringify(Object(S)) != '{}';
})), 'JSON', {
  stringify: function stringify(it) {
    var args = [it];
    var i = 1;
    var replacer, $replacer;
    while (arguments.length > i) args.push(arguments[i++]);
    $replacer = replacer = args[1];
    if (!isObject(replacer) && it === undefined || isSymbol(it)) return; // IE8 returns string on undefined
    if (!isArray(replacer)) replacer = function (key, value) {
      if (typeof $replacer == 'function') value = $replacer.call(this, key, value);
      if (!isSymbol(value)) return value;
    };
    args[1] = replacer;
    return _stringify.apply($JSON, args);
  }
});

// 19.4.3.4 Symbol.prototype[@@toPrimitive](hint)
$Symbol[PROTOTYPE][TO_PRIMITIVE] || __webpack_require__(58)($Symbol[PROTOTYPE], TO_PRIMITIVE, $Symbol[PROTOTYPE].valueOf);
// 19.4.3.5 Symbol.prototype[@@toStringTag]
setToStringTag($Symbol, 'Symbol');
// 20.2.1.9 Math[@@toStringTag]
setToStringTag(Math, 'Math', true);
// 24.3.3 JSON[@@toStringTag]
setToStringTag(global.JSON, 'JSON', true);


/***/ }),
/* 218 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(453), __esModule: true };

/***/ }),
/* 219 */,
/* 220 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {// 'path' module extracted from Node.js v8.11.1 (only the posix part)
// transplited with Babel

// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.



Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof2 = __webpack_require__(13);

var _typeof3 = _interopRequireDefault(_typeof2);

var _stringify = __webpack_require__(36);

var _stringify2 = _interopRequireDefault(_stringify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function assertPath(path) {
  if (typeof path !== 'string') {
    throw new TypeError('Path must be a string. Received ' + (0, _stringify2.default)(path));
  }
}

// Resolves . and .. elements in a path with directory names
function normalizeStringPosix(path, allowAboveRoot) {
  var res = '';
  var lastSegmentLength = 0;
  var lastSlash = -1;
  var dots = 0;
  var code;
  for (var i = 0; i <= path.length; ++i) {
    if (i < path.length) code = path.charCodeAt(i);else if (code === 47 /*/*/) break;else code = 47; /*/*/
    if (code === 47 /*/*/) {
        if (lastSlash === i - 1 || dots === 1) {
          // NOOP
        } else if (lastSlash !== i - 1 && dots === 2) {
          if (res.length < 2 || lastSegmentLength !== 2 || res.charCodeAt(res.length - 1) !== 46 /*.*/ || res.charCodeAt(res.length - 2) !== 46 /*.*/) {
              if (res.length > 2) {
                var lastSlashIndex = res.lastIndexOf('/');
                if (lastSlashIndex !== res.length - 1) {
                  if (lastSlashIndex === -1) {
                    res = '';
                    lastSegmentLength = 0;
                  } else {
                    res = res.slice(0, lastSlashIndex);
                    lastSegmentLength = res.length - 1 - res.lastIndexOf('/');
                  }
                  lastSlash = i;
                  dots = 0;
                  continue;
                }
              } else if (res.length === 2 || res.length === 1) {
                res = '';
                lastSegmentLength = 0;
                lastSlash = i;
                dots = 0;
                continue;
              }
            }
          if (allowAboveRoot) {
            if (res.length > 0) res += '/..';else res = '..';
            lastSegmentLength = 2;
          }
        } else {
          if (res.length > 0) res += '/' + path.slice(lastSlash + 1, i);else res = path.slice(lastSlash + 1, i);
          lastSegmentLength = i - lastSlash - 1;
        }
        lastSlash = i;
        dots = 0;
      } else if (code === 46 /*.*/ && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}

function _format(sep, pathObject) {
  var dir = pathObject.dir || pathObject.root;
  var base = pathObject.base || (pathObject.name || '') + (pathObject.ext || '');
  if (!dir) {
    return base;
  }
  if (dir === pathObject.root) {
    return dir + base;
  }
  return dir + sep + base;
}

var posix = {
  // path.resolve([from ...], to)
  resolve: function resolve() {
    var resolvedPath = '';
    var resolvedAbsolute = false;
    var cwd;

    for (var i = arguments.length - 1; i >= -1 && !resolvedAbsolute; i--) {
      var path;
      if (i >= 0) path = arguments[i];else {
        if (cwd === undefined) cwd = process.cwd();
        path = cwd;
      }

      assertPath(path);

      // Skip empty entries
      if (path.length === 0) {
        continue;
      }

      resolvedPath = path + '/' + resolvedPath;
      resolvedAbsolute = path.charCodeAt(0) === 47; /*/*/
    }

    // At this point the path should be resolved to a full absolute path, but
    // handle relative paths to be safe (might happen when process.cwd() fails)

    // Normalize the path
    resolvedPath = normalizeStringPosix(resolvedPath, !resolvedAbsolute);

    if (resolvedAbsolute) {
      if (resolvedPath.length > 0) return '/' + resolvedPath;else return '/';
    } else if (resolvedPath.length > 0) {
      return resolvedPath;
    } else {
      return '.';
    }
  },

  normalize: function normalize(path) {
    assertPath(path);

    if (path.length === 0) return '.';

    var isAbsolute = path.charCodeAt(0) === 47; /*/*/
    var trailingSeparator = path.charCodeAt(path.length - 1) === 47; /*/*/

    // Normalize the path
    path = normalizeStringPosix(path, !isAbsolute);

    if (path.length === 0 && !isAbsolute) path = '.';
    if (path.length > 0 && trailingSeparator) path += '/';

    if (isAbsolute) return '/' + path;
    return path;
  },

  isAbsolute: function isAbsolute(path) {
    assertPath(path);
    return path.length > 0 && path.charCodeAt(0) === 47; /*/*/
  },

  join: function join() {
    if (arguments.length === 0) return '.';
    var joined;
    for (var i = 0; i < arguments.length; ++i) {
      var arg = arguments[i];
      assertPath(arg);
      if (arg.length > 0) {
        if (joined === undefined) joined = arg;else joined += '/' + arg;
      }
    }
    if (joined === undefined) return '.';
    return posix.normalize(joined);
  },

  relative: function relative(from, to) {
    assertPath(from);
    assertPath(to);

    if (from === to) return '';

    from = posix.resolve(from);
    to = posix.resolve(to);

    if (from === to) return '';

    // Trim any leading backslashes
    var fromStart = 1;
    for (; fromStart < from.length; ++fromStart) {
      if (from.charCodeAt(fromStart) !== 47 /*/*/) break;
    }
    var fromEnd = from.length;
    var fromLen = fromEnd - fromStart;

    // Trim any leading backslashes
    var toStart = 1;
    for (; toStart < to.length; ++toStart) {
      if (to.charCodeAt(toStart) !== 47 /*/*/) break;
    }
    var toEnd = to.length;
    var toLen = toEnd - toStart;

    // Compare paths to find the longest common path from root
    var length = fromLen < toLen ? fromLen : toLen;
    var lastCommonSep = -1;
    var i = 0;
    for (; i <= length; ++i) {
      if (i === length) {
        if (toLen > length) {
          if (to.charCodeAt(toStart + i) === 47 /*/*/) {
              // We get here if `from` is the exact base path for `to`.
              // For example: from='/foo/bar'; to='/foo/bar/baz'
              return to.slice(toStart + i + 1);
            } else if (i === 0) {
            // We get here if `from` is the root
            // For example: from='/'; to='/foo'
            return to.slice(toStart + i);
          }
        } else if (fromLen > length) {
          if (from.charCodeAt(fromStart + i) === 47 /*/*/) {
              // We get here if `to` is the exact base path for `from`.
              // For example: from='/foo/bar/baz'; to='/foo/bar'
              lastCommonSep = i;
            } else if (i === 0) {
            // We get here if `to` is the root.
            // For example: from='/foo'; to='/'
            lastCommonSep = 0;
          }
        }
        break;
      }
      var fromCode = from.charCodeAt(fromStart + i);
      var toCode = to.charCodeAt(toStart + i);
      if (fromCode !== toCode) break;else if (fromCode === 47 /*/*/) lastCommonSep = i;
    }

    var out = '';
    // Generate the relative path based on the path difference between `to`
    // and `from`
    for (i = fromStart + lastCommonSep + 1; i <= fromEnd; ++i) {
      if (i === fromEnd || from.charCodeAt(i) === 47 /*/*/) {
          if (out.length === 0) out += '..';else out += '/..';
        }
    }

    // Lastly, append the rest of the destination (`to`) path that comes after
    // the common path parts
    if (out.length > 0) return out + to.slice(toStart + lastCommonSep);else {
      toStart += lastCommonSep;
      if (to.charCodeAt(toStart) === 47 /*/*/) ++toStart;
      return to.slice(toStart);
    }
  },

  _makeLong: function _makeLong(path) {
    return path;
  },

  dirname: function dirname(path) {
    assertPath(path);
    if (path.length === 0) return '.';
    var code = path.charCodeAt(0);
    var hasRoot = code === 47; /*/*/
    var end = -1;
    var matchedSlash = true;
    for (var i = path.length - 1; i >= 1; --i) {
      code = path.charCodeAt(i);
      if (code === 47 /*/*/) {
          if (!matchedSlash) {
            end = i;
            break;
          }
        } else {
        // We saw the first non-path separator
        matchedSlash = false;
      }
    }

    if (end === -1) return hasRoot ? '/' : '.';
    if (hasRoot && end === 1) return '//';
    return path.slice(0, end);
  },

  basename: function basename(path, ext) {
    if (ext !== undefined && typeof ext !== 'string') throw new TypeError('"ext" argument must be a string');
    assertPath(path);

    var start = 0;
    var end = -1;
    var matchedSlash = true;
    var i;

    if (ext !== undefined && ext.length > 0 && ext.length <= path.length) {
      if (ext.length === path.length && ext === path) return '';
      var extIdx = ext.length - 1;
      var firstNonSlashEnd = -1;
      for (i = path.length - 1; i >= 0; --i) {
        var code = path.charCodeAt(i);
        if (code === 47 /*/*/) {
            // If we reached a path separator that was not part of a set of path
            // separators at the end of the string, stop now
            if (!matchedSlash) {
              start = i + 1;
              break;
            }
          } else {
          if (firstNonSlashEnd === -1) {
            // We saw the first non-path separator, remember this index in case
            // we need it if the extension ends up not matching
            matchedSlash = false;
            firstNonSlashEnd = i + 1;
          }
          if (extIdx >= 0) {
            // Try to match the explicit extension
            if (code === ext.charCodeAt(extIdx)) {
              if (--extIdx === -1) {
                // We matched the extension, so mark this as the end of our path
                // component
                end = i;
              }
            } else {
              // Extension does not match, so our result is the entire path
              // component
              extIdx = -1;
              end = firstNonSlashEnd;
            }
          }
        }
      }

      if (start === end) end = firstNonSlashEnd;else if (end === -1) end = path.length;
      return path.slice(start, end);
    } else {
      for (i = path.length - 1; i >= 0; --i) {
        if (path.charCodeAt(i) === 47 /*/*/) {
            // If we reached a path separator that was not part of a set of path
            // separators at the end of the string, stop now
            if (!matchedSlash) {
              start = i + 1;
              break;
            }
          } else if (end === -1) {
          // We saw the first non-path separator, mark this as the end of our
          // path component
          matchedSlash = false;
          end = i + 1;
        }
      }

      if (end === -1) return '';
      return path.slice(start, end);
    }
  },

  extname: function extname(path) {
    assertPath(path);
    var startDot = -1;
    var startPart = 0;
    var end = -1;
    var matchedSlash = true;
    // Track the state of characters (if any) we see before our first dot and
    // after any path separator we find
    var preDotState = 0;
    for (var i = path.length - 1; i >= 0; --i) {
      var code = path.charCodeAt(i);
      if (code === 47 /*/*/) {
          // If we reached a path separator that was not part of a set of path
          // separators at the end of the string, stop now
          if (!matchedSlash) {
            startPart = i + 1;
            break;
          }
          continue;
        }
      if (end === -1) {
        // We saw the first non-path separator, mark this as the end of our
        // extension
        matchedSlash = false;
        end = i + 1;
      }
      if (code === 46 /*.*/) {
          // If this is our first dot, mark it as the start of our extension
          if (startDot === -1) startDot = i;else if (preDotState !== 1) preDotState = 1;
        } else if (startDot !== -1) {
        // We saw a non-dot and non-path separator before our dot, so we should
        // have a good chance at having a non-empty extension
        preDotState = -1;
      }
    }

    if (startDot === -1 || end === -1 ||
    // We saw a non-dot character immediately before the dot
    preDotState === 0 ||
    // The (right-most) trimmed path component is exactly '..'
    preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
      return '';
    }
    return path.slice(startDot, end);
  },

  format: function format(pathObject) {
    if (pathObject === null || (typeof pathObject === 'undefined' ? 'undefined' : (0, _typeof3.default)(pathObject)) !== 'object') {
      throw new TypeError('The "pathObject" argument must be of type Object. Received type ' + (typeof pathObject === 'undefined' ? 'undefined' : (0, _typeof3.default)(pathObject)));
    }
    return _format('/', pathObject);
  },

  parse: function parse(path) {
    assertPath(path);

    var ret = { root: '', dir: '', base: '', ext: '', name: '' };
    if (path.length === 0) return ret;
    var code = path.charCodeAt(0);
    var isAbsolute = code === 47; /*/*/
    var start;
    if (isAbsolute) {
      ret.root = '/';
      start = 1;
    } else {
      start = 0;
    }
    var startDot = -1;
    var startPart = 0;
    var end = -1;
    var matchedSlash = true;
    var i = path.length - 1;

    // Track the state of characters (if any) we see before our first dot and
    // after any path separator we find
    var preDotState = 0;

    // Get non-dir info
    for (; i >= start; --i) {
      code = path.charCodeAt(i);
      if (code === 47 /*/*/) {
          // If we reached a path separator that was not part of a set of path
          // separators at the end of the string, stop now
          if (!matchedSlash) {
            startPart = i + 1;
            break;
          }
          continue;
        }
      if (end === -1) {
        // We saw the first non-path separator, mark this as the end of our
        // extension
        matchedSlash = false;
        end = i + 1;
      }
      if (code === 46 /*.*/) {
          // If this is our first dot, mark it as the start of our extension
          if (startDot === -1) startDot = i;else if (preDotState !== 1) preDotState = 1;
        } else if (startDot !== -1) {
        // We saw a non-dot and non-path separator before our dot, so we should
        // have a good chance at having a non-empty extension
        preDotState = -1;
      }
    }

    if (startDot === -1 || end === -1 ||
    // We saw a non-dot character immediately before the dot
    preDotState === 0 ||
    // The (right-most) trimmed path component is exactly '..'
    preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
      if (end !== -1) {
        if (startPart === 0 && isAbsolute) ret.base = ret.name = path.slice(1, end);else ret.base = ret.name = path.slice(startPart, end);
      }
    } else {
      if (startPart === 0 && isAbsolute) {
        ret.name = path.slice(1, startDot);
        ret.base = path.slice(1, end);
      } else {
        ret.name = path.slice(startPart, startDot);
        ret.base = path.slice(startPart, end);
      }
      ret.ext = path.slice(startDot, end);
    }

    if (startPart > 0) ret.dir = path.slice(0, startPart - 1);else if (isAbsolute) ret.dir = '/';

    return ret;
  },

  sep: '/',
  delimiter: ':',
  win32: null,
  posix: null
};

posix.posix = posix;

exports.default = posix;
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(221)))

/***/ }),
/* 221 */
/***/ (function(module, exports) {

// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };


/***/ }),
/* 222 */,
/* 223 */,
/* 224 */,
/* 225 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _assign = __webpack_require__(66);

var _assign2 = _interopRequireDefault(_assign);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _assign2.default || function (target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];

    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }

  return target;
};

/***/ }),
/* 226 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof2 = __webpack_require__(13);

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// 处理传参为函数
var id = 0;
var functionMap = {};
var functionRegexp = /^@@function_(\d)+@@$/;

function functionToString(data, webviewId) {
  var res = void 0;
  if ((typeof data === 'undefined' ? 'undefined' : (0, _typeof3.default)(data)) === 'object') {
    res = Array.isArray(data) ? [] : {};
    for (var key in data) {
      if (data.hasOwnProperty(key)) {
        var _element = data[key];
        if ((typeof _element === 'undefined' ? 'undefined' : (0, _typeof3.default)(_element)) === 'object' && _element !== null) {
          res[key] = functionToString(_element, webviewId);
        } else if (typeof _element === 'function') {
          res[key] = _setFunc(_element, webviewId);
        } else {
          res[key] = _element;
        }
      }
    }
  } else if (typeof data === 'function') {
    res = _setFunc(data, webviewId);
  } else {
    res = data;
  }
  return res;
}

function setFunction(data, webviewId) {
  var res = void 0;
  if (data === null || data === undefined) {
    res = data;
  } else if ((typeof data === 'undefined' ? 'undefined' : (0, _typeof3.default)(data)) === 'object') {
    res = Array.isArray(data) ? [] : {};
    for (var key in data) {
      if (data.hasOwnProperty(key)) {
        var _element2 = data[key];
        if ((typeof _element2 === 'undefined' ? 'undefined' : (0, _typeof3.default)(_element2)) === 'object' && _element2 !== null) {
          res[key] = setFunction(_element2, webviewId);
        } else if (typeof _element2 === 'string' && _element2.match(functionRegexp)) {
          res[key] = _getFunc(_element2, webviewId);
        } else {
          res[key] = _element2;
        }
      }
    }
  } else if (typeof data === 'string' && data.match(functionRegexp)) {
    res = _getFunc(element, data);
  } else {
    res = data;
  }
  return res;
}

function deleteFunctions(webviewId) {
  delete functionMap[webviewId];
}

function _getFunc(funId, webviewId) {
  return functionMap[webviewId] && functionMap[webviewId][funId];
}

function _setFunc(func, webviewId) {
  var funId = '@@function_' + id++ + '@@';
  if (!functionMap[webviewId]) {
    functionMap[webviewId] = {};
  }
  functionMap[webviewId][funId] = func;
  return funId;
}

function resetFuncion() {
  functionMap = {};
}

exports.default = {
  functionToString: functionToString,
  setFunction: setFunction,
  deleteFunctions: deleteFunctions,
  resetFuncion: resetFuncion
};

/***/ }),
/* 227 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(228);

/***/ }),
/* 228 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {

__webpack_require__(229);

__webpack_require__(426);

__webpack_require__(427);

if (global._babelPolyfill) {
  throw new Error("only one instance of babel-polyfill is allowed");
}
global._babelPolyfill = true;

var DEFINE_PROPERTY = "defineProperty";
function define(O, key, value) {
  O[key] || Object[DEFINE_PROPERTY](O, key, {
    writable: true,
    configurable: true,
    value: value
  });
}

define(String.prototype, "padLeft", "".padStart);
define(String.prototype, "padRight", "".padEnd);

"pop,reverse,shift,keys,values,entries,indexOf,every,some,forEach,map,filter,find,findIndex,includes,join,slice,concat,push,splice,unshift,sort,lastIndexOf,reduce,reduceRight,copyWithin,fill".split(",").forEach(function (key) {
  [][key] && define(Array, key, Function.call.bind([][key]));
});
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(81)))

/***/ }),
/* 229 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(230);
__webpack_require__(233);
__webpack_require__(234);
__webpack_require__(235);
__webpack_require__(236);
__webpack_require__(237);
__webpack_require__(238);
__webpack_require__(239);
__webpack_require__(240);
__webpack_require__(241);
__webpack_require__(242);
__webpack_require__(243);
__webpack_require__(244);
__webpack_require__(245);
__webpack_require__(246);
__webpack_require__(247);
__webpack_require__(248);
__webpack_require__(249);
__webpack_require__(250);
__webpack_require__(251);
__webpack_require__(252);
__webpack_require__(253);
__webpack_require__(254);
__webpack_require__(255);
__webpack_require__(256);
__webpack_require__(257);
__webpack_require__(258);
__webpack_require__(259);
__webpack_require__(260);
__webpack_require__(261);
__webpack_require__(262);
__webpack_require__(263);
__webpack_require__(264);
__webpack_require__(265);
__webpack_require__(266);
__webpack_require__(267);
__webpack_require__(268);
__webpack_require__(269);
__webpack_require__(270);
__webpack_require__(271);
__webpack_require__(272);
__webpack_require__(273);
__webpack_require__(274);
__webpack_require__(275);
__webpack_require__(276);
__webpack_require__(277);
__webpack_require__(278);
__webpack_require__(279);
__webpack_require__(280);
__webpack_require__(281);
__webpack_require__(282);
__webpack_require__(283);
__webpack_require__(284);
__webpack_require__(285);
__webpack_require__(286);
__webpack_require__(287);
__webpack_require__(288);
__webpack_require__(289);
__webpack_require__(290);
__webpack_require__(291);
__webpack_require__(292);
__webpack_require__(293);
__webpack_require__(294);
__webpack_require__(295);
__webpack_require__(296);
__webpack_require__(297);
__webpack_require__(298);
__webpack_require__(299);
__webpack_require__(300);
__webpack_require__(301);
__webpack_require__(302);
__webpack_require__(303);
__webpack_require__(304);
__webpack_require__(305);
__webpack_require__(306);
__webpack_require__(307);
__webpack_require__(308);
__webpack_require__(310);
__webpack_require__(311);
__webpack_require__(313);
__webpack_require__(314);
__webpack_require__(315);
__webpack_require__(316);
__webpack_require__(317);
__webpack_require__(318);
__webpack_require__(319);
__webpack_require__(321);
__webpack_require__(322);
__webpack_require__(323);
__webpack_require__(324);
__webpack_require__(325);
__webpack_require__(326);
__webpack_require__(327);
__webpack_require__(328);
__webpack_require__(329);
__webpack_require__(330);
__webpack_require__(331);
__webpack_require__(332);
__webpack_require__(333);
__webpack_require__(128);
__webpack_require__(334);
__webpack_require__(175);
__webpack_require__(335);
__webpack_require__(176);
__webpack_require__(336);
__webpack_require__(337);
__webpack_require__(338);
__webpack_require__(339);
__webpack_require__(340);
__webpack_require__(179);
__webpack_require__(181);
__webpack_require__(182);
__webpack_require__(341);
__webpack_require__(342);
__webpack_require__(343);
__webpack_require__(344);
__webpack_require__(345);
__webpack_require__(346);
__webpack_require__(347);
__webpack_require__(348);
__webpack_require__(349);
__webpack_require__(350);
__webpack_require__(351);
__webpack_require__(352);
__webpack_require__(353);
__webpack_require__(354);
__webpack_require__(355);
__webpack_require__(356);
__webpack_require__(357);
__webpack_require__(358);
__webpack_require__(359);
__webpack_require__(360);
__webpack_require__(361);
__webpack_require__(362);
__webpack_require__(363);
__webpack_require__(364);
__webpack_require__(365);
__webpack_require__(366);
__webpack_require__(367);
__webpack_require__(368);
__webpack_require__(369);
__webpack_require__(370);
__webpack_require__(371);
__webpack_require__(372);
__webpack_require__(373);
__webpack_require__(374);
__webpack_require__(375);
__webpack_require__(376);
__webpack_require__(377);
__webpack_require__(378);
__webpack_require__(379);
__webpack_require__(380);
__webpack_require__(381);
__webpack_require__(382);
__webpack_require__(383);
__webpack_require__(384);
__webpack_require__(385);
__webpack_require__(386);
__webpack_require__(387);
__webpack_require__(388);
__webpack_require__(389);
__webpack_require__(390);
__webpack_require__(391);
__webpack_require__(392);
__webpack_require__(393);
__webpack_require__(394);
__webpack_require__(395);
__webpack_require__(396);
__webpack_require__(397);
__webpack_require__(398);
__webpack_require__(399);
__webpack_require__(400);
__webpack_require__(401);
__webpack_require__(402);
__webpack_require__(403);
__webpack_require__(404);
__webpack_require__(405);
__webpack_require__(406);
__webpack_require__(407);
__webpack_require__(408);
__webpack_require__(409);
__webpack_require__(410);
__webpack_require__(411);
__webpack_require__(412);
__webpack_require__(413);
__webpack_require__(414);
__webpack_require__(415);
__webpack_require__(416);
__webpack_require__(417);
__webpack_require__(418);
__webpack_require__(419);
__webpack_require__(420);
__webpack_require__(421);
__webpack_require__(422);
__webpack_require__(423);
__webpack_require__(424);
__webpack_require__(425);
module.exports = __webpack_require__(24);


/***/ }),
/* 230 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// ECMAScript 6 symbols shim
var global = __webpack_require__(2);
var has = __webpack_require__(19);
var DESCRIPTORS = __webpack_require__(8);
var $export = __webpack_require__(0);
var redefine = __webpack_require__(16);
var META = __webpack_require__(42).KEY;
var $fails = __webpack_require__(3);
var shared = __webpack_require__(68);
var setToStringTag = __webpack_require__(60);
var uid = __webpack_require__(47);
var wks = __webpack_require__(5);
var wksExt = __webpack_require__(157);
var wksDefine = __webpack_require__(109);
var enumKeys = __webpack_require__(232);
var isArray = __webpack_require__(84);
var anObject = __webpack_require__(1);
var isObject = __webpack_require__(4);
var toIObject = __webpack_require__(20);
var toPrimitive = __webpack_require__(31);
var createDesc = __webpack_require__(46);
var _create = __webpack_require__(50);
var gOPNExt = __webpack_require__(160);
var $GOPD = __webpack_require__(21);
var $DP = __webpack_require__(9);
var $keys = __webpack_require__(48);
var gOPD = $GOPD.f;
var dP = $DP.f;
var gOPN = gOPNExt.f;
var $Symbol = global.Symbol;
var $JSON = global.JSON;
var _stringify = $JSON && $JSON.stringify;
var PROTOTYPE = 'prototype';
var HIDDEN = wks('_hidden');
var TO_PRIMITIVE = wks('toPrimitive');
var isEnum = {}.propertyIsEnumerable;
var SymbolRegistry = shared('symbol-registry');
var AllSymbols = shared('symbols');
var OPSymbols = shared('op-symbols');
var ObjectProto = Object[PROTOTYPE];
var USE_NATIVE = typeof $Symbol == 'function';
var QObject = global.QObject;
// Don't use setters in Qt Script, https://github.com/zloirock/core-js/issues/173
var setter = !QObject || !QObject[PROTOTYPE] || !QObject[PROTOTYPE].findChild;

// fallback for old Android, https://code.google.com/p/v8/issues/detail?id=687
var setSymbolDesc = DESCRIPTORS && $fails(function () {
  return _create(dP({}, 'a', {
    get: function () { return dP(this, 'a', { value: 7 }).a; }
  })).a != 7;
}) ? function (it, key, D) {
  var protoDesc = gOPD(ObjectProto, key);
  if (protoDesc) delete ObjectProto[key];
  dP(it, key, D);
  if (protoDesc && it !== ObjectProto) dP(ObjectProto, key, protoDesc);
} : dP;

var wrap = function (tag) {
  var sym = AllSymbols[tag] = _create($Symbol[PROTOTYPE]);
  sym._k = tag;
  return sym;
};

var isSymbol = USE_NATIVE && typeof $Symbol.iterator == 'symbol' ? function (it) {
  return typeof it == 'symbol';
} : function (it) {
  return it instanceof $Symbol;
};

var $defineProperty = function defineProperty(it, key, D) {
  if (it === ObjectProto) $defineProperty(OPSymbols, key, D);
  anObject(it);
  key = toPrimitive(key, true);
  anObject(D);
  if (has(AllSymbols, key)) {
    if (!D.enumerable) {
      if (!has(it, HIDDEN)) dP(it, HIDDEN, createDesc(1, {}));
      it[HIDDEN][key] = true;
    } else {
      if (has(it, HIDDEN) && it[HIDDEN][key]) it[HIDDEN][key] = false;
      D = _create(D, { enumerable: createDesc(0, false) });
    } return setSymbolDesc(it, key, D);
  } return dP(it, key, D);
};
var $defineProperties = function defineProperties(it, P) {
  anObject(it);
  var keys = enumKeys(P = toIObject(P));
  var i = 0;
  var l = keys.length;
  var key;
  while (l > i) $defineProperty(it, key = keys[i++], P[key]);
  return it;
};
var $create = function create(it, P) {
  return P === undefined ? _create(it) : $defineProperties(_create(it), P);
};
var $propertyIsEnumerable = function propertyIsEnumerable(key) {
  var E = isEnum.call(this, key = toPrimitive(key, true));
  if (this === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return false;
  return E || !has(this, key) || !has(AllSymbols, key) || has(this, HIDDEN) && this[HIDDEN][key] ? E : true;
};
var $getOwnPropertyDescriptor = function getOwnPropertyDescriptor(it, key) {
  it = toIObject(it);
  key = toPrimitive(key, true);
  if (it === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return;
  var D = gOPD(it, key);
  if (D && has(AllSymbols, key) && !(has(it, HIDDEN) && it[HIDDEN][key])) D.enumerable = true;
  return D;
};
var $getOwnPropertyNames = function getOwnPropertyNames(it) {
  var names = gOPN(toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (!has(AllSymbols, key = names[i++]) && key != HIDDEN && key != META) result.push(key);
  } return result;
};
var $getOwnPropertySymbols = function getOwnPropertySymbols(it) {
  var IS_OP = it === ObjectProto;
  var names = gOPN(IS_OP ? OPSymbols : toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (has(AllSymbols, key = names[i++]) && (IS_OP ? has(ObjectProto, key) : true)) result.push(AllSymbols[key]);
  } return result;
};

// 19.4.1.1 Symbol([description])
if (!USE_NATIVE) {
  $Symbol = function Symbol() {
    if (this instanceof $Symbol) throw TypeError('Symbol is not a constructor!');
    var tag = uid(arguments.length > 0 ? arguments[0] : undefined);
    var $set = function (value) {
      if (this === ObjectProto) $set.call(OPSymbols, value);
      if (has(this, HIDDEN) && has(this[HIDDEN], tag)) this[HIDDEN][tag] = false;
      setSymbolDesc(this, tag, createDesc(1, value));
    };
    if (DESCRIPTORS && setter) setSymbolDesc(ObjectProto, tag, { configurable: true, set: $set });
    return wrap(tag);
  };
  redefine($Symbol[PROTOTYPE], 'toString', function toString() {
    return this._k;
  });

  $GOPD.f = $getOwnPropertyDescriptor;
  $DP.f = $defineProperty;
  __webpack_require__(51).f = gOPNExt.f = $getOwnPropertyNames;
  __webpack_require__(70).f = $propertyIsEnumerable;
  __webpack_require__(83).f = $getOwnPropertySymbols;

  if (DESCRIPTORS && !__webpack_require__(41)) {
    redefine(ObjectProto, 'propertyIsEnumerable', $propertyIsEnumerable, true);
  }

  wksExt.f = function (name) {
    return wrap(wks(name));
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, { Symbol: $Symbol });

for (var es6Symbols = (
  // 19.4.2.2, 19.4.2.3, 19.4.2.4, 19.4.2.6, 19.4.2.8, 19.4.2.9, 19.4.2.10, 19.4.2.11, 19.4.2.12, 19.4.2.13, 19.4.2.14
  'hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables'
).split(','), j = 0; es6Symbols.length > j;)wks(es6Symbols[j++]);

for (var wellKnownSymbols = $keys(wks.store), k = 0; wellKnownSymbols.length > k;) wksDefine(wellKnownSymbols[k++]);

$export($export.S + $export.F * !USE_NATIVE, 'Symbol', {
  // 19.4.2.1 Symbol.for(key)
  'for': function (key) {
    return has(SymbolRegistry, key += '')
      ? SymbolRegistry[key]
      : SymbolRegistry[key] = $Symbol(key);
  },
  // 19.4.2.5 Symbol.keyFor(sym)
  keyFor: function keyFor(sym) {
    if (!isSymbol(sym)) throw TypeError(sym + ' is not a symbol!');
    for (var key in SymbolRegistry) if (SymbolRegistry[key] === sym) return key;
  },
  useSetter: function () { setter = true; },
  useSimple: function () { setter = false; }
});

$export($export.S + $export.F * !USE_NATIVE, 'Object', {
  // 19.1.2.2 Object.create(O [, Properties])
  create: $create,
  // 19.1.2.4 Object.defineProperty(O, P, Attributes)
  defineProperty: $defineProperty,
  // 19.1.2.3 Object.defineProperties(O, Properties)
  defineProperties: $defineProperties,
  // 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
  getOwnPropertyDescriptor: $getOwnPropertyDescriptor,
  // 19.1.2.7 Object.getOwnPropertyNames(O)
  getOwnPropertyNames: $getOwnPropertyNames,
  // 19.1.2.8 Object.getOwnPropertySymbols(O)
  getOwnPropertySymbols: $getOwnPropertySymbols
});

// 24.3.2 JSON.stringify(value [, replacer [, space]])
$JSON && $export($export.S + $export.F * (!USE_NATIVE || $fails(function () {
  var S = $Symbol();
  // MS Edge converts symbol values to JSON as {}
  // WebKit converts symbol values to JSON as null
  // V8 throws on boxed symbols
  return _stringify([S]) != '[null]' || _stringify({ a: S }) != '{}' || _stringify(Object(S)) != '{}';
})), 'JSON', {
  stringify: function stringify(it) {
    var args = [it];
    var i = 1;
    var replacer, $replacer;
    while (arguments.length > i) args.push(arguments[i++]);
    $replacer = replacer = args[1];
    if (!isObject(replacer) && it === undefined || isSymbol(it)) return; // IE8 returns string on undefined
    if (!isArray(replacer)) replacer = function (key, value) {
      if (typeof $replacer == 'function') value = $replacer.call(this, key, value);
      if (!isSymbol(value)) return value;
    };
    args[1] = replacer;
    return _stringify.apply($JSON, args);
  }
});

// 19.4.3.4 Symbol.prototype[@@toPrimitive](hint)
$Symbol[PROTOTYPE][TO_PRIMITIVE] || __webpack_require__(15)($Symbol[PROTOTYPE], TO_PRIMITIVE, $Symbol[PROTOTYPE].valueOf);
// 19.4.3.5 Symbol.prototype[@@toStringTag]
setToStringTag($Symbol, 'Symbol');
// 20.2.1.9 Math[@@toStringTag]
setToStringTag(Math, 'Math', true);
// 24.3.3 JSON[@@toStringTag]
setToStringTag(global.JSON, 'JSON', true);


/***/ }),
/* 231 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(68)('native-function-to-string', Function.toString);


/***/ }),
/* 232 */
/***/ (function(module, exports, __webpack_require__) {

// all enumerable object keys, includes symbols
var getKeys = __webpack_require__(48);
var gOPS = __webpack_require__(83);
var pIE = __webpack_require__(70);
module.exports = function (it) {
  var result = getKeys(it);
  var getSymbols = gOPS.f;
  if (getSymbols) {
    var symbols = getSymbols(it);
    var isEnum = pIE.f;
    var i = 0;
    var key;
    while (symbols.length > i) if (isEnum.call(it, key = symbols[i++])) result.push(key);
  } return result;
};


/***/ }),
/* 233 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
$export($export.S, 'Object', { create: __webpack_require__(50) });


/***/ }),
/* 234 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
// 19.1.2.4 / 15.2.3.6 Object.defineProperty(O, P, Attributes)
$export($export.S + $export.F * !__webpack_require__(8), 'Object', { defineProperty: __webpack_require__(9).f });


/***/ }),
/* 235 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
// 19.1.2.3 / 15.2.3.7 Object.defineProperties(O, Properties)
$export($export.S + $export.F * !__webpack_require__(8), 'Object', { defineProperties: __webpack_require__(159) });


/***/ }),
/* 236 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
var toIObject = __webpack_require__(20);
var $getOwnPropertyDescriptor = __webpack_require__(21).f;

__webpack_require__(33)('getOwnPropertyDescriptor', function () {
  return function getOwnPropertyDescriptor(it, key) {
    return $getOwnPropertyDescriptor(toIObject(it), key);
  };
});


/***/ }),
/* 237 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.9 Object.getPrototypeOf(O)
var toObject = __webpack_require__(10);
var $getPrototypeOf = __webpack_require__(22);

__webpack_require__(33)('getPrototypeOf', function () {
  return function getPrototypeOf(it) {
    return $getPrototypeOf(toObject(it));
  };
});


/***/ }),
/* 238 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 Object.keys(O)
var toObject = __webpack_require__(10);
var $keys = __webpack_require__(48);

__webpack_require__(33)('keys', function () {
  return function keys(it) {
    return $keys(toObject(it));
  };
});


/***/ }),
/* 239 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.7 Object.getOwnPropertyNames(O)
__webpack_require__(33)('getOwnPropertyNames', function () {
  return __webpack_require__(160).f;
});


/***/ }),
/* 240 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.5 Object.freeze(O)
var isObject = __webpack_require__(4);
var meta = __webpack_require__(42).onFreeze;

__webpack_require__(33)('freeze', function ($freeze) {
  return function freeze(it) {
    return $freeze && isObject(it) ? $freeze(meta(it)) : it;
  };
});


/***/ }),
/* 241 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.17 Object.seal(O)
var isObject = __webpack_require__(4);
var meta = __webpack_require__(42).onFreeze;

__webpack_require__(33)('seal', function ($seal) {
  return function seal(it) {
    return $seal && isObject(it) ? $seal(meta(it)) : it;
  };
});


/***/ }),
/* 242 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.15 Object.preventExtensions(O)
var isObject = __webpack_require__(4);
var meta = __webpack_require__(42).onFreeze;

__webpack_require__(33)('preventExtensions', function ($preventExtensions) {
  return function preventExtensions(it) {
    return $preventExtensions && isObject(it) ? $preventExtensions(meta(it)) : it;
  };
});


/***/ }),
/* 243 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.12 Object.isFrozen(O)
var isObject = __webpack_require__(4);

__webpack_require__(33)('isFrozen', function ($isFrozen) {
  return function isFrozen(it) {
    return isObject(it) ? $isFrozen ? $isFrozen(it) : false : true;
  };
});


/***/ }),
/* 244 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.13 Object.isSealed(O)
var isObject = __webpack_require__(4);

__webpack_require__(33)('isSealed', function ($isSealed) {
  return function isSealed(it) {
    return isObject(it) ? $isSealed ? $isSealed(it) : false : true;
  };
});


/***/ }),
/* 245 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.11 Object.isExtensible(O)
var isObject = __webpack_require__(4);

__webpack_require__(33)('isExtensible', function ($isExtensible) {
  return function isExtensible(it) {
    return isObject(it) ? $isExtensible ? $isExtensible(it) : true : false;
  };
});


/***/ }),
/* 246 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.3.1 Object.assign(target, source)
var $export = __webpack_require__(0);

$export($export.S + $export.F, 'Object', { assign: __webpack_require__(161) });


/***/ }),
/* 247 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.3.10 Object.is(value1, value2)
var $export = __webpack_require__(0);
$export($export.S, 'Object', { is: __webpack_require__(162) });


/***/ }),
/* 248 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.3.19 Object.setPrototypeOf(O, proto)
var $export = __webpack_require__(0);
$export($export.S, 'Object', { setPrototypeOf: __webpack_require__(113).set });


/***/ }),
/* 249 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 19.1.3.6 Object.prototype.toString()
var classof = __webpack_require__(61);
var test = {};
test[__webpack_require__(5)('toStringTag')] = 'z';
if (test + '' != '[object z]') {
  __webpack_require__(16)(Object.prototype, 'toString', function toString() {
    return '[object ' + classof(this) + ']';
  }, true);
}


/***/ }),
/* 250 */
/***/ (function(module, exports, __webpack_require__) {

// 19.2.3.2 / 15.3.4.5 Function.prototype.bind(thisArg, args...)
var $export = __webpack_require__(0);

$export($export.P, 'Function', { bind: __webpack_require__(163) });


/***/ }),
/* 251 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(9).f;
var FProto = Function.prototype;
var nameRE = /^\s*function ([^ (]*)/;
var NAME = 'name';

// 19.2.4.2 name
NAME in FProto || __webpack_require__(8) && dP(FProto, NAME, {
  configurable: true,
  get: function () {
    try {
      return ('' + this).match(nameRE)[1];
    } catch (e) {
      return '';
    }
  }
});


/***/ }),
/* 252 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var isObject = __webpack_require__(4);
var getPrototypeOf = __webpack_require__(22);
var HAS_INSTANCE = __webpack_require__(5)('hasInstance');
var FunctionProto = Function.prototype;
// 19.2.3.6 Function.prototype[@@hasInstance](V)
if (!(HAS_INSTANCE in FunctionProto)) __webpack_require__(9).f(FunctionProto, HAS_INSTANCE, { value: function (O) {
  if (typeof this != 'function' || !isObject(O)) return false;
  if (!isObject(this.prototype)) return O instanceof this;
  // for environment w/o native `@@hasInstance` logic enough `instanceof`, but add this:
  while (O = getPrototypeOf(O)) if (this.prototype === O) return true;
  return false;
} });


/***/ }),
/* 253 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var $parseInt = __webpack_require__(165);
// 18.2.5 parseInt(string, radix)
$export($export.G + $export.F * (parseInt != $parseInt), { parseInt: $parseInt });


/***/ }),
/* 254 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var $parseFloat = __webpack_require__(166);
// 18.2.4 parseFloat(string)
$export($export.G + $export.F * (parseFloat != $parseFloat), { parseFloat: $parseFloat });


/***/ }),
/* 255 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(2);
var has = __webpack_require__(19);
var cof = __webpack_require__(26);
var inheritIfRequired = __webpack_require__(115);
var toPrimitive = __webpack_require__(31);
var fails = __webpack_require__(3);
var gOPN = __webpack_require__(51).f;
var gOPD = __webpack_require__(21).f;
var dP = __webpack_require__(9).f;
var $trim = __webpack_require__(62).trim;
var NUMBER = 'Number';
var $Number = global[NUMBER];
var Base = $Number;
var proto = $Number.prototype;
// Opera ~12 has broken Object#toString
var BROKEN_COF = cof(__webpack_require__(50)(proto)) == NUMBER;
var TRIM = 'trim' in String.prototype;

// 7.1.3 ToNumber(argument)
var toNumber = function (argument) {
  var it = toPrimitive(argument, false);
  if (typeof it == 'string' && it.length > 2) {
    it = TRIM ? it.trim() : $trim(it, 3);
    var first = it.charCodeAt(0);
    var third, radix, maxCode;
    if (first === 43 || first === 45) {
      third = it.charCodeAt(2);
      if (third === 88 || third === 120) return NaN; // Number('+0x1') should be NaN, old V8 fix
    } else if (first === 48) {
      switch (it.charCodeAt(1)) {
        case 66: case 98: radix = 2; maxCode = 49; break; // fast equal /^0b[01]+$/i
        case 79: case 111: radix = 8; maxCode = 55; break; // fast equal /^0o[0-7]+$/i
        default: return +it;
      }
      for (var digits = it.slice(2), i = 0, l = digits.length, code; i < l; i++) {
        code = digits.charCodeAt(i);
        // parseInt parses a string to a first unavailable symbol
        // but ToNumber should return NaN if a string contains unavailable symbols
        if (code < 48 || code > maxCode) return NaN;
      } return parseInt(digits, radix);
    }
  } return +it;
};

if (!$Number(' 0o1') || !$Number('0b1') || $Number('+0x1')) {
  $Number = function Number(value) {
    var it = arguments.length < 1 ? 0 : value;
    var that = this;
    return that instanceof $Number
      // check on 1..constructor(foo) case
      && (BROKEN_COF ? fails(function () { proto.valueOf.call(that); }) : cof(that) != NUMBER)
        ? inheritIfRequired(new Base(toNumber(it)), that, $Number) : toNumber(it);
  };
  for (var keys = __webpack_require__(8) ? gOPN(Base) : (
    // ES3:
    'MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,' +
    // ES6 (in case, if modules with ES6 Number statics required before):
    'EPSILON,isFinite,isInteger,isNaN,isSafeInteger,MAX_SAFE_INTEGER,' +
    'MIN_SAFE_INTEGER,parseFloat,parseInt,isInteger'
  ).split(','), j = 0, key; keys.length > j; j++) {
    if (has(Base, key = keys[j]) && !has($Number, key)) {
      dP($Number, key, gOPD(Base, key));
    }
  }
  $Number.prototype = proto;
  proto.constructor = $Number;
  __webpack_require__(16)(global, NUMBER, $Number);
}


/***/ }),
/* 256 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toInteger = __webpack_require__(27);
var aNumberValue = __webpack_require__(167);
var repeat = __webpack_require__(116);
var $toFixed = 1.0.toFixed;
var floor = Math.floor;
var data = [0, 0, 0, 0, 0, 0];
var ERROR = 'Number.toFixed: incorrect invocation!';
var ZERO = '0';

var multiply = function (n, c) {
  var i = -1;
  var c2 = c;
  while (++i < 6) {
    c2 += n * data[i];
    data[i] = c2 % 1e7;
    c2 = floor(c2 / 1e7);
  }
};
var divide = function (n) {
  var i = 6;
  var c = 0;
  while (--i >= 0) {
    c += data[i];
    data[i] = floor(c / n);
    c = (c % n) * 1e7;
  }
};
var numToString = function () {
  var i = 6;
  var s = '';
  while (--i >= 0) {
    if (s !== '' || i === 0 || data[i] !== 0) {
      var t = String(data[i]);
      s = s === '' ? t : s + repeat.call(ZERO, 7 - t.length) + t;
    }
  } return s;
};
var pow = function (x, n, acc) {
  return n === 0 ? acc : n % 2 === 1 ? pow(x, n - 1, acc * x) : pow(x * x, n / 2, acc);
};
var log = function (x) {
  var n = 0;
  var x2 = x;
  while (x2 >= 4096) {
    n += 12;
    x2 /= 4096;
  }
  while (x2 >= 2) {
    n += 1;
    x2 /= 2;
  } return n;
};

$export($export.P + $export.F * (!!$toFixed && (
  0.00008.toFixed(3) !== '0.000' ||
  0.9.toFixed(0) !== '1' ||
  1.255.toFixed(2) !== '1.25' ||
  1000000000000000128.0.toFixed(0) !== '1000000000000000128'
) || !__webpack_require__(3)(function () {
  // V8 ~ Android 4.3-
  $toFixed.call({});
})), 'Number', {
  toFixed: function toFixed(fractionDigits) {
    var x = aNumberValue(this, ERROR);
    var f = toInteger(fractionDigits);
    var s = '';
    var m = ZERO;
    var e, z, j, k;
    if (f < 0 || f > 20) throw RangeError(ERROR);
    // eslint-disable-next-line no-self-compare
    if (x != x) return 'NaN';
    if (x <= -1e21 || x >= 1e21) return String(x);
    if (x < 0) {
      s = '-';
      x = -x;
    }
    if (x > 1e-21) {
      e = log(x * pow(2, 69, 1)) - 69;
      z = e < 0 ? x * pow(2, -e, 1) : x / pow(2, e, 1);
      z *= 0x10000000000000;
      e = 52 - e;
      if (e > 0) {
        multiply(0, z);
        j = f;
        while (j >= 7) {
          multiply(1e7, 0);
          j -= 7;
        }
        multiply(pow(10, j, 1), 0);
        j = e - 1;
        while (j >= 23) {
          divide(1 << 23);
          j -= 23;
        }
        divide(1 << j);
        multiply(1, 1);
        divide(2);
        m = numToString();
      } else {
        multiply(0, z);
        multiply(1 << -e, 0);
        m = numToString() + repeat.call(ZERO, f);
      }
    }
    if (f > 0) {
      k = m.length;
      m = s + (k <= f ? '0.' + repeat.call(ZERO, f - k) + m : m.slice(0, k - f) + '.' + m.slice(k - f));
    } else {
      m = s + m;
    } return m;
  }
});


/***/ }),
/* 257 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $fails = __webpack_require__(3);
var aNumberValue = __webpack_require__(167);
var $toPrecision = 1.0.toPrecision;

$export($export.P + $export.F * ($fails(function () {
  // IE7-
  return $toPrecision.call(1, undefined) !== '1';
}) || !$fails(function () {
  // V8 ~ Android 4.3-
  $toPrecision.call({});
})), 'Number', {
  toPrecision: function toPrecision(precision) {
    var that = aNumberValue(this, 'Number#toPrecision: incorrect invocation!');
    return precision === undefined ? $toPrecision.call(that) : $toPrecision.call(that, precision);
  }
});


/***/ }),
/* 258 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.1 Number.EPSILON
var $export = __webpack_require__(0);

$export($export.S, 'Number', { EPSILON: Math.pow(2, -52) });


/***/ }),
/* 259 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.2 Number.isFinite(number)
var $export = __webpack_require__(0);
var _isFinite = __webpack_require__(2).isFinite;

$export($export.S, 'Number', {
  isFinite: function isFinite(it) {
    return typeof it == 'number' && _isFinite(it);
  }
});


/***/ }),
/* 260 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.3 Number.isInteger(number)
var $export = __webpack_require__(0);

$export($export.S, 'Number', { isInteger: __webpack_require__(168) });


/***/ }),
/* 261 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.4 Number.isNaN(number)
var $export = __webpack_require__(0);

$export($export.S, 'Number', {
  isNaN: function isNaN(number) {
    // eslint-disable-next-line no-self-compare
    return number != number;
  }
});


/***/ }),
/* 262 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.5 Number.isSafeInteger(number)
var $export = __webpack_require__(0);
var isInteger = __webpack_require__(168);
var abs = Math.abs;

$export($export.S, 'Number', {
  isSafeInteger: function isSafeInteger(number) {
    return isInteger(number) && abs(number) <= 0x1fffffffffffff;
  }
});


/***/ }),
/* 263 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.6 Number.MAX_SAFE_INTEGER
var $export = __webpack_require__(0);

$export($export.S, 'Number', { MAX_SAFE_INTEGER: 0x1fffffffffffff });


/***/ }),
/* 264 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.10 Number.MIN_SAFE_INTEGER
var $export = __webpack_require__(0);

$export($export.S, 'Number', { MIN_SAFE_INTEGER: -0x1fffffffffffff });


/***/ }),
/* 265 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var $parseFloat = __webpack_require__(166);
// 20.1.2.12 Number.parseFloat(string)
$export($export.S + $export.F * (Number.parseFloat != $parseFloat), 'Number', { parseFloat: $parseFloat });


/***/ }),
/* 266 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var $parseInt = __webpack_require__(165);
// 20.1.2.13 Number.parseInt(string, radix)
$export($export.S + $export.F * (Number.parseInt != $parseInt), 'Number', { parseInt: $parseInt });


/***/ }),
/* 267 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.3 Math.acosh(x)
var $export = __webpack_require__(0);
var log1p = __webpack_require__(169);
var sqrt = Math.sqrt;
var $acosh = Math.acosh;

$export($export.S + $export.F * !($acosh
  // V8 bug: https://code.google.com/p/v8/issues/detail?id=3509
  && Math.floor($acosh(Number.MAX_VALUE)) == 710
  // Tor Browser bug: Math.acosh(Infinity) -> NaN
  && $acosh(Infinity) == Infinity
), 'Math', {
  acosh: function acosh(x) {
    return (x = +x) < 1 ? NaN : x > 94906265.62425156
      ? Math.log(x) + Math.LN2
      : log1p(x - 1 + sqrt(x - 1) * sqrt(x + 1));
  }
});


/***/ }),
/* 268 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.5 Math.asinh(x)
var $export = __webpack_require__(0);
var $asinh = Math.asinh;

function asinh(x) {
  return !isFinite(x = +x) || x == 0 ? x : x < 0 ? -asinh(-x) : Math.log(x + Math.sqrt(x * x + 1));
}

// Tor Browser bug: Math.asinh(0) -> -0
$export($export.S + $export.F * !($asinh && 1 / $asinh(0) > 0), 'Math', { asinh: asinh });


/***/ }),
/* 269 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.7 Math.atanh(x)
var $export = __webpack_require__(0);
var $atanh = Math.atanh;

// Tor Browser bug: Math.atanh(-0) -> 0
$export($export.S + $export.F * !($atanh && 1 / $atanh(-0) < 0), 'Math', {
  atanh: function atanh(x) {
    return (x = +x) == 0 ? x : Math.log((1 + x) / (1 - x)) / 2;
  }
});


/***/ }),
/* 270 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.9 Math.cbrt(x)
var $export = __webpack_require__(0);
var sign = __webpack_require__(117);

$export($export.S, 'Math', {
  cbrt: function cbrt(x) {
    return sign(x = +x) * Math.pow(Math.abs(x), 1 / 3);
  }
});


/***/ }),
/* 271 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.11 Math.clz32(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  clz32: function clz32(x) {
    return (x >>>= 0) ? 31 - Math.floor(Math.log(x + 0.5) * Math.LOG2E) : 32;
  }
});


/***/ }),
/* 272 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.12 Math.cosh(x)
var $export = __webpack_require__(0);
var exp = Math.exp;

$export($export.S, 'Math', {
  cosh: function cosh(x) {
    return (exp(x = +x) + exp(-x)) / 2;
  }
});


/***/ }),
/* 273 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.14 Math.expm1(x)
var $export = __webpack_require__(0);
var $expm1 = __webpack_require__(118);

$export($export.S + $export.F * ($expm1 != Math.expm1), 'Math', { expm1: $expm1 });


/***/ }),
/* 274 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.16 Math.fround(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', { fround: __webpack_require__(170) });


/***/ }),
/* 275 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.17 Math.hypot([value1[, value2[, … ]]])
var $export = __webpack_require__(0);
var abs = Math.abs;

$export($export.S, 'Math', {
  hypot: function hypot(value1, value2) { // eslint-disable-line no-unused-vars
    var sum = 0;
    var i = 0;
    var aLen = arguments.length;
    var larg = 0;
    var arg, div;
    while (i < aLen) {
      arg = abs(arguments[i++]);
      if (larg < arg) {
        div = larg / arg;
        sum = sum * div * div + 1;
        larg = arg;
      } else if (arg > 0) {
        div = arg / larg;
        sum += div * div;
      } else sum += arg;
    }
    return larg === Infinity ? Infinity : larg * Math.sqrt(sum);
  }
});


/***/ }),
/* 276 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.18 Math.imul(x, y)
var $export = __webpack_require__(0);
var $imul = Math.imul;

// some WebKit versions fails with big numbers, some has wrong arity
$export($export.S + $export.F * __webpack_require__(3)(function () {
  return $imul(0xffffffff, 5) != -5 || $imul.length != 2;
}), 'Math', {
  imul: function imul(x, y) {
    var UINT16 = 0xffff;
    var xn = +x;
    var yn = +y;
    var xl = UINT16 & xn;
    var yl = UINT16 & yn;
    return 0 | xl * yl + ((UINT16 & xn >>> 16) * yl + xl * (UINT16 & yn >>> 16) << 16 >>> 0);
  }
});


/***/ }),
/* 277 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.21 Math.log10(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  log10: function log10(x) {
    return Math.log(x) * Math.LOG10E;
  }
});


/***/ }),
/* 278 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.20 Math.log1p(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', { log1p: __webpack_require__(169) });


/***/ }),
/* 279 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.22 Math.log2(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  log2: function log2(x) {
    return Math.log(x) / Math.LN2;
  }
});


/***/ }),
/* 280 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.28 Math.sign(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', { sign: __webpack_require__(117) });


/***/ }),
/* 281 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.30 Math.sinh(x)
var $export = __webpack_require__(0);
var expm1 = __webpack_require__(118);
var exp = Math.exp;

// V8 near Chromium 38 has a problem with very small numbers
$export($export.S + $export.F * __webpack_require__(3)(function () {
  return !Math.sinh(-2e-17) != -2e-17;
}), 'Math', {
  sinh: function sinh(x) {
    return Math.abs(x = +x) < 1
      ? (expm1(x) - expm1(-x)) / 2
      : (exp(x - 1) - exp(-x - 1)) * (Math.E / 2);
  }
});


/***/ }),
/* 282 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.33 Math.tanh(x)
var $export = __webpack_require__(0);
var expm1 = __webpack_require__(118);
var exp = Math.exp;

$export($export.S, 'Math', {
  tanh: function tanh(x) {
    var a = expm1(x = +x);
    var b = expm1(-x);
    return a == Infinity ? 1 : b == Infinity ? -1 : (a - b) / (exp(x) + exp(-x));
  }
});


/***/ }),
/* 283 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.34 Math.trunc(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  trunc: function trunc(it) {
    return (it > 0 ? Math.floor : Math.ceil)(it);
  }
});


/***/ }),
/* 284 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var toAbsoluteIndex = __webpack_require__(49);
var fromCharCode = String.fromCharCode;
var $fromCodePoint = String.fromCodePoint;

// length should be 1, old FF problem
$export($export.S + $export.F * (!!$fromCodePoint && $fromCodePoint.length != 1), 'String', {
  // 21.1.2.2 String.fromCodePoint(...codePoints)
  fromCodePoint: function fromCodePoint(x) { // eslint-disable-line no-unused-vars
    var res = [];
    var aLen = arguments.length;
    var i = 0;
    var code;
    while (aLen > i) {
      code = +arguments[i++];
      if (toAbsoluteIndex(code, 0x10ffff) !== code) throw RangeError(code + ' is not a valid code point');
      res.push(code < 0x10000
        ? fromCharCode(code)
        : fromCharCode(((code -= 0x10000) >> 10) + 0xd800, code % 0x400 + 0xdc00)
      );
    } return res.join('');
  }
});


/***/ }),
/* 285 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var toIObject = __webpack_require__(20);
var toLength = __webpack_require__(6);

$export($export.S, 'String', {
  // 21.1.2.4 String.raw(callSite, ...substitutions)
  raw: function raw(callSite) {
    var tpl = toIObject(callSite.raw);
    var len = toLength(tpl.length);
    var aLen = arguments.length;
    var res = [];
    var i = 0;
    while (len > i) {
      res.push(String(tpl[i++]));
      if (i < aLen) res.push(String(arguments[i]));
    } return res.join('');
  }
});


/***/ }),
/* 286 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 21.1.3.25 String.prototype.trim()
__webpack_require__(62)('trim', function ($trim) {
  return function trim() {
    return $trim(this, 3);
  };
});


/***/ }),
/* 287 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $at = __webpack_require__(85)(true);

// 21.1.3.27 String.prototype[@@iterator]()
__webpack_require__(119)(String, 'String', function (iterated) {
  this._t = String(iterated); // target
  this._i = 0;                // next index
// 21.1.5.2.1 %StringIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var index = this._i;
  var point;
  if (index >= O.length) return { value: undefined, done: true };
  point = $at(O, index);
  this._i += point.length;
  return { value: point, done: false };
});


/***/ }),
/* 288 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $at = __webpack_require__(85)(false);
$export($export.P, 'String', {
  // 21.1.3.3 String.prototype.codePointAt(pos)
  codePointAt: function codePointAt(pos) {
    return $at(this, pos);
  }
});


/***/ }),
/* 289 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 21.1.3.6 String.prototype.endsWith(searchString [, endPosition])

var $export = __webpack_require__(0);
var toLength = __webpack_require__(6);
var context = __webpack_require__(121);
var ENDS_WITH = 'endsWith';
var $endsWith = ''[ENDS_WITH];

$export($export.P + $export.F * __webpack_require__(122)(ENDS_WITH), 'String', {
  endsWith: function endsWith(searchString /* , endPosition = @length */) {
    var that = context(this, searchString, ENDS_WITH);
    var endPosition = arguments.length > 1 ? arguments[1] : undefined;
    var len = toLength(that.length);
    var end = endPosition === undefined ? len : Math.min(toLength(endPosition), len);
    var search = String(searchString);
    return $endsWith
      ? $endsWith.call(that, search, end)
      : that.slice(end - search.length, end) === search;
  }
});


/***/ }),
/* 290 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 21.1.3.7 String.prototype.includes(searchString, position = 0)

var $export = __webpack_require__(0);
var context = __webpack_require__(121);
var INCLUDES = 'includes';

$export($export.P + $export.F * __webpack_require__(122)(INCLUDES), 'String', {
  includes: function includes(searchString /* , position = 0 */) {
    return !!~context(this, searchString, INCLUDES)
      .indexOf(searchString, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),
/* 291 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);

$export($export.P, 'String', {
  // 21.1.3.13 String.prototype.repeat(count)
  repeat: __webpack_require__(116)
});


/***/ }),
/* 292 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 21.1.3.18 String.prototype.startsWith(searchString [, position ])

var $export = __webpack_require__(0);
var toLength = __webpack_require__(6);
var context = __webpack_require__(121);
var STARTS_WITH = 'startsWith';
var $startsWith = ''[STARTS_WITH];

$export($export.P + $export.F * __webpack_require__(122)(STARTS_WITH), 'String', {
  startsWith: function startsWith(searchString /* , position = 0 */) {
    var that = context(this, searchString, STARTS_WITH);
    var index = toLength(Math.min(arguments.length > 1 ? arguments[1] : undefined, that.length));
    var search = String(searchString);
    return $startsWith
      ? $startsWith.call(that, search, index)
      : that.slice(index, index + search.length) === search;
  }
});


/***/ }),
/* 293 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.2 String.prototype.anchor(name)
__webpack_require__(17)('anchor', function (createHTML) {
  return function anchor(name) {
    return createHTML(this, 'a', 'name', name);
  };
});


/***/ }),
/* 294 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.3 String.prototype.big()
__webpack_require__(17)('big', function (createHTML) {
  return function big() {
    return createHTML(this, 'big', '', '');
  };
});


/***/ }),
/* 295 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.4 String.prototype.blink()
__webpack_require__(17)('blink', function (createHTML) {
  return function blink() {
    return createHTML(this, 'blink', '', '');
  };
});


/***/ }),
/* 296 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.5 String.prototype.bold()
__webpack_require__(17)('bold', function (createHTML) {
  return function bold() {
    return createHTML(this, 'b', '', '');
  };
});


/***/ }),
/* 297 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.6 String.prototype.fixed()
__webpack_require__(17)('fixed', function (createHTML) {
  return function fixed() {
    return createHTML(this, 'tt', '', '');
  };
});


/***/ }),
/* 298 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.7 String.prototype.fontcolor(color)
__webpack_require__(17)('fontcolor', function (createHTML) {
  return function fontcolor(color) {
    return createHTML(this, 'font', 'color', color);
  };
});


/***/ }),
/* 299 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.8 String.prototype.fontsize(size)
__webpack_require__(17)('fontsize', function (createHTML) {
  return function fontsize(size) {
    return createHTML(this, 'font', 'size', size);
  };
});


/***/ }),
/* 300 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.9 String.prototype.italics()
__webpack_require__(17)('italics', function (createHTML) {
  return function italics() {
    return createHTML(this, 'i', '', '');
  };
});


/***/ }),
/* 301 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.10 String.prototype.link(url)
__webpack_require__(17)('link', function (createHTML) {
  return function link(url) {
    return createHTML(this, 'a', 'href', url);
  };
});


/***/ }),
/* 302 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.11 String.prototype.small()
__webpack_require__(17)('small', function (createHTML) {
  return function small() {
    return createHTML(this, 'small', '', '');
  };
});


/***/ }),
/* 303 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.12 String.prototype.strike()
__webpack_require__(17)('strike', function (createHTML) {
  return function strike() {
    return createHTML(this, 'strike', '', '');
  };
});


/***/ }),
/* 304 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.13 String.prototype.sub()
__webpack_require__(17)('sub', function (createHTML) {
  return function sub() {
    return createHTML(this, 'sub', '', '');
  };
});


/***/ }),
/* 305 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.14 String.prototype.sup()
__webpack_require__(17)('sup', function (createHTML) {
  return function sup() {
    return createHTML(this, 'sup', '', '');
  };
});


/***/ }),
/* 306 */
/***/ (function(module, exports, __webpack_require__) {

// 20.3.3.1 / 15.9.4.4 Date.now()
var $export = __webpack_require__(0);

$export($export.S, 'Date', { now: function () { return new Date().getTime(); } });


/***/ }),
/* 307 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toObject = __webpack_require__(10);
var toPrimitive = __webpack_require__(31);

$export($export.P + $export.F * __webpack_require__(3)(function () {
  return new Date(NaN).toJSON() !== null
    || Date.prototype.toJSON.call({ toISOString: function () { return 1; } }) !== 1;
}), 'Date', {
  // eslint-disable-next-line no-unused-vars
  toJSON: function toJSON(key) {
    var O = toObject(this);
    var pv = toPrimitive(O);
    return typeof pv == 'number' && !isFinite(pv) ? null : O.toISOString();
  }
});


/***/ }),
/* 308 */
/***/ (function(module, exports, __webpack_require__) {

// 20.3.4.36 / 15.9.5.43 Date.prototype.toISOString()
var $export = __webpack_require__(0);
var toISOString = __webpack_require__(309);

// PhantomJS / old WebKit has a broken implementations
$export($export.P + $export.F * (Date.prototype.toISOString !== toISOString), 'Date', {
  toISOString: toISOString
});


/***/ }),
/* 309 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 20.3.4.36 / 15.9.5.43 Date.prototype.toISOString()
var fails = __webpack_require__(3);
var getTime = Date.prototype.getTime;
var $toISOString = Date.prototype.toISOString;

var lz = function (num) {
  return num > 9 ? num : '0' + num;
};

// PhantomJS / old WebKit has a broken implementations
module.exports = (fails(function () {
  return $toISOString.call(new Date(-5e13 - 1)) != '0385-07-25T07:06:39.999Z';
}) || !fails(function () {
  $toISOString.call(new Date(NaN));
})) ? function toISOString() {
  if (!isFinite(getTime.call(this))) throw RangeError('Invalid time value');
  var d = this;
  var y = d.getUTCFullYear();
  var m = d.getUTCMilliseconds();
  var s = y < 0 ? '-' : y > 9999 ? '+' : '';
  return s + ('00000' + Math.abs(y)).slice(s ? -6 : -4) +
    '-' + lz(d.getUTCMonth() + 1) + '-' + lz(d.getUTCDate()) +
    'T' + lz(d.getUTCHours()) + ':' + lz(d.getUTCMinutes()) +
    ':' + lz(d.getUTCSeconds()) + '.' + (m > 99 ? m : '0' + lz(m)) + 'Z';
} : $toISOString;


/***/ }),
/* 310 */
/***/ (function(module, exports, __webpack_require__) {

var DateProto = Date.prototype;
var INVALID_DATE = 'Invalid Date';
var TO_STRING = 'toString';
var $toString = DateProto[TO_STRING];
var getTime = DateProto.getTime;
if (new Date(NaN) + '' != INVALID_DATE) {
  __webpack_require__(16)(DateProto, TO_STRING, function toString() {
    var value = getTime.call(this);
    // eslint-disable-next-line no-self-compare
    return value === value ? $toString.call(this) : INVALID_DATE;
  });
}


/***/ }),
/* 311 */
/***/ (function(module, exports, __webpack_require__) {

var TO_PRIMITIVE = __webpack_require__(5)('toPrimitive');
var proto = Date.prototype;

if (!(TO_PRIMITIVE in proto)) __webpack_require__(15)(proto, TO_PRIMITIVE, __webpack_require__(312));


/***/ }),
/* 312 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var anObject = __webpack_require__(1);
var toPrimitive = __webpack_require__(31);
var NUMBER = 'number';

module.exports = function (hint) {
  if (hint !== 'string' && hint !== NUMBER && hint !== 'default') throw TypeError('Incorrect hint');
  return toPrimitive(anObject(this), hint != NUMBER);
};


/***/ }),
/* 313 */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.2.2 / 15.4.3.2 Array.isArray(arg)
var $export = __webpack_require__(0);

$export($export.S, 'Array', { isArray: __webpack_require__(84) });


/***/ }),
/* 314 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var ctx = __webpack_require__(25);
var $export = __webpack_require__(0);
var toObject = __webpack_require__(10);
var call = __webpack_require__(171);
var isArrayIter = __webpack_require__(123);
var toLength = __webpack_require__(6);
var createProperty = __webpack_require__(124);
var getIterFn = __webpack_require__(125);

$export($export.S + $export.F * !__webpack_require__(87)(function (iter) { Array.from(iter); }), 'Array', {
  // 22.1.2.1 Array.from(arrayLike, mapfn = undefined, thisArg = undefined)
  from: function from(arrayLike /* , mapfn = undefined, thisArg = undefined */) {
    var O = toObject(arrayLike);
    var C = typeof this == 'function' ? this : Array;
    var aLen = arguments.length;
    var mapfn = aLen > 1 ? arguments[1] : undefined;
    var mapping = mapfn !== undefined;
    var index = 0;
    var iterFn = getIterFn(O);
    var length, result, step, iterator;
    if (mapping) mapfn = ctx(mapfn, aLen > 2 ? arguments[2] : undefined, 2);
    // if object isn't iterable or it's array with default iterator - use simple case
    if (iterFn != undefined && !(C == Array && isArrayIter(iterFn))) {
      for (iterator = iterFn.call(O), result = new C(); !(step = iterator.next()).done; index++) {
        createProperty(result, index, mapping ? call(iterator, mapfn, [step.value, index], true) : step.value);
      }
    } else {
      length = toLength(O.length);
      for (result = new C(length); length > index; index++) {
        createProperty(result, index, mapping ? mapfn(O[index], index) : O[index]);
      }
    }
    result.length = index;
    return result;
  }
});


/***/ }),
/* 315 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var createProperty = __webpack_require__(124);

// WebKit Array.of isn't generic
$export($export.S + $export.F * __webpack_require__(3)(function () {
  function F() { /* empty */ }
  return !(Array.of.call(F) instanceof F);
}), 'Array', {
  // 22.1.2.3 Array.of( ...items)
  of: function of(/* ...args */) {
    var index = 0;
    var aLen = arguments.length;
    var result = new (typeof this == 'function' ? this : Array)(aLen);
    while (aLen > index) createProperty(result, index, arguments[index++]);
    result.length = aLen;
    return result;
  }
});


/***/ }),
/* 316 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 22.1.3.13 Array.prototype.join(separator)
var $export = __webpack_require__(0);
var toIObject = __webpack_require__(20);
var arrayJoin = [].join;

// fallback for not array-like strings
$export($export.P + $export.F * (__webpack_require__(69) != Object || !__webpack_require__(28)(arrayJoin)), 'Array', {
  join: function join(separator) {
    return arrayJoin.call(toIObject(this), separator === undefined ? ',' : separator);
  }
});


/***/ }),
/* 317 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var html = __webpack_require__(112);
var cof = __webpack_require__(26);
var toAbsoluteIndex = __webpack_require__(49);
var toLength = __webpack_require__(6);
var arraySlice = [].slice;

// fallback for not array-like ES3 strings and DOM objects
$export($export.P + $export.F * __webpack_require__(3)(function () {
  if (html) arraySlice.call(html);
}), 'Array', {
  slice: function slice(begin, end) {
    var len = toLength(this.length);
    var klass = cof(this);
    end = end === undefined ? len : end;
    if (klass == 'Array') return arraySlice.call(this, begin, end);
    var start = toAbsoluteIndex(begin, len);
    var upTo = toAbsoluteIndex(end, len);
    var size = toLength(upTo - start);
    var cloned = new Array(size);
    var i = 0;
    for (; i < size; i++) cloned[i] = klass == 'String'
      ? this.charAt(start + i)
      : this[start + i];
    return cloned;
  }
});


/***/ }),
/* 318 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var aFunction = __webpack_require__(11);
var toObject = __webpack_require__(10);
var fails = __webpack_require__(3);
var $sort = [].sort;
var test = [1, 2, 3];

$export($export.P + $export.F * (fails(function () {
  // IE8-
  test.sort(undefined);
}) || !fails(function () {
  // V8 bug
  test.sort(null);
  // Old WebKit
}) || !__webpack_require__(28)($sort)), 'Array', {
  // 22.1.3.25 Array.prototype.sort(comparefn)
  sort: function sort(comparefn) {
    return comparefn === undefined
      ? $sort.call(toObject(this))
      : $sort.call(toObject(this), aFunction(comparefn));
  }
});


/***/ }),
/* 319 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $forEach = __webpack_require__(34)(0);
var STRICT = __webpack_require__(28)([].forEach, true);

$export($export.P + $export.F * !STRICT, 'Array', {
  // 22.1.3.10 / 15.4.4.18 Array.prototype.forEach(callbackfn [, thisArg])
  forEach: function forEach(callbackfn /* , thisArg */) {
    return $forEach(this, callbackfn, arguments[1]);
  }
});


/***/ }),
/* 320 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
var isArray = __webpack_require__(84);
var SPECIES = __webpack_require__(5)('species');

module.exports = function (original) {
  var C;
  if (isArray(original)) {
    C = original.constructor;
    // cross-realm fallback
    if (typeof C == 'function' && (C === Array || isArray(C.prototype))) C = undefined;
    if (isObject(C)) {
      C = C[SPECIES];
      if (C === null) C = undefined;
    }
  } return C === undefined ? Array : C;
};


/***/ }),
/* 321 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $map = __webpack_require__(34)(1);

$export($export.P + $export.F * !__webpack_require__(28)([].map, true), 'Array', {
  // 22.1.3.15 / 15.4.4.19 Array.prototype.map(callbackfn [, thisArg])
  map: function map(callbackfn /* , thisArg */) {
    return $map(this, callbackfn, arguments[1]);
  }
});


/***/ }),
/* 322 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $filter = __webpack_require__(34)(2);

$export($export.P + $export.F * !__webpack_require__(28)([].filter, true), 'Array', {
  // 22.1.3.7 / 15.4.4.20 Array.prototype.filter(callbackfn [, thisArg])
  filter: function filter(callbackfn /* , thisArg */) {
    return $filter(this, callbackfn, arguments[1]);
  }
});


/***/ }),
/* 323 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $some = __webpack_require__(34)(3);

$export($export.P + $export.F * !__webpack_require__(28)([].some, true), 'Array', {
  // 22.1.3.23 / 15.4.4.17 Array.prototype.some(callbackfn [, thisArg])
  some: function some(callbackfn /* , thisArg */) {
    return $some(this, callbackfn, arguments[1]);
  }
});


/***/ }),
/* 324 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $every = __webpack_require__(34)(4);

$export($export.P + $export.F * !__webpack_require__(28)([].every, true), 'Array', {
  // 22.1.3.5 / 15.4.4.16 Array.prototype.every(callbackfn [, thisArg])
  every: function every(callbackfn /* , thisArg */) {
    return $every(this, callbackfn, arguments[1]);
  }
});


/***/ }),
/* 325 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $reduce = __webpack_require__(172);

$export($export.P + $export.F * !__webpack_require__(28)([].reduce, true), 'Array', {
  // 22.1.3.18 / 15.4.4.21 Array.prototype.reduce(callbackfn [, initialValue])
  reduce: function reduce(callbackfn /* , initialValue */) {
    return $reduce(this, callbackfn, arguments.length, arguments[1], false);
  }
});


/***/ }),
/* 326 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $reduce = __webpack_require__(172);

$export($export.P + $export.F * !__webpack_require__(28)([].reduceRight, true), 'Array', {
  // 22.1.3.19 / 15.4.4.22 Array.prototype.reduceRight(callbackfn [, initialValue])
  reduceRight: function reduceRight(callbackfn /* , initialValue */) {
    return $reduce(this, callbackfn, arguments.length, arguments[1], true);
  }
});


/***/ }),
/* 327 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $indexOf = __webpack_require__(82)(false);
var $native = [].indexOf;
var NEGATIVE_ZERO = !!$native && 1 / [1].indexOf(1, -0) < 0;

$export($export.P + $export.F * (NEGATIVE_ZERO || !__webpack_require__(28)($native)), 'Array', {
  // 22.1.3.11 / 15.4.4.14 Array.prototype.indexOf(searchElement [, fromIndex])
  indexOf: function indexOf(searchElement /* , fromIndex = 0 */) {
    return NEGATIVE_ZERO
      // convert -0 to +0
      ? $native.apply(this, arguments) || 0
      : $indexOf(this, searchElement, arguments[1]);
  }
});


/***/ }),
/* 328 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toIObject = __webpack_require__(20);
var toInteger = __webpack_require__(27);
var toLength = __webpack_require__(6);
var $native = [].lastIndexOf;
var NEGATIVE_ZERO = !!$native && 1 / [1].lastIndexOf(1, -0) < 0;

$export($export.P + $export.F * (NEGATIVE_ZERO || !__webpack_require__(28)($native)), 'Array', {
  // 22.1.3.14 / 15.4.4.15 Array.prototype.lastIndexOf(searchElement [, fromIndex])
  lastIndexOf: function lastIndexOf(searchElement /* , fromIndex = @[*-1] */) {
    // convert -0 to +0
    if (NEGATIVE_ZERO) return $native.apply(this, arguments) || 0;
    var O = toIObject(this);
    var length = toLength(O.length);
    var index = length - 1;
    if (arguments.length > 1) index = Math.min(index, toInteger(arguments[1]));
    if (index < 0) index = length + index;
    for (;index >= 0; index--) if (index in O) if (O[index] === searchElement) return index || 0;
    return -1;
  }
});


/***/ }),
/* 329 */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.3.3 Array.prototype.copyWithin(target, start, end = this.length)
var $export = __webpack_require__(0);

$export($export.P, 'Array', { copyWithin: __webpack_require__(173) });

__webpack_require__(43)('copyWithin');


/***/ }),
/* 330 */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.3.6 Array.prototype.fill(value, start = 0, end = this.length)
var $export = __webpack_require__(0);

$export($export.P, 'Array', { fill: __webpack_require__(127) });

__webpack_require__(43)('fill');


/***/ }),
/* 331 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 22.1.3.8 Array.prototype.find(predicate, thisArg = undefined)
var $export = __webpack_require__(0);
var $find = __webpack_require__(34)(5);
var KEY = 'find';
var forced = true;
// Shouldn't skip holes
if (KEY in []) Array(1)[KEY](function () { forced = false; });
$export($export.P + $export.F * forced, 'Array', {
  find: function find(callbackfn /* , that = undefined */) {
    return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
__webpack_require__(43)(KEY);


/***/ }),
/* 332 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 22.1.3.9 Array.prototype.findIndex(predicate, thisArg = undefined)
var $export = __webpack_require__(0);
var $find = __webpack_require__(34)(6);
var KEY = 'findIndex';
var forced = true;
// Shouldn't skip holes
if (KEY in []) Array(1)[KEY](function () { forced = false; });
$export($export.P + $export.F * forced, 'Array', {
  findIndex: function findIndex(callbackfn /* , that = undefined */) {
    return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
__webpack_require__(43)(KEY);


/***/ }),
/* 333 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(52)('Array');


/***/ }),
/* 334 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var inheritIfRequired = __webpack_require__(115);
var dP = __webpack_require__(9).f;
var gOPN = __webpack_require__(51).f;
var isRegExp = __webpack_require__(86);
var $flags = __webpack_require__(71);
var $RegExp = global.RegExp;
var Base = $RegExp;
var proto = $RegExp.prototype;
var re1 = /a/g;
var re2 = /a/g;
// "new" creates a new object, old webkit buggy here
var CORRECT_NEW = new $RegExp(re1) !== re1;

if (__webpack_require__(8) && (!CORRECT_NEW || __webpack_require__(3)(function () {
  re2[__webpack_require__(5)('match')] = false;
  // RegExp constructor can alter flags and IsRegExp works correct with @@match
  return $RegExp(re1) != re1 || $RegExp(re2) == re2 || $RegExp(re1, 'i') != '/a/i';
}))) {
  $RegExp = function RegExp(p, f) {
    var tiRE = this instanceof $RegExp;
    var piRE = isRegExp(p);
    var fiU = f === undefined;
    return !tiRE && piRE && p.constructor === $RegExp && fiU ? p
      : inheritIfRequired(CORRECT_NEW
        ? new Base(piRE && !fiU ? p.source : p, f)
        : Base((piRE = p instanceof $RegExp) ? p.source : p, piRE && fiU ? $flags.call(p) : f)
      , tiRE ? this : proto, $RegExp);
  };
  var proxy = function (key) {
    key in $RegExp || dP($RegExp, key, {
      configurable: true,
      get: function () { return Base[key]; },
      set: function (it) { Base[key] = it; }
    });
  };
  for (var keys = gOPN(Base), i = 0; keys.length > i;) proxy(keys[i++]);
  proto.constructor = $RegExp;
  $RegExp.prototype = proto;
  __webpack_require__(16)(global, 'RegExp', $RegExp);
}

__webpack_require__(52)('RegExp');


/***/ }),
/* 335 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

__webpack_require__(176);
var anObject = __webpack_require__(1);
var $flags = __webpack_require__(71);
var DESCRIPTORS = __webpack_require__(8);
var TO_STRING = 'toString';
var $toString = /./[TO_STRING];

var define = function (fn) {
  __webpack_require__(16)(RegExp.prototype, TO_STRING, fn, true);
};

// 21.2.5.14 RegExp.prototype.toString()
if (__webpack_require__(3)(function () { return $toString.call({ source: 'a', flags: 'b' }) != '/a/b'; })) {
  define(function toString() {
    var R = anObject(this);
    return '/'.concat(R.source, '/',
      'flags' in R ? R.flags : !DESCRIPTORS && R instanceof RegExp ? $flags.call(R) : undefined);
  });
// FF44- RegExp#toString has a wrong name
} else if ($toString.name != TO_STRING) {
  define(function toString() {
    return $toString.call(this);
  });
}


/***/ }),
/* 336 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var anObject = __webpack_require__(1);
var toLength = __webpack_require__(6);
var advanceStringIndex = __webpack_require__(130);
var regExpExec = __webpack_require__(88);

// @@match logic
__webpack_require__(89)('match', 1, function (defined, MATCH, $match, maybeCallNative) {
  return [
    // `String.prototype.match` method
    // https://tc39.github.io/ecma262/#sec-string.prototype.match
    function match(regexp) {
      var O = defined(this);
      var fn = regexp == undefined ? undefined : regexp[MATCH];
      return fn !== undefined ? fn.call(regexp, O) : new RegExp(regexp)[MATCH](String(O));
    },
    // `RegExp.prototype[@@match]` method
    // https://tc39.github.io/ecma262/#sec-regexp.prototype-@@match
    function (regexp) {
      var res = maybeCallNative($match, regexp, this);
      if (res.done) return res.value;
      var rx = anObject(regexp);
      var S = String(this);
      if (!rx.global) return regExpExec(rx, S);
      var fullUnicode = rx.unicode;
      rx.lastIndex = 0;
      var A = [];
      var n = 0;
      var result;
      while ((result = regExpExec(rx, S)) !== null) {
        var matchStr = String(result[0]);
        A[n] = matchStr;
        if (matchStr === '') rx.lastIndex = advanceStringIndex(S, toLength(rx.lastIndex), fullUnicode);
        n++;
      }
      return n === 0 ? null : A;
    }
  ];
});


/***/ }),
/* 337 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var anObject = __webpack_require__(1);
var toObject = __webpack_require__(10);
var toLength = __webpack_require__(6);
var toInteger = __webpack_require__(27);
var advanceStringIndex = __webpack_require__(130);
var regExpExec = __webpack_require__(88);
var max = Math.max;
var min = Math.min;
var floor = Math.floor;
var SUBSTITUTION_SYMBOLS = /\$([$&`']|\d\d?|<[^>]*>)/g;
var SUBSTITUTION_SYMBOLS_NO_NAMED = /\$([$&`']|\d\d?)/g;

var maybeToString = function (it) {
  return it === undefined ? it : String(it);
};

// @@replace logic
__webpack_require__(89)('replace', 2, function (defined, REPLACE, $replace, maybeCallNative) {
  return [
    // `String.prototype.replace` method
    // https://tc39.github.io/ecma262/#sec-string.prototype.replace
    function replace(searchValue, replaceValue) {
      var O = defined(this);
      var fn = searchValue == undefined ? undefined : searchValue[REPLACE];
      return fn !== undefined
        ? fn.call(searchValue, O, replaceValue)
        : $replace.call(String(O), searchValue, replaceValue);
    },
    // `RegExp.prototype[@@replace]` method
    // https://tc39.github.io/ecma262/#sec-regexp.prototype-@@replace
    function (regexp, replaceValue) {
      var res = maybeCallNative($replace, regexp, this, replaceValue);
      if (res.done) return res.value;

      var rx = anObject(regexp);
      var S = String(this);
      var functionalReplace = typeof replaceValue === 'function';
      if (!functionalReplace) replaceValue = String(replaceValue);
      var global = rx.global;
      if (global) {
        var fullUnicode = rx.unicode;
        rx.lastIndex = 0;
      }
      var results = [];
      while (true) {
        var result = regExpExec(rx, S);
        if (result === null) break;
        results.push(result);
        if (!global) break;
        var matchStr = String(result[0]);
        if (matchStr === '') rx.lastIndex = advanceStringIndex(S, toLength(rx.lastIndex), fullUnicode);
      }
      var accumulatedResult = '';
      var nextSourcePosition = 0;
      for (var i = 0; i < results.length; i++) {
        result = results[i];
        var matched = String(result[0]);
        var position = max(min(toInteger(result.index), S.length), 0);
        var captures = [];
        // NOTE: This is equivalent to
        //   captures = result.slice(1).map(maybeToString)
        // but for some reason `nativeSlice.call(result, 1, result.length)` (called in
        // the slice polyfill when slicing native arrays) "doesn't work" in safari 9 and
        // causes a crash (https://pastebin.com/N21QzeQA) when trying to debug it.
        for (var j = 1; j < result.length; j++) captures.push(maybeToString(result[j]));
        var namedCaptures = result.groups;
        if (functionalReplace) {
          var replacerArgs = [matched].concat(captures, position, S);
          if (namedCaptures !== undefined) replacerArgs.push(namedCaptures);
          var replacement = String(replaceValue.apply(undefined, replacerArgs));
        } else {
          replacement = getSubstitution(matched, S, position, captures, namedCaptures, replaceValue);
        }
        if (position >= nextSourcePosition) {
          accumulatedResult += S.slice(nextSourcePosition, position) + replacement;
          nextSourcePosition = position + matched.length;
        }
      }
      return accumulatedResult + S.slice(nextSourcePosition);
    }
  ];

    // https://tc39.github.io/ecma262/#sec-getsubstitution
  function getSubstitution(matched, str, position, captures, namedCaptures, replacement) {
    var tailPos = position + matched.length;
    var m = captures.length;
    var symbols = SUBSTITUTION_SYMBOLS_NO_NAMED;
    if (namedCaptures !== undefined) {
      namedCaptures = toObject(namedCaptures);
      symbols = SUBSTITUTION_SYMBOLS;
    }
    return $replace.call(replacement, symbols, function (match, ch) {
      var capture;
      switch (ch.charAt(0)) {
        case '$': return '$';
        case '&': return matched;
        case '`': return str.slice(0, position);
        case "'": return str.slice(tailPos);
        case '<':
          capture = namedCaptures[ch.slice(1, -1)];
          break;
        default: // \d\d?
          var n = +ch;
          if (n === 0) return match;
          if (n > m) {
            var f = floor(n / 10);
            if (f === 0) return match;
            if (f <= m) return captures[f - 1] === undefined ? ch.charAt(1) : captures[f - 1] + ch.charAt(1);
            return match;
          }
          capture = captures[n - 1];
      }
      return capture === undefined ? '' : capture;
    });
  }
});


/***/ }),
/* 338 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var anObject = __webpack_require__(1);
var sameValue = __webpack_require__(162);
var regExpExec = __webpack_require__(88);

// @@search logic
__webpack_require__(89)('search', 1, function (defined, SEARCH, $search, maybeCallNative) {
  return [
    // `String.prototype.search` method
    // https://tc39.github.io/ecma262/#sec-string.prototype.search
    function search(regexp) {
      var O = defined(this);
      var fn = regexp == undefined ? undefined : regexp[SEARCH];
      return fn !== undefined ? fn.call(regexp, O) : new RegExp(regexp)[SEARCH](String(O));
    },
    // `RegExp.prototype[@@search]` method
    // https://tc39.github.io/ecma262/#sec-regexp.prototype-@@search
    function (regexp) {
      var res = maybeCallNative($search, regexp, this);
      if (res.done) return res.value;
      var rx = anObject(regexp);
      var S = String(this);
      var previousLastIndex = rx.lastIndex;
      if (!sameValue(previousLastIndex, 0)) rx.lastIndex = 0;
      var result = regExpExec(rx, S);
      if (!sameValue(rx.lastIndex, previousLastIndex)) rx.lastIndex = previousLastIndex;
      return result === null ? -1 : result.index;
    }
  ];
});


/***/ }),
/* 339 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var isRegExp = __webpack_require__(86);
var anObject = __webpack_require__(1);
var speciesConstructor = __webpack_require__(72);
var advanceStringIndex = __webpack_require__(130);
var toLength = __webpack_require__(6);
var callRegExpExec = __webpack_require__(88);
var regexpExec = __webpack_require__(129);
var fails = __webpack_require__(3);
var $min = Math.min;
var $push = [].push;
var $SPLIT = 'split';
var LENGTH = 'length';
var LAST_INDEX = 'lastIndex';
var MAX_UINT32 = 0xffffffff;

// babel-minify transpiles RegExp('x', 'y') -> /x/y and it causes SyntaxError
var SUPPORTS_Y = !fails(function () { RegExp(MAX_UINT32, 'y'); });

// @@split logic
__webpack_require__(89)('split', 2, function (defined, SPLIT, $split, maybeCallNative) {
  var internalSplit;
  if (
    'abbc'[$SPLIT](/(b)*/)[1] == 'c' ||
    'test'[$SPLIT](/(?:)/, -1)[LENGTH] != 4 ||
    'ab'[$SPLIT](/(?:ab)*/)[LENGTH] != 2 ||
    '.'[$SPLIT](/(.?)(.?)/)[LENGTH] != 4 ||
    '.'[$SPLIT](/()()/)[LENGTH] > 1 ||
    ''[$SPLIT](/.?/)[LENGTH]
  ) {
    // based on es5-shim implementation, need to rework it
    internalSplit = function (separator, limit) {
      var string = String(this);
      if (separator === undefined && limit === 0) return [];
      // If `separator` is not a regex, use native split
      if (!isRegExp(separator)) return $split.call(string, separator, limit);
      var output = [];
      var flags = (separator.ignoreCase ? 'i' : '') +
                  (separator.multiline ? 'm' : '') +
                  (separator.unicode ? 'u' : '') +
                  (separator.sticky ? 'y' : '');
      var lastLastIndex = 0;
      var splitLimit = limit === undefined ? MAX_UINT32 : limit >>> 0;
      // Make `global` and avoid `lastIndex` issues by working with a copy
      var separatorCopy = new RegExp(separator.source, flags + 'g');
      var match, lastIndex, lastLength;
      while (match = regexpExec.call(separatorCopy, string)) {
        lastIndex = separatorCopy[LAST_INDEX];
        if (lastIndex > lastLastIndex) {
          output.push(string.slice(lastLastIndex, match.index));
          if (match[LENGTH] > 1 && match.index < string[LENGTH]) $push.apply(output, match.slice(1));
          lastLength = match[0][LENGTH];
          lastLastIndex = lastIndex;
          if (output[LENGTH] >= splitLimit) break;
        }
        if (separatorCopy[LAST_INDEX] === match.index) separatorCopy[LAST_INDEX]++; // Avoid an infinite loop
      }
      if (lastLastIndex === string[LENGTH]) {
        if (lastLength || !separatorCopy.test('')) output.push('');
      } else output.push(string.slice(lastLastIndex));
      return output[LENGTH] > splitLimit ? output.slice(0, splitLimit) : output;
    };
  // Chakra, V8
  } else if ('0'[$SPLIT](undefined, 0)[LENGTH]) {
    internalSplit = function (separator, limit) {
      return separator === undefined && limit === 0 ? [] : $split.call(this, separator, limit);
    };
  } else {
    internalSplit = $split;
  }

  return [
    // `String.prototype.split` method
    // https://tc39.github.io/ecma262/#sec-string.prototype.split
    function split(separator, limit) {
      var O = defined(this);
      var splitter = separator == undefined ? undefined : separator[SPLIT];
      return splitter !== undefined
        ? splitter.call(separator, O, limit)
        : internalSplit.call(String(O), separator, limit);
    },
    // `RegExp.prototype[@@split]` method
    // https://tc39.github.io/ecma262/#sec-regexp.prototype-@@split
    //
    // NOTE: This cannot be properly polyfilled in engines that don't support
    // the 'y' flag.
    function (regexp, limit) {
      var res = maybeCallNative(internalSplit, regexp, this, limit, internalSplit !== $split);
      if (res.done) return res.value;

      var rx = anObject(regexp);
      var S = String(this);
      var C = speciesConstructor(rx, RegExp);

      var unicodeMatching = rx.unicode;
      var flags = (rx.ignoreCase ? 'i' : '') +
                  (rx.multiline ? 'm' : '') +
                  (rx.unicode ? 'u' : '') +
                  (SUPPORTS_Y ? 'y' : 'g');

      // ^(? + rx + ) is needed, in combination with some S slicing, to
      // simulate the 'y' flag.
      var splitter = new C(SUPPORTS_Y ? rx : '^(?:' + rx.source + ')', flags);
      var lim = limit === undefined ? MAX_UINT32 : limit >>> 0;
      if (lim === 0) return [];
      if (S.length === 0) return callRegExpExec(splitter, S) === null ? [S] : [];
      var p = 0;
      var q = 0;
      var A = [];
      while (q < S.length) {
        splitter.lastIndex = SUPPORTS_Y ? q : 0;
        var z = callRegExpExec(splitter, SUPPORTS_Y ? S : S.slice(q));
        var e;
        if (
          z === null ||
          (e = $min(toLength(splitter.lastIndex + (SUPPORTS_Y ? 0 : q)), S.length)) === p
        ) {
          q = advanceStringIndex(S, q, unicodeMatching);
        } else {
          A.push(S.slice(p, q));
          if (A.length === lim) return A;
          for (var i = 1; i <= z.length - 1; i++) {
            A.push(z[i]);
            if (A.length === lim) return A;
          }
          q = p = e;
        }
      }
      A.push(S.slice(p));
      return A;
    }
  ];
});


/***/ }),
/* 340 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var LIBRARY = __webpack_require__(41);
var global = __webpack_require__(2);
var ctx = __webpack_require__(25);
var classof = __webpack_require__(61);
var $export = __webpack_require__(0);
var isObject = __webpack_require__(4);
var aFunction = __webpack_require__(11);
var anInstance = __webpack_require__(53);
var forOf = __webpack_require__(54);
var speciesConstructor = __webpack_require__(72);
var task = __webpack_require__(131).set;
var microtask = __webpack_require__(132)();
var newPromiseCapabilityModule = __webpack_require__(133);
var perform = __webpack_require__(177);
var userAgent = __webpack_require__(90);
var promiseResolve = __webpack_require__(178);
var PROMISE = 'Promise';
var TypeError = global.TypeError;
var process = global.process;
var versions = process && process.versions;
var v8 = versions && versions.v8 || '';
var $Promise = global[PROMISE];
var isNode = classof(process) == 'process';
var empty = function () { /* empty */ };
var Internal, newGenericPromiseCapability, OwnPromiseCapability, Wrapper;
var newPromiseCapability = newGenericPromiseCapability = newPromiseCapabilityModule.f;

var USE_NATIVE = !!function () {
  try {
    // correct subclassing with @@species support
    var promise = $Promise.resolve(1);
    var FakePromise = (promise.constructor = {})[__webpack_require__(5)('species')] = function (exec) {
      exec(empty, empty);
    };
    // unhandled rejections tracking support, NodeJS Promise without it fails @@species test
    return (isNode || typeof PromiseRejectionEvent == 'function')
      && promise.then(empty) instanceof FakePromise
      // v8 6.6 (Node 10 and Chrome 66) have a bug with resolving custom thenables
      // https://bugs.chromium.org/p/chromium/issues/detail?id=830565
      // we can't detect it synchronously, so just check versions
      && v8.indexOf('6.6') !== 0
      && userAgent.indexOf('Chrome/66') === -1;
  } catch (e) { /* empty */ }
}();

// helpers
var isThenable = function (it) {
  var then;
  return isObject(it) && typeof (then = it.then) == 'function' ? then : false;
};
var notify = function (promise, isReject) {
  if (promise._n) return;
  promise._n = true;
  var chain = promise._c;
  microtask(function () {
    var value = promise._v;
    var ok = promise._s == 1;
    var i = 0;
    var run = function (reaction) {
      var handler = ok ? reaction.ok : reaction.fail;
      var resolve = reaction.resolve;
      var reject = reaction.reject;
      var domain = reaction.domain;
      var result, then, exited;
      try {
        if (handler) {
          if (!ok) {
            if (promise._h == 2) onHandleUnhandled(promise);
            promise._h = 1;
          }
          if (handler === true) result = value;
          else {
            if (domain) domain.enter();
            result = handler(value); // may throw
            if (domain) {
              domain.exit();
              exited = true;
            }
          }
          if (result === reaction.promise) {
            reject(TypeError('Promise-chain cycle'));
          } else if (then = isThenable(result)) {
            then.call(result, resolve, reject);
          } else resolve(result);
        } else reject(value);
      } catch (e) {
        if (domain && !exited) domain.exit();
        reject(e);
      }
    };
    while (chain.length > i) run(chain[i++]); // variable length - can't use forEach
    promise._c = [];
    promise._n = false;
    if (isReject && !promise._h) onUnhandled(promise);
  });
};
var onUnhandled = function (promise) {
  task.call(global, function () {
    var value = promise._v;
    var unhandled = isUnhandled(promise);
    var result, handler, console;
    if (unhandled) {
      result = perform(function () {
        if (isNode) {
          process.emit('unhandledRejection', value, promise);
        } else if (handler = global.onunhandledrejection) {
          handler({ promise: promise, reason: value });
        } else if ((console = global.console) && console.error) {
          console.error('Unhandled promise rejection', value);
        }
      });
      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
      promise._h = isNode || isUnhandled(promise) ? 2 : 1;
    } promise._a = undefined;
    if (unhandled && result.e) throw result.v;
  });
};
var isUnhandled = function (promise) {
  return promise._h !== 1 && (promise._a || promise._c).length === 0;
};
var onHandleUnhandled = function (promise) {
  task.call(global, function () {
    var handler;
    if (isNode) {
      process.emit('rejectionHandled', promise);
    } else if (handler = global.onrejectionhandled) {
      handler({ promise: promise, reason: promise._v });
    }
  });
};
var $reject = function (value) {
  var promise = this;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  promise._v = value;
  promise._s = 2;
  if (!promise._a) promise._a = promise._c.slice();
  notify(promise, true);
};
var $resolve = function (value) {
  var promise = this;
  var then;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  try {
    if (promise === value) throw TypeError("Promise can't be resolved itself");
    if (then = isThenable(value)) {
      microtask(function () {
        var wrapper = { _w: promise, _d: false }; // wrap
        try {
          then.call(value, ctx($resolve, wrapper, 1), ctx($reject, wrapper, 1));
        } catch (e) {
          $reject.call(wrapper, e);
        }
      });
    } else {
      promise._v = value;
      promise._s = 1;
      notify(promise, false);
    }
  } catch (e) {
    $reject.call({ _w: promise, _d: false }, e); // wrap
  }
};

// constructor polyfill
if (!USE_NATIVE) {
  // 25.4.3.1 Promise(executor)
  $Promise = function Promise(executor) {
    anInstance(this, $Promise, PROMISE, '_h');
    aFunction(executor);
    Internal.call(this);
    try {
      executor(ctx($resolve, this, 1), ctx($reject, this, 1));
    } catch (err) {
      $reject.call(this, err);
    }
  };
  // eslint-disable-next-line no-unused-vars
  Internal = function Promise(executor) {
    this._c = [];             // <- awaiting reactions
    this._a = undefined;      // <- checked in isUnhandled reactions
    this._s = 0;              // <- state
    this._d = false;          // <- done
    this._v = undefined;      // <- value
    this._h = 0;              // <- rejection state, 0 - default, 1 - handled, 2 - unhandled
    this._n = false;          // <- notify
  };
  Internal.prototype = __webpack_require__(55)($Promise.prototype, {
    // 25.4.5.3 Promise.prototype.then(onFulfilled, onRejected)
    then: function then(onFulfilled, onRejected) {
      var reaction = newPromiseCapability(speciesConstructor(this, $Promise));
      reaction.ok = typeof onFulfilled == 'function' ? onFulfilled : true;
      reaction.fail = typeof onRejected == 'function' && onRejected;
      reaction.domain = isNode ? process.domain : undefined;
      this._c.push(reaction);
      if (this._a) this._a.push(reaction);
      if (this._s) notify(this, false);
      return reaction.promise;
    },
    // 25.4.5.1 Promise.prototype.catch(onRejected)
    'catch': function (onRejected) {
      return this.then(undefined, onRejected);
    }
  });
  OwnPromiseCapability = function () {
    var promise = new Internal();
    this.promise = promise;
    this.resolve = ctx($resolve, promise, 1);
    this.reject = ctx($reject, promise, 1);
  };
  newPromiseCapabilityModule.f = newPromiseCapability = function (C) {
    return C === $Promise || C === Wrapper
      ? new OwnPromiseCapability(C)
      : newGenericPromiseCapability(C);
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, { Promise: $Promise });
__webpack_require__(60)($Promise, PROMISE);
__webpack_require__(52)(PROMISE);
Wrapper = __webpack_require__(24)[PROMISE];

// statics
$export($export.S + $export.F * !USE_NATIVE, PROMISE, {
  // 25.4.4.5 Promise.reject(r)
  reject: function reject(r) {
    var capability = newPromiseCapability(this);
    var $$reject = capability.reject;
    $$reject(r);
    return capability.promise;
  }
});
$export($export.S + $export.F * (LIBRARY || !USE_NATIVE), PROMISE, {
  // 25.4.4.6 Promise.resolve(x)
  resolve: function resolve(x) {
    return promiseResolve(LIBRARY && this === Wrapper ? $Promise : this, x);
  }
});
$export($export.S + $export.F * !(USE_NATIVE && __webpack_require__(87)(function (iter) {
  $Promise.all(iter)['catch'](empty);
})), PROMISE, {
  // 25.4.4.1 Promise.all(iterable)
  all: function all(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var resolve = capability.resolve;
    var reject = capability.reject;
    var result = perform(function () {
      var values = [];
      var index = 0;
      var remaining = 1;
      forOf(iterable, false, function (promise) {
        var $index = index++;
        var alreadyCalled = false;
        values.push(undefined);
        remaining++;
        C.resolve(promise).then(function (value) {
          if (alreadyCalled) return;
          alreadyCalled = true;
          values[$index] = value;
          --remaining || resolve(values);
        }, reject);
      });
      --remaining || resolve(values);
    });
    if (result.e) reject(result.v);
    return capability.promise;
  },
  // 25.4.4.4 Promise.race(iterable)
  race: function race(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var reject = capability.reject;
    var result = perform(function () {
      forOf(iterable, false, function (promise) {
        C.resolve(promise).then(capability.resolve, reject);
      });
    });
    if (result.e) reject(result.v);
    return capability.promise;
  }
});


/***/ }),
/* 341 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var weak = __webpack_require__(183);
var validate = __webpack_require__(56);
var WEAK_SET = 'WeakSet';

// 23.4 WeakSet Objects
__webpack_require__(91)(WEAK_SET, function (get) {
  return function WeakSet() { return get(this, arguments.length > 0 ? arguments[0] : undefined); };
}, {
  // 23.4.3.1 WeakSet.prototype.add(value)
  add: function add(value) {
    return weak.def(validate(this, WEAK_SET), value, true);
  }
}, weak, false, true);


/***/ }),
/* 342 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $typed = __webpack_require__(92);
var buffer = __webpack_require__(134);
var anObject = __webpack_require__(1);
var toAbsoluteIndex = __webpack_require__(49);
var toLength = __webpack_require__(6);
var isObject = __webpack_require__(4);
var ArrayBuffer = __webpack_require__(2).ArrayBuffer;
var speciesConstructor = __webpack_require__(72);
var $ArrayBuffer = buffer.ArrayBuffer;
var $DataView = buffer.DataView;
var $isView = $typed.ABV && ArrayBuffer.isView;
var $slice = $ArrayBuffer.prototype.slice;
var VIEW = $typed.VIEW;
var ARRAY_BUFFER = 'ArrayBuffer';

$export($export.G + $export.W + $export.F * (ArrayBuffer !== $ArrayBuffer), { ArrayBuffer: $ArrayBuffer });

$export($export.S + $export.F * !$typed.CONSTR, ARRAY_BUFFER, {
  // 24.1.3.1 ArrayBuffer.isView(arg)
  isView: function isView(it) {
    return $isView && $isView(it) || isObject(it) && VIEW in it;
  }
});

$export($export.P + $export.U + $export.F * __webpack_require__(3)(function () {
  return !new $ArrayBuffer(2).slice(1, undefined).byteLength;
}), ARRAY_BUFFER, {
  // 24.1.4.3 ArrayBuffer.prototype.slice(start, end)
  slice: function slice(start, end) {
    if ($slice !== undefined && end === undefined) return $slice.call(anObject(this), start); // FF fix
    var len = anObject(this).byteLength;
    var first = toAbsoluteIndex(start, len);
    var fin = toAbsoluteIndex(end === undefined ? len : end, len);
    var result = new (speciesConstructor(this, $ArrayBuffer))(toLength(fin - first));
    var viewS = new $DataView(this);
    var viewT = new $DataView(result);
    var index = 0;
    while (first < fin) {
      viewT.setUint8(index++, viewS.getUint8(first++));
    } return result;
  }
});

__webpack_require__(52)(ARRAY_BUFFER);


/***/ }),
/* 343 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
$export($export.G + $export.W + $export.F * !__webpack_require__(92).ABV, {
  DataView: __webpack_require__(134).DataView
});


/***/ }),
/* 344 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(38)('Int8', 1, function (init) {
  return function Int8Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 345 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(38)('Uint8', 1, function (init) {
  return function Uint8Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 346 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(38)('Uint8', 1, function (init) {
  return function Uint8ClampedArray(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
}, true);


/***/ }),
/* 347 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(38)('Int16', 2, function (init) {
  return function Int16Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 348 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(38)('Uint16', 2, function (init) {
  return function Uint16Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 349 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(38)('Int32', 4, function (init) {
  return function Int32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 350 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(38)('Uint32', 4, function (init) {
  return function Uint32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 351 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(38)('Float32', 4, function (init) {
  return function Float32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 352 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(38)('Float64', 8, function (init) {
  return function Float64Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 353 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.1 Reflect.apply(target, thisArgument, argumentsList)
var $export = __webpack_require__(0);
var aFunction = __webpack_require__(11);
var anObject = __webpack_require__(1);
var rApply = (__webpack_require__(2).Reflect || {}).apply;
var fApply = Function.apply;
// MS Edge argumentsList argument is optional
$export($export.S + $export.F * !__webpack_require__(3)(function () {
  rApply(function () { /* empty */ });
}), 'Reflect', {
  apply: function apply(target, thisArgument, argumentsList) {
    var T = aFunction(target);
    var L = anObject(argumentsList);
    return rApply ? rApply(T, thisArgument, L) : fApply.call(T, thisArgument, L);
  }
});


/***/ }),
/* 354 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.2 Reflect.construct(target, argumentsList [, newTarget])
var $export = __webpack_require__(0);
var create = __webpack_require__(50);
var aFunction = __webpack_require__(11);
var anObject = __webpack_require__(1);
var isObject = __webpack_require__(4);
var fails = __webpack_require__(3);
var bind = __webpack_require__(163);
var rConstruct = (__webpack_require__(2).Reflect || {}).construct;

// MS Edge supports only 2 arguments and argumentsList argument is optional
// FF Nightly sets third argument as `new.target`, but does not create `this` from it
var NEW_TARGET_BUG = fails(function () {
  function F() { /* empty */ }
  return !(rConstruct(function () { /* empty */ }, [], F) instanceof F);
});
var ARGS_BUG = !fails(function () {
  rConstruct(function () { /* empty */ });
});

$export($export.S + $export.F * (NEW_TARGET_BUG || ARGS_BUG), 'Reflect', {
  construct: function construct(Target, args /* , newTarget */) {
    aFunction(Target);
    anObject(args);
    var newTarget = arguments.length < 3 ? Target : aFunction(arguments[2]);
    if (ARGS_BUG && !NEW_TARGET_BUG) return rConstruct(Target, args, newTarget);
    if (Target == newTarget) {
      // w/o altered newTarget, optimization for 0-4 arguments
      switch (args.length) {
        case 0: return new Target();
        case 1: return new Target(args[0]);
        case 2: return new Target(args[0], args[1]);
        case 3: return new Target(args[0], args[1], args[2]);
        case 4: return new Target(args[0], args[1], args[2], args[3]);
      }
      // w/o altered newTarget, lot of arguments case
      var $args = [null];
      $args.push.apply($args, args);
      return new (bind.apply(Target, $args))();
    }
    // with altered newTarget, not support built-in constructors
    var proto = newTarget.prototype;
    var instance = create(isObject(proto) ? proto : Object.prototype);
    var result = Function.apply.call(Target, instance, args);
    return isObject(result) ? result : instance;
  }
});


/***/ }),
/* 355 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.3 Reflect.defineProperty(target, propertyKey, attributes)
var dP = __webpack_require__(9);
var $export = __webpack_require__(0);
var anObject = __webpack_require__(1);
var toPrimitive = __webpack_require__(31);

// MS Edge has broken Reflect.defineProperty - throwing instead of returning false
$export($export.S + $export.F * __webpack_require__(3)(function () {
  // eslint-disable-next-line no-undef
  Reflect.defineProperty(dP.f({}, 1, { value: 1 }), 1, { value: 2 });
}), 'Reflect', {
  defineProperty: function defineProperty(target, propertyKey, attributes) {
    anObject(target);
    propertyKey = toPrimitive(propertyKey, true);
    anObject(attributes);
    try {
      dP.f(target, propertyKey, attributes);
      return true;
    } catch (e) {
      return false;
    }
  }
});


/***/ }),
/* 356 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.4 Reflect.deleteProperty(target, propertyKey)
var $export = __webpack_require__(0);
var gOPD = __webpack_require__(21).f;
var anObject = __webpack_require__(1);

$export($export.S, 'Reflect', {
  deleteProperty: function deleteProperty(target, propertyKey) {
    var desc = gOPD(anObject(target), propertyKey);
    return desc && !desc.configurable ? false : delete target[propertyKey];
  }
});


/***/ }),
/* 357 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 26.1.5 Reflect.enumerate(target)
var $export = __webpack_require__(0);
var anObject = __webpack_require__(1);
var Enumerate = function (iterated) {
  this._t = anObject(iterated); // target
  this._i = 0;                  // next index
  var keys = this._k = [];      // keys
  var key;
  for (key in iterated) keys.push(key);
};
__webpack_require__(120)(Enumerate, 'Object', function () {
  var that = this;
  var keys = that._k;
  var key;
  do {
    if (that._i >= keys.length) return { value: undefined, done: true };
  } while (!((key = keys[that._i++]) in that._t));
  return { value: key, done: false };
});

$export($export.S, 'Reflect', {
  enumerate: function enumerate(target) {
    return new Enumerate(target);
  }
});


/***/ }),
/* 358 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.6 Reflect.get(target, propertyKey [, receiver])
var gOPD = __webpack_require__(21);
var getPrototypeOf = __webpack_require__(22);
var has = __webpack_require__(19);
var $export = __webpack_require__(0);
var isObject = __webpack_require__(4);
var anObject = __webpack_require__(1);

function get(target, propertyKey /* , receiver */) {
  var receiver = arguments.length < 3 ? target : arguments[2];
  var desc, proto;
  if (anObject(target) === receiver) return target[propertyKey];
  if (desc = gOPD.f(target, propertyKey)) return has(desc, 'value')
    ? desc.value
    : desc.get !== undefined
      ? desc.get.call(receiver)
      : undefined;
  if (isObject(proto = getPrototypeOf(target))) return get(proto, propertyKey, receiver);
}

$export($export.S, 'Reflect', { get: get });


/***/ }),
/* 359 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.7 Reflect.getOwnPropertyDescriptor(target, propertyKey)
var gOPD = __webpack_require__(21);
var $export = __webpack_require__(0);
var anObject = __webpack_require__(1);

$export($export.S, 'Reflect', {
  getOwnPropertyDescriptor: function getOwnPropertyDescriptor(target, propertyKey) {
    return gOPD.f(anObject(target), propertyKey);
  }
});


/***/ }),
/* 360 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.8 Reflect.getPrototypeOf(target)
var $export = __webpack_require__(0);
var getProto = __webpack_require__(22);
var anObject = __webpack_require__(1);

$export($export.S, 'Reflect', {
  getPrototypeOf: function getPrototypeOf(target) {
    return getProto(anObject(target));
  }
});


/***/ }),
/* 361 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.9 Reflect.has(target, propertyKey)
var $export = __webpack_require__(0);

$export($export.S, 'Reflect', {
  has: function has(target, propertyKey) {
    return propertyKey in target;
  }
});


/***/ }),
/* 362 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.10 Reflect.isExtensible(target)
var $export = __webpack_require__(0);
var anObject = __webpack_require__(1);
var $isExtensible = Object.isExtensible;

$export($export.S, 'Reflect', {
  isExtensible: function isExtensible(target) {
    anObject(target);
    return $isExtensible ? $isExtensible(target) : true;
  }
});


/***/ }),
/* 363 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.11 Reflect.ownKeys(target)
var $export = __webpack_require__(0);

$export($export.S, 'Reflect', { ownKeys: __webpack_require__(185) });


/***/ }),
/* 364 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.12 Reflect.preventExtensions(target)
var $export = __webpack_require__(0);
var anObject = __webpack_require__(1);
var $preventExtensions = Object.preventExtensions;

$export($export.S, 'Reflect', {
  preventExtensions: function preventExtensions(target) {
    anObject(target);
    try {
      if ($preventExtensions) $preventExtensions(target);
      return true;
    } catch (e) {
      return false;
    }
  }
});


/***/ }),
/* 365 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.13 Reflect.set(target, propertyKey, V [, receiver])
var dP = __webpack_require__(9);
var gOPD = __webpack_require__(21);
var getPrototypeOf = __webpack_require__(22);
var has = __webpack_require__(19);
var $export = __webpack_require__(0);
var createDesc = __webpack_require__(46);
var anObject = __webpack_require__(1);
var isObject = __webpack_require__(4);

function set(target, propertyKey, V /* , receiver */) {
  var receiver = arguments.length < 4 ? target : arguments[3];
  var ownDesc = gOPD.f(anObject(target), propertyKey);
  var existingDescriptor, proto;
  if (!ownDesc) {
    if (isObject(proto = getPrototypeOf(target))) {
      return set(proto, propertyKey, V, receiver);
    }
    ownDesc = createDesc(0);
  }
  if (has(ownDesc, 'value')) {
    if (ownDesc.writable === false || !isObject(receiver)) return false;
    if (existingDescriptor = gOPD.f(receiver, propertyKey)) {
      if (existingDescriptor.get || existingDescriptor.set || existingDescriptor.writable === false) return false;
      existingDescriptor.value = V;
      dP.f(receiver, propertyKey, existingDescriptor);
    } else dP.f(receiver, propertyKey, createDesc(0, V));
    return true;
  }
  return ownDesc.set === undefined ? false : (ownDesc.set.call(receiver, V), true);
}

$export($export.S, 'Reflect', { set: set });


/***/ }),
/* 366 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.14 Reflect.setPrototypeOf(target, proto)
var $export = __webpack_require__(0);
var setProto = __webpack_require__(113);

if (setProto) $export($export.S, 'Reflect', {
  setPrototypeOf: function setPrototypeOf(target, proto) {
    setProto.check(target, proto);
    try {
      setProto.set(target, proto);
      return true;
    } catch (e) {
      return false;
    }
  }
});


/***/ }),
/* 367 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/tc39/Array.prototype.includes
var $export = __webpack_require__(0);
var $includes = __webpack_require__(82)(true);

$export($export.P, 'Array', {
  includes: function includes(el /* , fromIndex = 0 */) {
    return $includes(this, el, arguments.length > 1 ? arguments[1] : undefined);
  }
});

__webpack_require__(43)('includes');


/***/ }),
/* 368 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-flatMap/#sec-Array.prototype.flatMap
var $export = __webpack_require__(0);
var flattenIntoArray = __webpack_require__(186);
var toObject = __webpack_require__(10);
var toLength = __webpack_require__(6);
var aFunction = __webpack_require__(11);
var arraySpeciesCreate = __webpack_require__(126);

$export($export.P, 'Array', {
  flatMap: function flatMap(callbackfn /* , thisArg */) {
    var O = toObject(this);
    var sourceLen, A;
    aFunction(callbackfn);
    sourceLen = toLength(O.length);
    A = arraySpeciesCreate(O, 0);
    flattenIntoArray(A, O, O, sourceLen, 0, 1, callbackfn, arguments[1]);
    return A;
  }
});

__webpack_require__(43)('flatMap');


/***/ }),
/* 369 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-flatMap/#sec-Array.prototype.flatten
var $export = __webpack_require__(0);
var flattenIntoArray = __webpack_require__(186);
var toObject = __webpack_require__(10);
var toLength = __webpack_require__(6);
var toInteger = __webpack_require__(27);
var arraySpeciesCreate = __webpack_require__(126);

$export($export.P, 'Array', {
  flatten: function flatten(/* depthArg = 1 */) {
    var depthArg = arguments[0];
    var O = toObject(this);
    var sourceLen = toLength(O.length);
    var A = arraySpeciesCreate(O, 0);
    flattenIntoArray(A, O, O, sourceLen, 0, depthArg === undefined ? 1 : toInteger(depthArg));
    return A;
  }
});

__webpack_require__(43)('flatten');


/***/ }),
/* 370 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/mathiasbynens/String.prototype.at
var $export = __webpack_require__(0);
var $at = __webpack_require__(85)(true);

$export($export.P, 'String', {
  at: function at(pos) {
    return $at(this, pos);
  }
});


/***/ }),
/* 371 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/tc39/proposal-string-pad-start-end
var $export = __webpack_require__(0);
var $pad = __webpack_require__(187);
var userAgent = __webpack_require__(90);

// https://github.com/zloirock/core-js/issues/280
var WEBKIT_BUG = /Version\/10\.\d+(\.\d+)?( Mobile\/\w+)? Safari\//.test(userAgent);

$export($export.P + $export.F * WEBKIT_BUG, 'String', {
  padStart: function padStart(maxLength /* , fillString = ' ' */) {
    return $pad(this, maxLength, arguments.length > 1 ? arguments[1] : undefined, true);
  }
});


/***/ }),
/* 372 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/tc39/proposal-string-pad-start-end
var $export = __webpack_require__(0);
var $pad = __webpack_require__(187);
var userAgent = __webpack_require__(90);

// https://github.com/zloirock/core-js/issues/280
var WEBKIT_BUG = /Version\/10\.\d+(\.\d+)?( Mobile\/\w+)? Safari\//.test(userAgent);

$export($export.P + $export.F * WEBKIT_BUG, 'String', {
  padEnd: function padEnd(maxLength /* , fillString = ' ' */) {
    return $pad(this, maxLength, arguments.length > 1 ? arguments[1] : undefined, false);
  }
});


/***/ }),
/* 373 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/sebmarkbage/ecmascript-string-left-right-trim
__webpack_require__(62)('trimLeft', function ($trim) {
  return function trimLeft() {
    return $trim(this, 1);
  };
}, 'trimStart');


/***/ }),
/* 374 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/sebmarkbage/ecmascript-string-left-right-trim
__webpack_require__(62)('trimRight', function ($trim) {
  return function trimRight() {
    return $trim(this, 2);
  };
}, 'trimEnd');


/***/ }),
/* 375 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/String.prototype.matchAll/
var $export = __webpack_require__(0);
var defined = __webpack_require__(32);
var toLength = __webpack_require__(6);
var isRegExp = __webpack_require__(86);
var getFlags = __webpack_require__(71);
var RegExpProto = RegExp.prototype;

var $RegExpStringIterator = function (regexp, string) {
  this._r = regexp;
  this._s = string;
};

__webpack_require__(120)($RegExpStringIterator, 'RegExp String', function next() {
  var match = this._r.exec(this._s);
  return { value: match, done: match === null };
});

$export($export.P, 'String', {
  matchAll: function matchAll(regexp) {
    defined(this);
    if (!isRegExp(regexp)) throw TypeError(regexp + ' is not a regexp!');
    var S = String(this);
    var flags = 'flags' in RegExpProto ? String(regexp.flags) : getFlags.call(regexp);
    var rx = new RegExp(regexp.source, ~flags.indexOf('g') ? flags : 'g' + flags);
    rx.lastIndex = toLength(regexp.lastIndex);
    return new $RegExpStringIterator(rx, S);
  }
});


/***/ }),
/* 376 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(109)('asyncIterator');


/***/ }),
/* 377 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(109)('observable');


/***/ }),
/* 378 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-object-getownpropertydescriptors
var $export = __webpack_require__(0);
var ownKeys = __webpack_require__(185);
var toIObject = __webpack_require__(20);
var gOPD = __webpack_require__(21);
var createProperty = __webpack_require__(124);

$export($export.S, 'Object', {
  getOwnPropertyDescriptors: function getOwnPropertyDescriptors(object) {
    var O = toIObject(object);
    var getDesc = gOPD.f;
    var keys = ownKeys(O);
    var result = {};
    var i = 0;
    var key, desc;
    while (keys.length > i) {
      desc = getDesc(O, key = keys[i++]);
      if (desc !== undefined) createProperty(result, key, desc);
    }
    return result;
  }
});


/***/ }),
/* 379 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-object-values-entries
var $export = __webpack_require__(0);
var $values = __webpack_require__(188)(false);

$export($export.S, 'Object', {
  values: function values(it) {
    return $values(it);
  }
});


/***/ }),
/* 380 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-object-values-entries
var $export = __webpack_require__(0);
var $entries = __webpack_require__(188)(true);

$export($export.S, 'Object', {
  entries: function entries(it) {
    return $entries(it);
  }
});


/***/ }),
/* 381 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toObject = __webpack_require__(10);
var aFunction = __webpack_require__(11);
var $defineProperty = __webpack_require__(9);

// B.2.2.2 Object.prototype.__defineGetter__(P, getter)
__webpack_require__(8) && $export($export.P + __webpack_require__(93), 'Object', {
  __defineGetter__: function __defineGetter__(P, getter) {
    $defineProperty.f(toObject(this), P, { get: aFunction(getter), enumerable: true, configurable: true });
  }
});


/***/ }),
/* 382 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toObject = __webpack_require__(10);
var aFunction = __webpack_require__(11);
var $defineProperty = __webpack_require__(9);

// B.2.2.3 Object.prototype.__defineSetter__(P, setter)
__webpack_require__(8) && $export($export.P + __webpack_require__(93), 'Object', {
  __defineSetter__: function __defineSetter__(P, setter) {
    $defineProperty.f(toObject(this), P, { set: aFunction(setter), enumerable: true, configurable: true });
  }
});


/***/ }),
/* 383 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toObject = __webpack_require__(10);
var toPrimitive = __webpack_require__(31);
var getPrototypeOf = __webpack_require__(22);
var getOwnPropertyDescriptor = __webpack_require__(21).f;

// B.2.2.4 Object.prototype.__lookupGetter__(P)
__webpack_require__(8) && $export($export.P + __webpack_require__(93), 'Object', {
  __lookupGetter__: function __lookupGetter__(P) {
    var O = toObject(this);
    var K = toPrimitive(P, true);
    var D;
    do {
      if (D = getOwnPropertyDescriptor(O, K)) return D.get;
    } while (O = getPrototypeOf(O));
  }
});


/***/ }),
/* 384 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toObject = __webpack_require__(10);
var toPrimitive = __webpack_require__(31);
var getPrototypeOf = __webpack_require__(22);
var getOwnPropertyDescriptor = __webpack_require__(21).f;

// B.2.2.5 Object.prototype.__lookupSetter__(P)
__webpack_require__(8) && $export($export.P + __webpack_require__(93), 'Object', {
  __lookupSetter__: function __lookupSetter__(P) {
    var O = toObject(this);
    var K = toPrimitive(P, true);
    var D;
    do {
      if (D = getOwnPropertyDescriptor(O, K)) return D.set;
    } while (O = getPrototypeOf(O));
  }
});


/***/ }),
/* 385 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/DavidBruant/Map-Set.prototype.toJSON
var $export = __webpack_require__(0);

$export($export.P + $export.R, 'Map', { toJSON: __webpack_require__(189)('Map') });


/***/ }),
/* 386 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/DavidBruant/Map-Set.prototype.toJSON
var $export = __webpack_require__(0);

$export($export.P + $export.R, 'Set', { toJSON: __webpack_require__(189)('Set') });


/***/ }),
/* 387 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-map.of
__webpack_require__(94)('Map');


/***/ }),
/* 388 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-set.of
__webpack_require__(94)('Set');


/***/ }),
/* 389 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakmap.of
__webpack_require__(94)('WeakMap');


/***/ }),
/* 390 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakset.of
__webpack_require__(94)('WeakSet');


/***/ }),
/* 391 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-map.from
__webpack_require__(95)('Map');


/***/ }),
/* 392 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-set.from
__webpack_require__(95)('Set');


/***/ }),
/* 393 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakmap.from
__webpack_require__(95)('WeakMap');


/***/ }),
/* 394 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakset.from
__webpack_require__(95)('WeakSet');


/***/ }),
/* 395 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-global
var $export = __webpack_require__(0);

$export($export.G, { global: __webpack_require__(2) });


/***/ }),
/* 396 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-global
var $export = __webpack_require__(0);

$export($export.S, 'System', { global: __webpack_require__(2) });


/***/ }),
/* 397 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/ljharb/proposal-is-error
var $export = __webpack_require__(0);
var cof = __webpack_require__(26);

$export($export.S, 'Error', {
  isError: function isError(it) {
    return cof(it) === 'Error';
  }
});


/***/ }),
/* 398 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  clamp: function clamp(x, lower, upper) {
    return Math.min(upper, Math.max(lower, x));
  }
});


/***/ }),
/* 399 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);

$export($export.S, 'Math', { DEG_PER_RAD: Math.PI / 180 });


/***/ }),
/* 400 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);
var RAD_PER_DEG = 180 / Math.PI;

$export($export.S, 'Math', {
  degrees: function degrees(radians) {
    return radians * RAD_PER_DEG;
  }
});


/***/ }),
/* 401 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);
var scale = __webpack_require__(191);
var fround = __webpack_require__(170);

$export($export.S, 'Math', {
  fscale: function fscale(x, inLow, inHigh, outLow, outHigh) {
    return fround(scale(x, inLow, inHigh, outLow, outHigh));
  }
});


/***/ }),
/* 402 */
/***/ (function(module, exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  iaddh: function iaddh(x0, x1, y0, y1) {
    var $x0 = x0 >>> 0;
    var $x1 = x1 >>> 0;
    var $y0 = y0 >>> 0;
    return $x1 + (y1 >>> 0) + (($x0 & $y0 | ($x0 | $y0) & ~($x0 + $y0 >>> 0)) >>> 31) | 0;
  }
});


/***/ }),
/* 403 */
/***/ (function(module, exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  isubh: function isubh(x0, x1, y0, y1) {
    var $x0 = x0 >>> 0;
    var $x1 = x1 >>> 0;
    var $y0 = y0 >>> 0;
    return $x1 - (y1 >>> 0) - ((~$x0 & $y0 | ~($x0 ^ $y0) & $x0 - $y0 >>> 0) >>> 31) | 0;
  }
});


/***/ }),
/* 404 */
/***/ (function(module, exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  imulh: function imulh(u, v) {
    var UINT16 = 0xffff;
    var $u = +u;
    var $v = +v;
    var u0 = $u & UINT16;
    var v0 = $v & UINT16;
    var u1 = $u >> 16;
    var v1 = $v >> 16;
    var t = (u1 * v0 >>> 0) + (u0 * v0 >>> 16);
    return u1 * v1 + (t >> 16) + ((u0 * v1 >>> 0) + (t & UINT16) >> 16);
  }
});


/***/ }),
/* 405 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);

$export($export.S, 'Math', { RAD_PER_DEG: 180 / Math.PI });


/***/ }),
/* 406 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);
var DEG_PER_RAD = Math.PI / 180;

$export($export.S, 'Math', {
  radians: function radians(degrees) {
    return degrees * DEG_PER_RAD;
  }
});


/***/ }),
/* 407 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);

$export($export.S, 'Math', { scale: __webpack_require__(191) });


/***/ }),
/* 408 */
/***/ (function(module, exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  umulh: function umulh(u, v) {
    var UINT16 = 0xffff;
    var $u = +u;
    var $v = +v;
    var u0 = $u & UINT16;
    var v0 = $v & UINT16;
    var u1 = $u >>> 16;
    var v1 = $v >>> 16;
    var t = (u1 * v0 >>> 0) + (u0 * v0 >>> 16);
    return u1 * v1 + (t >>> 16) + ((u0 * v1 >>> 0) + (t & UINT16) >>> 16);
  }
});


/***/ }),
/* 409 */
/***/ (function(module, exports, __webpack_require__) {

// http://jfbastien.github.io/papers/Math.signbit.html
var $export = __webpack_require__(0);

$export($export.S, 'Math', { signbit: function signbit(x) {
  // eslint-disable-next-line no-self-compare
  return (x = +x) != x ? x : x == 0 ? 1 / x == Infinity : x > 0;
} });


/***/ }),
/* 410 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// https://github.com/tc39/proposal-promise-finally

var $export = __webpack_require__(0);
var core = __webpack_require__(24);
var global = __webpack_require__(2);
var speciesConstructor = __webpack_require__(72);
var promiseResolve = __webpack_require__(178);

$export($export.P + $export.R, 'Promise', { 'finally': function (onFinally) {
  var C = speciesConstructor(this, core.Promise || global.Promise);
  var isFunction = typeof onFinally == 'function';
  return this.then(
    isFunction ? function (x) {
      return promiseResolve(C, onFinally()).then(function () { return x; });
    } : onFinally,
    isFunction ? function (e) {
      return promiseResolve(C, onFinally()).then(function () { throw e; });
    } : onFinally
  );
} });


/***/ }),
/* 411 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/tc39/proposal-promise-try
var $export = __webpack_require__(0);
var newPromiseCapability = __webpack_require__(133);
var perform = __webpack_require__(177);

$export($export.S, 'Promise', { 'try': function (callbackfn) {
  var promiseCapability = newPromiseCapability.f(this);
  var result = perform(callbackfn);
  (result.e ? promiseCapability.reject : promiseCapability.resolve)(result.v);
  return promiseCapability.promise;
} });


/***/ }),
/* 412 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(39);
var anObject = __webpack_require__(1);
var toMetaKey = metadata.key;
var ordinaryDefineOwnMetadata = metadata.set;

metadata.exp({ defineMetadata: function defineMetadata(metadataKey, metadataValue, target, targetKey) {
  ordinaryDefineOwnMetadata(metadataKey, metadataValue, anObject(target), toMetaKey(targetKey));
} });


/***/ }),
/* 413 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(39);
var anObject = __webpack_require__(1);
var toMetaKey = metadata.key;
var getOrCreateMetadataMap = metadata.map;
var store = metadata.store;

metadata.exp({ deleteMetadata: function deleteMetadata(metadataKey, target /* , targetKey */) {
  var targetKey = arguments.length < 3 ? undefined : toMetaKey(arguments[2]);
  var metadataMap = getOrCreateMetadataMap(anObject(target), targetKey, false);
  if (metadataMap === undefined || !metadataMap['delete'](metadataKey)) return false;
  if (metadataMap.size) return true;
  var targetMetadata = store.get(target);
  targetMetadata['delete'](targetKey);
  return !!targetMetadata.size || store['delete'](target);
} });


/***/ }),
/* 414 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(39);
var anObject = __webpack_require__(1);
var getPrototypeOf = __webpack_require__(22);
var ordinaryHasOwnMetadata = metadata.has;
var ordinaryGetOwnMetadata = metadata.get;
var toMetaKey = metadata.key;

var ordinaryGetMetadata = function (MetadataKey, O, P) {
  var hasOwn = ordinaryHasOwnMetadata(MetadataKey, O, P);
  if (hasOwn) return ordinaryGetOwnMetadata(MetadataKey, O, P);
  var parent = getPrototypeOf(O);
  return parent !== null ? ordinaryGetMetadata(MetadataKey, parent, P) : undefined;
};

metadata.exp({ getMetadata: function getMetadata(metadataKey, target /* , targetKey */) {
  return ordinaryGetMetadata(metadataKey, anObject(target), arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
} });


/***/ }),
/* 415 */
/***/ (function(module, exports, __webpack_require__) {

var Set = __webpack_require__(181);
var from = __webpack_require__(190);
var metadata = __webpack_require__(39);
var anObject = __webpack_require__(1);
var getPrototypeOf = __webpack_require__(22);
var ordinaryOwnMetadataKeys = metadata.keys;
var toMetaKey = metadata.key;

var ordinaryMetadataKeys = function (O, P) {
  var oKeys = ordinaryOwnMetadataKeys(O, P);
  var parent = getPrototypeOf(O);
  if (parent === null) return oKeys;
  var pKeys = ordinaryMetadataKeys(parent, P);
  return pKeys.length ? oKeys.length ? from(new Set(oKeys.concat(pKeys))) : pKeys : oKeys;
};

metadata.exp({ getMetadataKeys: function getMetadataKeys(target /* , targetKey */) {
  return ordinaryMetadataKeys(anObject(target), arguments.length < 2 ? undefined : toMetaKey(arguments[1]));
} });


/***/ }),
/* 416 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(39);
var anObject = __webpack_require__(1);
var ordinaryGetOwnMetadata = metadata.get;
var toMetaKey = metadata.key;

metadata.exp({ getOwnMetadata: function getOwnMetadata(metadataKey, target /* , targetKey */) {
  return ordinaryGetOwnMetadata(metadataKey, anObject(target)
    , arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
} });


/***/ }),
/* 417 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(39);
var anObject = __webpack_require__(1);
var ordinaryOwnMetadataKeys = metadata.keys;
var toMetaKey = metadata.key;

metadata.exp({ getOwnMetadataKeys: function getOwnMetadataKeys(target /* , targetKey */) {
  return ordinaryOwnMetadataKeys(anObject(target), arguments.length < 2 ? undefined : toMetaKey(arguments[1]));
} });


/***/ }),
/* 418 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(39);
var anObject = __webpack_require__(1);
var getPrototypeOf = __webpack_require__(22);
var ordinaryHasOwnMetadata = metadata.has;
var toMetaKey = metadata.key;

var ordinaryHasMetadata = function (MetadataKey, O, P) {
  var hasOwn = ordinaryHasOwnMetadata(MetadataKey, O, P);
  if (hasOwn) return true;
  var parent = getPrototypeOf(O);
  return parent !== null ? ordinaryHasMetadata(MetadataKey, parent, P) : false;
};

metadata.exp({ hasMetadata: function hasMetadata(metadataKey, target /* , targetKey */) {
  return ordinaryHasMetadata(metadataKey, anObject(target), arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
} });


/***/ }),
/* 419 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(39);
var anObject = __webpack_require__(1);
var ordinaryHasOwnMetadata = metadata.has;
var toMetaKey = metadata.key;

metadata.exp({ hasOwnMetadata: function hasOwnMetadata(metadataKey, target /* , targetKey */) {
  return ordinaryHasOwnMetadata(metadataKey, anObject(target)
    , arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
} });


/***/ }),
/* 420 */
/***/ (function(module, exports, __webpack_require__) {

var $metadata = __webpack_require__(39);
var anObject = __webpack_require__(1);
var aFunction = __webpack_require__(11);
var toMetaKey = $metadata.key;
var ordinaryDefineOwnMetadata = $metadata.set;

$metadata.exp({ metadata: function metadata(metadataKey, metadataValue) {
  return function decorator(target, targetKey) {
    ordinaryDefineOwnMetadata(
      metadataKey, metadataValue,
      (targetKey !== undefined ? anObject : aFunction)(target),
      toMetaKey(targetKey)
    );
  };
} });


/***/ }),
/* 421 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/rwaldron/tc39-notes/blob/master/es6/2014-09/sept-25.md#510-globalasap-for-enqueuing-a-microtask
var $export = __webpack_require__(0);
var microtask = __webpack_require__(132)();
var process = __webpack_require__(2).process;
var isNode = __webpack_require__(26)(process) == 'process';

$export($export.G, {
  asap: function asap(fn) {
    var domain = isNode && process.domain;
    microtask(domain ? domain.bind(fn) : fn);
  }
});


/***/ }),
/* 422 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/zenparsing/es-observable
var $export = __webpack_require__(0);
var global = __webpack_require__(2);
var core = __webpack_require__(24);
var microtask = __webpack_require__(132)();
var OBSERVABLE = __webpack_require__(5)('observable');
var aFunction = __webpack_require__(11);
var anObject = __webpack_require__(1);
var anInstance = __webpack_require__(53);
var redefineAll = __webpack_require__(55);
var hide = __webpack_require__(15);
var forOf = __webpack_require__(54);
var RETURN = forOf.RETURN;

var getMethod = function (fn) {
  return fn == null ? undefined : aFunction(fn);
};

var cleanupSubscription = function (subscription) {
  var cleanup = subscription._c;
  if (cleanup) {
    subscription._c = undefined;
    cleanup();
  }
};

var subscriptionClosed = function (subscription) {
  return subscription._o === undefined;
};

var closeSubscription = function (subscription) {
  if (!subscriptionClosed(subscription)) {
    subscription._o = undefined;
    cleanupSubscription(subscription);
  }
};

var Subscription = function (observer, subscriber) {
  anObject(observer);
  this._c = undefined;
  this._o = observer;
  observer = new SubscriptionObserver(this);
  try {
    var cleanup = subscriber(observer);
    var subscription = cleanup;
    if (cleanup != null) {
      if (typeof cleanup.unsubscribe === 'function') cleanup = function () { subscription.unsubscribe(); };
      else aFunction(cleanup);
      this._c = cleanup;
    }
  } catch (e) {
    observer.error(e);
    return;
  } if (subscriptionClosed(this)) cleanupSubscription(this);
};

Subscription.prototype = redefineAll({}, {
  unsubscribe: function unsubscribe() { closeSubscription(this); }
});

var SubscriptionObserver = function (subscription) {
  this._s = subscription;
};

SubscriptionObserver.prototype = redefineAll({}, {
  next: function next(value) {
    var subscription = this._s;
    if (!subscriptionClosed(subscription)) {
      var observer = subscription._o;
      try {
        var m = getMethod(observer.next);
        if (m) return m.call(observer, value);
      } catch (e) {
        try {
          closeSubscription(subscription);
        } finally {
          throw e;
        }
      }
    }
  },
  error: function error(value) {
    var subscription = this._s;
    if (subscriptionClosed(subscription)) throw value;
    var observer = subscription._o;
    subscription._o = undefined;
    try {
      var m = getMethod(observer.error);
      if (!m) throw value;
      value = m.call(observer, value);
    } catch (e) {
      try {
        cleanupSubscription(subscription);
      } finally {
        throw e;
      }
    } cleanupSubscription(subscription);
    return value;
  },
  complete: function complete(value) {
    var subscription = this._s;
    if (!subscriptionClosed(subscription)) {
      var observer = subscription._o;
      subscription._o = undefined;
      try {
        var m = getMethod(observer.complete);
        value = m ? m.call(observer, value) : undefined;
      } catch (e) {
        try {
          cleanupSubscription(subscription);
        } finally {
          throw e;
        }
      } cleanupSubscription(subscription);
      return value;
    }
  }
});

var $Observable = function Observable(subscriber) {
  anInstance(this, $Observable, 'Observable', '_f')._f = aFunction(subscriber);
};

redefineAll($Observable.prototype, {
  subscribe: function subscribe(observer) {
    return new Subscription(observer, this._f);
  },
  forEach: function forEach(fn) {
    var that = this;
    return new (core.Promise || global.Promise)(function (resolve, reject) {
      aFunction(fn);
      var subscription = that.subscribe({
        next: function (value) {
          try {
            return fn(value);
          } catch (e) {
            reject(e);
            subscription.unsubscribe();
          }
        },
        error: reject,
        complete: resolve
      });
    });
  }
});

redefineAll($Observable, {
  from: function from(x) {
    var C = typeof this === 'function' ? this : $Observable;
    var method = getMethod(anObject(x)[OBSERVABLE]);
    if (method) {
      var observable = anObject(method.call(x));
      return observable.constructor === C ? observable : new C(function (observer) {
        return observable.subscribe(observer);
      });
    }
    return new C(function (observer) {
      var done = false;
      microtask(function () {
        if (!done) {
          try {
            if (forOf(x, false, function (it) {
              observer.next(it);
              if (done) return RETURN;
            }) === RETURN) return;
          } catch (e) {
            if (done) throw e;
            observer.error(e);
            return;
          } observer.complete();
        }
      });
      return function () { done = true; };
    });
  },
  of: function of() {
    for (var i = 0, l = arguments.length, items = new Array(l); i < l;) items[i] = arguments[i++];
    return new (typeof this === 'function' ? this : $Observable)(function (observer) {
      var done = false;
      microtask(function () {
        if (!done) {
          for (var j = 0; j < items.length; ++j) {
            observer.next(items[j]);
            if (done) return;
          } observer.complete();
        }
      });
      return function () { done = true; };
    });
  }
});

hide($Observable.prototype, OBSERVABLE, function () { return this; });

$export($export.G, { Observable: $Observable });

__webpack_require__(52)('Observable');


/***/ }),
/* 423 */
/***/ (function(module, exports, __webpack_require__) {

// ie9- setTimeout & setInterval additional parameters fix
var global = __webpack_require__(2);
var $export = __webpack_require__(0);
var userAgent = __webpack_require__(90);
var slice = [].slice;
var MSIE = /MSIE .\./.test(userAgent); // <- dirty ie9- check
var wrap = function (set) {
  return function (fn, time /* , ...args */) {
    var boundArgs = arguments.length > 2;
    var args = boundArgs ? slice.call(arguments, 2) : false;
    return set(boundArgs ? function () {
      // eslint-disable-next-line no-new-func
      (typeof fn == 'function' ? fn : Function(fn)).apply(this, args);
    } : fn, time);
  };
};
$export($export.G + $export.B + $export.F * MSIE, {
  setTimeout: wrap(global.setTimeout),
  setInterval: wrap(global.setInterval)
});


/***/ }),
/* 424 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var $task = __webpack_require__(131);
$export($export.G + $export.B, {
  setImmediate: $task.set,
  clearImmediate: $task.clear
});


/***/ }),
/* 425 */
/***/ (function(module, exports, __webpack_require__) {

var $iterators = __webpack_require__(128);
var getKeys = __webpack_require__(48);
var redefine = __webpack_require__(16);
var global = __webpack_require__(2);
var hide = __webpack_require__(15);
var Iterators = __webpack_require__(63);
var wks = __webpack_require__(5);
var ITERATOR = wks('iterator');
var TO_STRING_TAG = wks('toStringTag');
var ArrayValues = Iterators.Array;

var DOMIterables = {
  CSSRuleList: true, // TODO: Not spec compliant, should be false.
  CSSStyleDeclaration: false,
  CSSValueList: false,
  ClientRectList: false,
  DOMRectList: false,
  DOMStringList: false,
  DOMTokenList: true,
  DataTransferItemList: false,
  FileList: false,
  HTMLAllCollection: false,
  HTMLCollection: false,
  HTMLFormElement: false,
  HTMLSelectElement: false,
  MediaList: true, // TODO: Not spec compliant, should be false.
  MimeTypeArray: false,
  NamedNodeMap: false,
  NodeList: true,
  PaintRequestList: false,
  Plugin: false,
  PluginArray: false,
  SVGLengthList: false,
  SVGNumberList: false,
  SVGPathSegList: false,
  SVGPointList: false,
  SVGStringList: false,
  SVGTransformList: false,
  SourceBufferList: false,
  StyleSheetList: true, // TODO: Not spec compliant, should be false.
  TextTrackCueList: false,
  TextTrackList: false,
  TouchList: false
};

for (var collections = getKeys(DOMIterables), i = 0; i < collections.length; i++) {
  var NAME = collections[i];
  var explicit = DOMIterables[NAME];
  var Collection = global[NAME];
  var proto = Collection && Collection.prototype;
  var key;
  if (proto) {
    if (!proto[ITERATOR]) hide(proto, ITERATOR, ArrayValues);
    if (!proto[TO_STRING_TAG]) hide(proto, TO_STRING_TAG, NAME);
    Iterators[NAME] = ArrayValues;
    if (explicit) for (key in $iterators) if (!proto[key]) redefine(proto, key, $iterators[key], true);
  }
}


/***/ }),
/* 426 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {/**
 * Copyright (c) 2014, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * https://raw.github.com/facebook/regenerator/master/LICENSE file. An
 * additional grant of patent rights can be found in the PATENTS file in
 * the same directory.
 */

!(function(global) {
  "use strict";

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  var inModule = typeof module === "object";
  var runtime = global.regeneratorRuntime;
  if (runtime) {
    if (inModule) {
      // If regeneratorRuntime is defined globally and we're in a module,
      // make the exports object identical to regeneratorRuntime.
      module.exports = runtime;
    }
    // Don't bother evaluating the rest of this file if the runtime was
    // already defined globally.
    return;
  }

  // Define the runtime globally (as expected by generated code) as either
  // module.exports (if we're in a module) or a new, empty object.
  runtime = global.regeneratorRuntime = inModule ? module.exports : {};

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);

    return generator;
  }
  runtime.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype &&
      NativeIteratorPrototype !== Op &&
      hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype =
    Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunctionPrototype[toStringTagSymbol] =
    GeneratorFunction.displayName = "GeneratorFunction";

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      prototype[method] = function(arg) {
        return this._invoke(method, arg);
      };
    });
  }

  runtime.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  runtime.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      if (!(toStringTagSymbol in genFun)) {
        genFun[toStringTagSymbol] = "GeneratorFunction";
      }
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  runtime.awrap = function(arg) {
    return { __await: arg };
  };

  function AsyncIterator(generator) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value &&
            typeof value === "object" &&
            hasOwn.call(value, "__await")) {
          return Promise.resolve(value.__await).then(function(value) {
            invoke("next", value, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return Promise.resolve(value).then(function(unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration. If the Promise is rejected, however, the
          // result for this iteration will be rejected with the same
          // reason. Note that rejections of yielded Promises are not
          // thrown back into the generator function, as is the case
          // when an awaited Promise is rejected. This difference in
          // behavior between yield and await is important, because it
          // allows the consumer to decide what to do with the yielded
          // rejection (swallow it and continue, manually .throw it back
          // into the generator, abandon iteration, whatever). With
          // await, by contrast, there is no opportunity to examine the
          // rejection reason outside the generator function, so the
          // only option is to throw it from the await expression, and
          // let the generator function handle the exception.
          result.value = unwrapped;
          resolve(result);
        }, reject);
      }
    }

    if (typeof global.process === "object" && global.process.domain) {
      invoke = global.process.domain.bind(invoke);
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new Promise(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };
  runtime.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  runtime.async = function(innerFn, outerFn, self, tryLocsList) {
    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList)
    );

    return runtime.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;

        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);

        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;

      if (context.method === "throw") {
        if (delegate.iterator.return) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);

          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }

        context.method = "throw";
        context.arg = new TypeError(
          "The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (! info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }

    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  Gp[toStringTagSymbol] = "Generator";

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  Gp[iteratorSymbol] = function() {
    return this;
  };

  Gp.toString = function() {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  runtime.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  runtime.values = values;

  function doneResult() {
    return { value: undefined, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;

      this.method = "next";
      this.arg = undefined;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined;
        }

        return !! caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined;
      }

      return ContinueSentinel;
    }
  };
})(
  // Among the various tricks for obtaining a reference to the global
  // object, this seems to be the most reliable technique that does not
  // use indirect eval (which violates Content Security Policy).
  typeof global === "object" ? global :
  typeof window === "object" ? window :
  typeof self === "object" ? self : this
);

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(81)))

/***/ }),
/* 427 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(428);
module.exports = __webpack_require__(24).RegExp.escape;


/***/ }),
/* 428 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/benjamingr/RexExp.escape
var $export = __webpack_require__(0);
var $re = __webpack_require__(429)(/[\\^$*+?.()|[\]{}]/g, '\\$&');

$export($export.S, 'RegExp', { escape: function escape(it) { return $re(it); } });


/***/ }),
/* 429 */
/***/ (function(module, exports) {

module.exports = function (regExp, replace) {
  var replacer = replace === Object(replace) ? function (part) {
    return replace[part];
  } : replace;
  return function (it) {
    return String(it).replace(regExp, replacer);
  };
};


/***/ }),
/* 430 */
/***/ (function(module, exports, __webpack_require__) {

var core = __webpack_require__(7);
var $JSON = core.JSON || (core.JSON = { stringify: JSON.stringify });
module.exports = function stringify(it) { // eslint-disable-line no-unused-vars
  return $JSON.stringify.apply($JSON, arguments);
};


/***/ }),
/* 431 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(36);

var _stringify2 = _interopRequireDefault(_stringify);

var _keys = __webpack_require__(37);

var _keys2 = _interopRequireDefault(_keys);

var _errorType = __webpack_require__(436);

var errorType = _interopRequireWildcard(_errorType);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var jsBridge = void 0,
    bridgeName = void 0,
    logEventName = void 0;
if (typeof ServiceJSBridge !== 'undefined') {
  jsBridge = window.ServiceJSBridge;
  bridgeName = 'Service';
  logEventName = 'H5_JS_SERVICE_ERR';
} else if (typeof FinChatJSBridge !== 'undefined') {
  jsBridge = window.FinChatJSBridge;
  bridgeName = 'FinChat';
  logEventName = 'H5_JS_VIEW_ERR';
}
if (typeof __wxConfig === 'undefined') {
  var _wxConfig = typeof __wxConfig__ !== 'undefined' && __wxConfig__ || {};
}
function onBridgeReady(fn) {
  typeof jsBridge !== 'undefined' ? fn() : document.addEventListener(bridgeName + 'JSBridgeReady', fn, false);
}
function invoke() {
  // invoke
  var args = arguments;
  onBridgeReady(function () {
    jsBridge.invoke.apply(jsBridge, args);
  });
}
function publish() {
  // publish
  var args = arguments;
  onBridgeReady(function () {
    jsBridge.publish.apply(jsBridge, args);
  });
}
function getUpdateTime() {
  // get wx.version.updateTime
  return typeof wx !== 'undefined' ? wx.version && wx.version.updateTime || '' : '';
}
function _reportKeyValue() {
  // 以key/value的形式上报日志
  if (reportKeyValues && reportKeyValues.length > 0) {
    invoke('reportKeyValue', {
      dataArray: reportKeyValues
    });
    reportKeyValues = [];
  }
  // !reportKeyValues || reportKeyValues.length <= 0 ||
  //   (invoke('reportKeyValue', {
  //     dataArray: reportKeyValues
  //   }),
  //   (reportKeyValues = []))
}
function _reportIDKey() {
  if (reportIDKeys && reportIDKeys.length > 0) {
    invoke('reportIDKey', {
      dataArray: reportIDKeys
    });
    reportIDKeys = [];
  }
  // !reportIDKeys ||
  //   reportIDKeys.length <= 0 ||
  //   (invoke('reportIDKey', { dataArray: reportIDKeys }), (reportIDKeys = []))
}
function systemLog() {
  if (systemLogs && systemLogs.length > 0) {
    invoke('systemLog', {
      dataArray: systemLogs
    });
    systemLogs = [];
  }
  // !systemLogs ||
  //   systemLogs.length <= 0 ||
  //   (invoke('systemLog', { dataArray: systemLogs }), (systemLogs = []))
}
function getPlatName() {
  // get platname
  return 'devtools';
}
function safeCall(fn) {
  //
  return function () {
    try {
      return fn.apply(fn, arguments);
    } catch (e) {
      console.error('reporter error:' + e.message);
    }
  };
}
function _defindGeter(key) {
  defineObj.__defineGetter__(key, function () {
    return safeCall(utils[key]);
  });
}
var reportIDKeyLength = 1,
    reportKeyValueLengthThreshold = 20,
    systemLogLength = 50,
    submitTLThreshold = 50,
    reportKeyTLThreshold = 50,
    reportIDKeyTLThreshold = 20,
    logTLThreshold = 50,
    speedReportThreshold = 500,
    slowReportThreshold = 500,
    errorReportTemp = 3,
    errorReportSize = 3,
    slowReportLength = 3,
    errorReportLength = 50,
    slowReportValueLength = 50,
    reportKeyValues = [],
    reportIDKeys = [],
    systemLogs = [],
    reportKeyTimePreTime = 0,
    reportIDKeyPreTime = 0,
    logPreTime = 0,
    submitPreTime = 0,
    slowReportTime = 0,
    speedReportMap = {},
    errorReportMap = {},
    slowReportMap = {};
typeof logxx === 'function' && logxx('reporter-sdk start');
var isIOS = getPlatName() === 'ios';
var errListenerFns = function errListenerFns() {};
var utils = {
  // log report obj
  surroundThirdByTryCatch: function surroundThirdByTryCatch(fn, ext) {
    return function () {
      var res;
      try {
        var startTime = Date.now();
        res = fn.apply(fn, arguments);
        var doTime = Date.now() - startTime;
        doTime > 1e3 && utils.slowReport({
          key: 'apiCallback',
          cost: doTime,
          extend: ext
        });
      } catch (e) {
        console.log(e);
        utils.thirdErrorReport({
          error: e,
          extend: ext
        });
      }
      return res;
    };
  },
  slowReport: function slowReport(params) {
    var key = params.key,
        cost = params.cost,
        extend = params.extend,
        force = params.force,
        slowValueType = errorType.SlowValueType[key],
        now = Date.now();
    // 指定类型 强制或上报间隔大于＝指定阀值 extend类型数不超出阀值&当前extend上报数不超出阀值
    // var flag =
    //   slowValueType &&
    //   (force || !(now - slowReportTime < slowReportThreshold)) &&
    //   !(
    //     Object.keys(slowReportMap).length > slowReportValueLength ||
    //     (slowReportMap[extend] || (slowReportMap[extend] = 0),
    //     slowReportMap[extend]++,
    //     slowReportMap[extend] > slowReportLength)
    //   )
    var flag = slowValueType && (force || now - slowReportTime >= slowReportThreshold);
    if (flag) {
      if ((0, _keys2.default)(slowReportMap).length > slowReportValueLength) {
        flag = false;
      } else {
        if (!slowReportMap[extend]) slowReportMap[extend] = 0;
        slowReportMap[extend]++;
        flag = slowReportMap[extend] <= slowReportLength;
      }
    }

    if (flag) {
      slowReportTime = now;
      var value = cost + ',' + encodeURIComponent(extend) + ',' + slowValueType;
      utils.reportKeyValue({
        key: 'Slow',
        value: value,
        force: true
      });
    }
  },
  speedReport: function speedReport(params) {
    var key = params.key,
        data = params.data,
        timeMark = params.timeMark,
        force = params.force,
        SpeedValueType = errorType.SpeedValueType[key],
        now = Date.now(),
        dataLength = 0,
        nativeTime = timeMark.nativeTime,

    // flag =
    //   SpeedValueType &&
    //   (force ||
    //     !(
    //       now - (speedReportMap[SpeedValueType] || 0) <
    //       speedReportThreshold
    //     )) &&
    //   timeMark.startTime &&
    //   timeMark.endTime &&
    //   ((SpeedValueType != 1 && SpeedValueType != 2) || nativeTime)
    flag = SpeedValueType;
    if (flag) {
      flag = (force || now - (speedReportMap[SpeedValueType] || 0) >= speedReportThreshold) && timeMark.startTime && timeMark.endTime && (SpeedValueType != 1 && SpeedValueType != 2 || nativeTime);
    }
    if (flag) {
      if (data) dataLength = (0, _stringify2.default)(data).length;
      // data && (dataLength = JSON.stringify(data).length)
      speedReportMap[SpeedValueType] = now;
      var value = SpeedValueType + ',' + timeMark.startTime + ',' + nativeTime + ',' + nativeTime + ',,' + timeMark.endTime + ',' + dataLength;
      utils.reportKeyValue({
        key: 'Speed',
        value: value,
        force: true
      });
    }
  },
  reportKeyValue: function reportKeyValue(params) {
    var key = params.key,
        value = params.value,
        force = params.force;
    // errorType.KeyValueType[key] &&
    //   ((!force && Date.now() - reportKeyTimePreTime < reportKeyTLThreshold) ||
    //     ((reportKeyTimePreTime = Date.now()),
    //     reportKeyValues.push({
    //       key: errorType.KeyValueType[key],
    //       value: value
    //     }),
    //     reportKeyValues.length >= reportKeyValueLengthThreshold &&
    //       reportKeyValue()))
    if (errorType.KeyValueType[key]) {
      if (force || Date.now() - reportKeyTimePreTime >= reportKeyTLThreshold) {
        reportKeyTimePreTime = Date.now();
        reportKeyValues.push({
          key: errorType.KeyValueType[key],
          value: value
        });
        if (reportKeyValues.length >= reportKeyValueLengthThreshold) _reportKeyValue();
      }
    }
  },
  reportIDKey: function reportIDKey(params) {
    var id = params.id,
        key = params.key,
        force = params.force;
    // errorType.IDKeyType[key] &&
    //   ((!force && Date.now() - reportIDKeyPreTime < reportIDKeyTLThreshold) ||
    //     ((reportIDKeyPreTime = Date.now()),
    //     reportIDKeys.push({
    //       id: id || isIOS ? '356' : '358',
    //       key: errorType.IDKeyType[key],
    //       value: 1
    //     }),
    //     reportIDKeys.length >= reportIDKeyLength && reportIDKey()))
    if (errorType.IDKeyType[key]) {
      if (force || Date.now() - reportIDKeyPreTime >= reportIDKeyTLThreshold) {
        reportIDKeyPreTime = Date.now();
        reportIDKeys.push({
          id: id || isIOS ? '356' : '358',
          key: errorType.IDKeyType[key],
          value: 1
        });
        if (reportIDKeys.length >= reportIDKeyLength) _reportIDKey();
      }
    }
  },
  thirdErrorReport: function thirdErrorReport(params) {
    var error = params.error,
        extend = params.extend;
    console.log(error);
    utils.errorReport({
      key: 'thirdScriptError',
      error: error,
      extend: extend
    });
  },
  errorReport: function errorReport(params) {
    var data = {},
        error = params.error || {},
        extend = params.extend;
    data.msg = extend ? error.message + ';' + extend : error.message;
    data.stack = error.stack;
    if (errorType.ErrorType[params.key]) {
      data.key = params.key;
    } else {
      data.key = 'unknowErr';
    }
    jsBridge.publish('H5_LOG_MSG', { event: logEventName, desc: data }, [params.webviewId || '']);
    console.error(data.msg);
  },
  log: function log(_log, debug) {
    if (_log && typeof _log === 'string') {
      if (debug || Date.now() - logPreTime >= logTLThreshold) {
        logPreTime = Date.now();
        systemLogs.push(_log + '');
        systemLogs.length >= systemLogLength && systemLog();
      }
    }
    // log &&typeof log === 'string' &&((!debug && Date.now() - logPreTime < logTLThreshold) ||
    //     ((logPreTime = Date.now()),
    //     systemLogs.push(log + ''),
    //     systemLogs.length >= systemLogLength && systemLog()))
  },
  submit: function submit() {
    if (Date.now() - submitPreTime >= submitTLThreshold) {
      submitPreTime = Date.now();
      _reportKeyValue();
      systemLog();
    }
    // Date.now() - submitPreTime < submitTLThreshold ||
    //   ((submitPreTime = Date.now()),
    //   reportIDKey(),
    //   reportKeyValue(),
    //   systemLog())
  },
  registerErrorListener: function registerErrorListener(fn) {
    typeof fn === 'function' && (errListenerFns = fn);
  },
  unRegisterErrorListener: function unRegisterErrorListener() {
    errListenerFns = function errListenerFns() {};
  },
  triggerErrorMessage: function triggerErrorMessage(params) {
    errListenerFns(params);
  }
};
var defineObj = {};
for (var key in utils) {
  _defindGeter(key);
}

typeof window !== 'undefined' && (window.onbeforeunload = function () {
  utils.submit();
});
window.Reporter = defineObj;
module.exports = defineObj;

/***/ }),
/* 432 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(433);
module.exports = __webpack_require__(7).Object.keys;


/***/ }),
/* 433 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 Object.keys(O)
var toObject = __webpack_require__(73);
var $keys = __webpack_require__(74);

__webpack_require__(152)('keys', function () {
  return function keys(it) {
    return $keys(toObject(it));
  };
});


/***/ }),
/* 434 */
/***/ (function(module, exports, __webpack_require__) {

// false -> Array#indexOf
// true  -> Array#includes
var toIObject = __webpack_require__(59);
var toLength = __webpack_require__(136);
var toAbsoluteIndex = __webpack_require__(435);
module.exports = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = toIObject($this);
    var length = toLength(O.length);
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare
    if (IS_INCLUDES && el != el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare
      if (value != value) return true;
    // Array#indexOf ignores holes, Array#includes - not
    } else for (;length > index; index++) if (IS_INCLUDES || index in O) {
      if (O[index] === el) return IS_INCLUDES || index || 0;
    } return !IS_INCLUDES && -1;
  };
};


/***/ }),
/* 435 */
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(137);
var max = Math.max;
var min = Math.min;
module.exports = function (index, length) {
  index = toInteger(index);
  return index < 0 ? max(index + length, 0) : min(index, length);
};


/***/ }),
/* 436 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
var IDKeyType = exports.IDKeyType = {
    login: 1,
    login_cancel: 2,
    login_fail: 3,
    request_fail: 4,
    connectSocket_fail: 5,
    closeSocket_fail: 6,
    sendSocketMessage_fail: 7,
    uploadFile_fail: 8,
    downloadFile_fail: 9,
    redirectTo_fail: 10,
    navigateTo_fail: 11,
    navigateBack_fail: 12,
    appServiceSDKScriptError: 13,
    webviewSDKScriptError: 14,
    jsEnginScriptError: 15,
    thirdScriptError: 16,
    webviewScriptError: 17,
    exparserScriptError: 18,
    startRecord: 19,
    startRecord_fail: 20,
    getLocation: 21,
    getLocation_fail: 22,
    chooseLocation: 23,
    chooseLocation_fail: 24,
    openAddress: 25,
    openAddress_fail: 26,
    openLocation: 27,
    openLocation_fail: 28,
    makePhoneCall: 29,
    makePhoneCall_fail: 30,
    operateWXData: 31,
    operateWXData_fail: 32,
    checkLogin: 33,
    checkLogin_fail: 34,
    refreshSession: 35,
    refreshSession_fail: 36,
    chooseVideo: 37,
    chooseVideo_fail: 38,
    chooseImage: 39,
    chooseImage_fail: 40,
    verifyPaymentPassword: 41,
    verifyPaymentPassword_fail: 42,
    requestPayment: 43,
    requestPayment_fail: 44,
    bindPaymentCard: 45,
    bindPaymentCard_fail: 46,
    requestPaymentToBank: 47,
    requestPaymentToBank_fail: 48,
    openDocument: 49,
    openDocument_fail: 50,
    chooseContact: 51,
    chooseContact_fail: 52,
    operateMusicPlayer: 53,
    operateMusicPlayer_fail: 54,
    getMusicPlayerState_fail: 55,
    playVoice_fail: 56,
    setNavigationBarTitle_fail: 57,
    switchTab_fail: 58,
    getImageInfo_fail: 59,
    enableCompass_fail: 60,
    enableAccelerometer_fail: 61,
    getStorage_fail: 62,
    setStorage_fail: 63,
    clearStorage_fail: 64,
    removeStorage_fail: 65,
    getStorageInfo_fail: 66,
    getStorageSync_fail: 67,
    setStorageSync_fail: 68,
    addCard_fail: 69,
    openCard_fail: 70
};
var KeyValueType = exports.KeyValueType = {
    Speed: "13544",
    Error: "13582",
    Slow: "13968"
};
var SpeedValueType = exports.SpeedValueType = {
    webview2AppService: 1,
    appService2Webview: 2,
    funcReady: 3,
    firstGetData: 4,
    firstRenderTime: 5,
    reRenderTime: 6,
    forceUpdateRenderTime: 7,
    appRoute2newPage: 8,
    newPage2pageReady: 9,
    thirdScriptRunTime: 10,
    pageframe: 11,
    WAWebview: 12
};
var SlowValueType = exports.SlowValueType = {
    apiCallback: 1,
    pageInvoke: 2
};
var ErrorType = exports.ErrorType = {
    appServiceSDKScriptError: 1,
    webviewSDKScriptError: 2,
    jsEnginScriptError: 3,
    thirdScriptError: 4,
    webviewScriptError: 5,
    exparserScriptError: 6,
    appServiceScriptError: 7
};

/***/ }),
/* 437 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(438);
module.exports = __webpack_require__(7).Object.getPrototypeOf;


/***/ }),
/* 438 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.9 Object.getPrototypeOf(O)
var toObject = __webpack_require__(73);
var $getPrototypeOf = __webpack_require__(195);

__webpack_require__(152)('getPrototypeOf', function () {
  return function getPrototypeOf(it) {
    return $getPrototypeOf(toObject(it));
  };
});


/***/ }),
/* 439 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(80);
__webpack_require__(104);
module.exports = __webpack_require__(144).f('iterator');


/***/ }),
/* 440 */
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(137);
var defined = __webpack_require__(135);
// true  -> String#at
// false -> String#codePointAt
module.exports = function (TO_STRING) {
  return function (that, pos) {
    var s = String(defined(that));
    var i = toInteger(pos);
    var l = s.length;
    var a, b;
    if (i < 0 || i >= l) return TO_STRING ? '' : undefined;
    a = s.charCodeAt(i);
    return a < 0xd800 || a > 0xdbff || i + 1 === l || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff
      ? TO_STRING ? s.charAt(i) : a
      : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
  };
};


/***/ }),
/* 441 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var create = __webpack_require__(143);
var descriptor = __webpack_require__(77);
var setToStringTag = __webpack_require__(99);
var IteratorPrototype = {};

// 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
__webpack_require__(58)(IteratorPrototype, __webpack_require__(14)('iterator'), function () { return this; });

module.exports = function (Constructor, NAME, next) {
  Constructor.prototype = create(IteratorPrototype, { next: descriptor(1, next) });
  setToStringTag(Constructor, NAME + ' Iterator');
};


/***/ }),
/* 442 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(40);
var anObject = __webpack_require__(35);
var getKeys = __webpack_require__(74);

module.exports = __webpack_require__(45) ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var keys = getKeys(Properties);
  var length = keys.length;
  var i = 0;
  var P;
  while (length > i) dP.f(O, P = keys[i++], Properties[P]);
  return O;
};


/***/ }),
/* 443 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var addToUnscopables = __webpack_require__(444);
var step = __webpack_require__(445);
var Iterators = __webpack_require__(67);
var toIObject = __webpack_require__(59);

// 22.1.3.4 Array.prototype.entries()
// 22.1.3.13 Array.prototype.keys()
// 22.1.3.29 Array.prototype.values()
// 22.1.3.30 Array.prototype[@@iterator]()
module.exports = __webpack_require__(196)(Array, 'Array', function (iterated, kind) {
  this._t = toIObject(iterated); // target
  this._i = 0;                   // next index
  this._k = kind;                // kind
// 22.1.5.2.1 %ArrayIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var kind = this._k;
  var index = this._i++;
  if (!O || index >= O.length) {
    this._t = undefined;
    return step(1);
  }
  if (kind == 'keys') return step(0, index);
  if (kind == 'values') return step(0, O[index]);
  return step(0, [index, O[index]]);
}, 'values');

// argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
Iterators.Arguments = Iterators.Array;

addToUnscopables('keys');
addToUnscopables('values');
addToUnscopables('entries');


/***/ }),
/* 444 */
/***/ (function(module, exports) {

module.exports = function () { /* empty */ };


/***/ }),
/* 445 */
/***/ (function(module, exports) {

module.exports = function (done, value) {
  return { value: value, done: !!done };
};


/***/ }),
/* 446 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(217);
__webpack_require__(201);
__webpack_require__(451);
__webpack_require__(452);
module.exports = __webpack_require__(7).Symbol;


/***/ }),
/* 447 */
/***/ (function(module, exports, __webpack_require__) {

var META = __webpack_require__(96)('meta');
var isObject = __webpack_require__(44);
var has = __webpack_require__(57);
var setDesc = __webpack_require__(40).f;
var id = 0;
var isExtensible = Object.isExtensible || function () {
  return true;
};
var FREEZE = !__webpack_require__(65)(function () {
  return isExtensible(Object.preventExtensions({}));
});
var setMeta = function (it) {
  setDesc(it, META, { value: {
    i: 'O' + ++id, // object ID
    w: {}          // weak collections IDs
  } });
};
var fastKey = function (it, create) {
  // return primitive with prefix
  if (!isObject(it)) return typeof it == 'symbol' ? it : (typeof it == 'string' ? 'S' : 'P') + it;
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return 'F';
    // not necessary to add metadata
    if (!create) return 'E';
    // add missing metadata
    setMeta(it);
  // return object ID
  } return it[META].i;
};
var getWeak = function (it, create) {
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return true;
    // not necessary to add metadata
    if (!create) return false;
    // add missing metadata
    setMeta(it);
  // return hash weak collections IDs
  } return it[META].w;
};
// add metadata on freeze-family methods calling
var onFreeze = function (it) {
  if (FREEZE && meta.NEED && isExtensible(it) && !has(it, META)) setMeta(it);
  return it;
};
var meta = module.exports = {
  KEY: META,
  NEED: false,
  fastKey: fastKey,
  getWeak: getWeak,
  onFreeze: onFreeze
};


/***/ }),
/* 448 */
/***/ (function(module, exports, __webpack_require__) {

// all enumerable object keys, includes symbols
var getKeys = __webpack_require__(74);
var gOPS = __webpack_require__(146);
var pIE = __webpack_require__(100);
module.exports = function (it) {
  var result = getKeys(it);
  var getSymbols = gOPS.f;
  if (getSymbols) {
    var symbols = getSymbols(it);
    var isEnum = pIE.f;
    var i = 0;
    var key;
    while (symbols.length > i) if (isEnum.call(it, key = symbols[i++])) result.push(key);
  } return result;
};


/***/ }),
/* 449 */
/***/ (function(module, exports, __webpack_require__) {

// 7.2.2 IsArray(argument)
var cof = __webpack_require__(75);
module.exports = Array.isArray || function isArray(arg) {
  return cof(arg) == 'Array';
};


/***/ }),
/* 450 */
/***/ (function(module, exports, __webpack_require__) {

// fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
var toIObject = __webpack_require__(59);
var gOPN = __webpack_require__(200).f;
var toString = {}.toString;

var windowNames = typeof window == 'object' && window && Object.getOwnPropertyNames
  ? Object.getOwnPropertyNames(window) : [];

var getWindowNames = function (it) {
  try {
    return gOPN(it);
  } catch (e) {
    return windowNames.slice();
  }
};

module.exports.f = function getOwnPropertyNames(it) {
  return windowNames && toString.call(it) == '[object Window]' ? getWindowNames(it) : gOPN(toIObject(it));
};


/***/ }),
/* 451 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(145)('asyncIterator');


/***/ }),
/* 452 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(145)('observable');


/***/ }),
/* 453 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(454);
module.exports = __webpack_require__(7).Object.setPrototypeOf;


/***/ }),
/* 454 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.3.19 Object.setPrototypeOf(O, proto)
var $export = __webpack_require__(18);
$export($export.S, 'Object', { setPrototypeOf: __webpack_require__(455).set });


/***/ }),
/* 455 */
/***/ (function(module, exports, __webpack_require__) {

// Works with __proto__ only. Old v8 can't work with null proto objects.
/* eslint-disable no-proto */
var isObject = __webpack_require__(44);
var anObject = __webpack_require__(35);
var check = function (O, proto) {
  anObject(O);
  if (!isObject(proto) && proto !== null) throw TypeError(proto + ": can't set as prototype!");
};
module.exports = {
  set: Object.setPrototypeOf || ('__proto__' in {} ? // eslint-disable-line
    function (test, buggy, set) {
      try {
        set = __webpack_require__(64)(Function.call, __webpack_require__(153).f(Object.prototype, '__proto__').set, 2);
        set(test, []);
        buggy = !(test instanceof Array);
      } catch (e) { buggy = true; }
      return function setPrototypeOf(O, proto) {
        check(O, proto);
        if (buggy) O.__proto__ = proto;
        else set(O, proto);
        return O;
      };
    }({}, false) : undefined),
  check: check
};


/***/ }),
/* 456 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(457);
var $Object = __webpack_require__(7).Object;
module.exports = function create(P, D) {
  return $Object.create(P, D);
};


/***/ }),
/* 457 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(18);
// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
$export($export.S, 'Object', { create: __webpack_require__(143) });


/***/ }),
/* 458 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(80);
__webpack_require__(459);
module.exports = __webpack_require__(7).Array.from;


/***/ }),
/* 459 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var ctx = __webpack_require__(64);
var $export = __webpack_require__(18);
var toObject = __webpack_require__(73);
var call = __webpack_require__(202);
var isArrayIter = __webpack_require__(203);
var toLength = __webpack_require__(136);
var createProperty = __webpack_require__(460);
var getIterFn = __webpack_require__(147);

$export($export.S + $export.F * !__webpack_require__(204)(function (iter) { Array.from(iter); }), 'Array', {
  // 22.1.2.1 Array.from(arrayLike, mapfn = undefined, thisArg = undefined)
  from: function from(arrayLike /* , mapfn = undefined, thisArg = undefined */) {
    var O = toObject(arrayLike);
    var C = typeof this == 'function' ? this : Array;
    var aLen = arguments.length;
    var mapfn = aLen > 1 ? arguments[1] : undefined;
    var mapping = mapfn !== undefined;
    var index = 0;
    var iterFn = getIterFn(O);
    var length, result, step, iterator;
    if (mapping) mapfn = ctx(mapfn, aLen > 2 ? arguments[2] : undefined, 2);
    // if object isn't iterable or it's array with default iterator - use simple case
    if (iterFn != undefined && !(C == Array && isArrayIter(iterFn))) {
      for (iterator = iterFn.call(O), result = new C(); !(step = iterator.next()).done; index++) {
        createProperty(result, index, mapping ? call(iterator, mapfn, [step.value, index], true) : step.value);
      }
    } else {
      length = toLength(O.length);
      for (result = new C(length); length > index; index++) {
        createProperty(result, index, mapping ? mapfn(O[index], index) : O[index]);
      }
    }
    result.length = index;
    return result;
  }
});


/***/ }),
/* 460 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $defineProperty = __webpack_require__(40);
var createDesc = __webpack_require__(77);

module.exports = function (object, index, value) {
  if (index in object) $defineProperty.f(object, index, createDesc(0, value));
  else object[index] = value;
};


/***/ }),
/* 461 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(104);
__webpack_require__(80);
module.exports = __webpack_require__(462);


/***/ }),
/* 462 */
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(35);
var get = __webpack_require__(147);
module.exports = __webpack_require__(7).getIterator = function (it) {
  var iterFn = get(it);
  if (typeof iterFn != 'function') throw TypeError(it + ' is not iterable!');
  return anObject(iterFn.call(it));
};


/***/ }),
/* 463 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(464);
var $Object = __webpack_require__(7).Object;
module.exports = function defineProperty(it, key, desc) {
  return $Object.defineProperty(it, key, desc);
};


/***/ }),
/* 464 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(18);
// 19.1.2.4 / 15.2.3.6 Object.defineProperty(O, P, Attributes)
$export($export.S + $export.F * !__webpack_require__(45), 'Object', { defineProperty: __webpack_require__(40).f });


/***/ }),
/* 465 */,
/* 466 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(467);
module.exports = __webpack_require__(7).Object.assign;


/***/ }),
/* 467 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.3.1 Object.assign(target, source)
var $export = __webpack_require__(18);

$export($export.S + $export.F, 'Object', { assign: __webpack_require__(468) });


/***/ }),
/* 468 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 19.1.2.1 Object.assign(target, source, ...)
var getKeys = __webpack_require__(74);
var gOPS = __webpack_require__(146);
var pIE = __webpack_require__(100);
var toObject = __webpack_require__(73);
var IObject = __webpack_require__(193);
var $assign = Object.assign;

// should work with symbols and should have deterministic property order (V8 bug)
module.exports = !$assign || __webpack_require__(65)(function () {
  var A = {};
  var B = {};
  // eslint-disable-next-line no-undef
  var S = Symbol();
  var K = 'abcdefghijklmnopqrst';
  A[S] = 7;
  K.split('').forEach(function (k) { B[k] = k; });
  return $assign({}, A)[S] != 7 || Object.keys($assign({}, B)).join('') != K;
}) ? function assign(target, source) { // eslint-disable-line no-unused-vars
  var T = toObject(target);
  var aLen = arguments.length;
  var index = 1;
  var getSymbols = gOPS.f;
  var isEnum = pIE.f;
  while (aLen > index) {
    var S = IObject(arguments[index++]);
    var keys = getSymbols ? getKeys(S).concat(getSymbols(S)) : getKeys(S);
    var length = keys.length;
    var j = 0;
    var key;
    while (length > j) if (isEnum.call(S, key = keys[j++])) T[key] = S[key];
  } return T;
} : $assign;


/***/ }),
/* 469 */,
/* 470 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(201);
__webpack_require__(80);
__webpack_require__(104);
__webpack_require__(471);
__webpack_require__(479);
__webpack_require__(480);
module.exports = __webpack_require__(7).Promise;


/***/ }),
/* 471 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var LIBRARY = __webpack_require__(76);
var global = __webpack_require__(12);
var ctx = __webpack_require__(64);
var classof = __webpack_require__(154);
var $export = __webpack_require__(18);
var isObject = __webpack_require__(44);
var aFunction = __webpack_require__(97);
var anInstance = __webpack_require__(472);
var forOf = __webpack_require__(473);
var speciesConstructor = __webpack_require__(208);
var task = __webpack_require__(149).set;
var microtask = __webpack_require__(475)();
var newPromiseCapabilityModule = __webpack_require__(150);
var perform = __webpack_require__(209);
var userAgent = __webpack_require__(476);
var promiseResolve = __webpack_require__(210);
var PROMISE = 'Promise';
var TypeError = global.TypeError;
var process = global.process;
var versions = process && process.versions;
var v8 = versions && versions.v8 || '';
var $Promise = global[PROMISE];
var isNode = classof(process) == 'process';
var empty = function () { /* empty */ };
var Internal, newGenericPromiseCapability, OwnPromiseCapability, Wrapper;
var newPromiseCapability = newGenericPromiseCapability = newPromiseCapabilityModule.f;

var USE_NATIVE = !!function () {
  try {
    // correct subclassing with @@species support
    var promise = $Promise.resolve(1);
    var FakePromise = (promise.constructor = {})[__webpack_require__(14)('species')] = function (exec) {
      exec(empty, empty);
    };
    // unhandled rejections tracking support, NodeJS Promise without it fails @@species test
    return (isNode || typeof PromiseRejectionEvent == 'function')
      && promise.then(empty) instanceof FakePromise
      // v8 6.6 (Node 10 and Chrome 66) have a bug with resolving custom thenables
      // https://bugs.chromium.org/p/chromium/issues/detail?id=830565
      // we can't detect it synchronously, so just check versions
      && v8.indexOf('6.6') !== 0
      && userAgent.indexOf('Chrome/66') === -1;
  } catch (e) { /* empty */ }
}();

// helpers
var isThenable = function (it) {
  var then;
  return isObject(it) && typeof (then = it.then) == 'function' ? then : false;
};
var notify = function (promise, isReject) {
  if (promise._n) return;
  promise._n = true;
  var chain = promise._c;
  microtask(function () {
    var value = promise._v;
    var ok = promise._s == 1;
    var i = 0;
    var run = function (reaction) {
      var handler = ok ? reaction.ok : reaction.fail;
      var resolve = reaction.resolve;
      var reject = reaction.reject;
      var domain = reaction.domain;
      var result, then, exited;
      try {
        if (handler) {
          if (!ok) {
            if (promise._h == 2) onHandleUnhandled(promise);
            promise._h = 1;
          }
          if (handler === true) result = value;
          else {
            if (domain) domain.enter();
            result = handler(value); // may throw
            if (domain) {
              domain.exit();
              exited = true;
            }
          }
          if (result === reaction.promise) {
            reject(TypeError('Promise-chain cycle'));
          } else if (then = isThenable(result)) {
            then.call(result, resolve, reject);
          } else resolve(result);
        } else reject(value);
      } catch (e) {
        if (domain && !exited) domain.exit();
        reject(e);
      }
    };
    while (chain.length > i) run(chain[i++]); // variable length - can't use forEach
    promise._c = [];
    promise._n = false;
    if (isReject && !promise._h) onUnhandled(promise);
  });
};
var onUnhandled = function (promise) {
  task.call(global, function () {
    var value = promise._v;
    var unhandled = isUnhandled(promise);
    var result, handler, console;
    if (unhandled) {
      result = perform(function () {
        if (isNode) {
          process.emit('unhandledRejection', value, promise);
        } else if (handler = global.onunhandledrejection) {
          handler({ promise: promise, reason: value });
        } else if ((console = global.console) && console.error) {
          console.error('Unhandled promise rejection', value);
        }
      });
      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
      promise._h = isNode || isUnhandled(promise) ? 2 : 1;
    } promise._a = undefined;
    if (unhandled && result.e) throw result.v;
  });
};
var isUnhandled = function (promise) {
  return promise._h !== 1 && (promise._a || promise._c).length === 0;
};
var onHandleUnhandled = function (promise) {
  task.call(global, function () {
    var handler;
    if (isNode) {
      process.emit('rejectionHandled', promise);
    } else if (handler = global.onrejectionhandled) {
      handler({ promise: promise, reason: promise._v });
    }
  });
};
var $reject = function (value) {
  var promise = this;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  promise._v = value;
  promise._s = 2;
  if (!promise._a) promise._a = promise._c.slice();
  notify(promise, true);
};
var $resolve = function (value) {
  var promise = this;
  var then;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  try {
    if (promise === value) throw TypeError("Promise can't be resolved itself");
    if (then = isThenable(value)) {
      microtask(function () {
        var wrapper = { _w: promise, _d: false }; // wrap
        try {
          then.call(value, ctx($resolve, wrapper, 1), ctx($reject, wrapper, 1));
        } catch (e) {
          $reject.call(wrapper, e);
        }
      });
    } else {
      promise._v = value;
      promise._s = 1;
      notify(promise, false);
    }
  } catch (e) {
    $reject.call({ _w: promise, _d: false }, e); // wrap
  }
};

// constructor polyfill
if (!USE_NATIVE) {
  // 25.4.3.1 Promise(executor)
  $Promise = function Promise(executor) {
    anInstance(this, $Promise, PROMISE, '_h');
    aFunction(executor);
    Internal.call(this);
    try {
      executor(ctx($resolve, this, 1), ctx($reject, this, 1));
    } catch (err) {
      $reject.call(this, err);
    }
  };
  // eslint-disable-next-line no-unused-vars
  Internal = function Promise(executor) {
    this._c = [];             // <- awaiting reactions
    this._a = undefined;      // <- checked in isUnhandled reactions
    this._s = 0;              // <- state
    this._d = false;          // <- done
    this._v = undefined;      // <- value
    this._h = 0;              // <- rejection state, 0 - default, 1 - handled, 2 - unhandled
    this._n = false;          // <- notify
  };
  Internal.prototype = __webpack_require__(477)($Promise.prototype, {
    // 25.4.5.3 Promise.prototype.then(onFulfilled, onRejected)
    then: function then(onFulfilled, onRejected) {
      var reaction = newPromiseCapability(speciesConstructor(this, $Promise));
      reaction.ok = typeof onFulfilled == 'function' ? onFulfilled : true;
      reaction.fail = typeof onRejected == 'function' && onRejected;
      reaction.domain = isNode ? process.domain : undefined;
      this._c.push(reaction);
      if (this._a) this._a.push(reaction);
      if (this._s) notify(this, false);
      return reaction.promise;
    },
    // 25.4.5.1 Promise.prototype.catch(onRejected)
    'catch': function (onRejected) {
      return this.then(undefined, onRejected);
    }
  });
  OwnPromiseCapability = function () {
    var promise = new Internal();
    this.promise = promise;
    this.resolve = ctx($resolve, promise, 1);
    this.reject = ctx($reject, promise, 1);
  };
  newPromiseCapabilityModule.f = newPromiseCapability = function (C) {
    return C === $Promise || C === Wrapper
      ? new OwnPromiseCapability(C)
      : newGenericPromiseCapability(C);
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, { Promise: $Promise });
__webpack_require__(99)($Promise, PROMISE);
__webpack_require__(478)(PROMISE);
Wrapper = __webpack_require__(7)[PROMISE];

// statics
$export($export.S + $export.F * !USE_NATIVE, PROMISE, {
  // 25.4.4.5 Promise.reject(r)
  reject: function reject(r) {
    var capability = newPromiseCapability(this);
    var $$reject = capability.reject;
    $$reject(r);
    return capability.promise;
  }
});
$export($export.S + $export.F * (LIBRARY || !USE_NATIVE), PROMISE, {
  // 25.4.4.6 Promise.resolve(x)
  resolve: function resolve(x) {
    return promiseResolve(LIBRARY && this === Wrapper ? $Promise : this, x);
  }
});
$export($export.S + $export.F * !(USE_NATIVE && __webpack_require__(204)(function (iter) {
  $Promise.all(iter)['catch'](empty);
})), PROMISE, {
  // 25.4.4.1 Promise.all(iterable)
  all: function all(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var resolve = capability.resolve;
    var reject = capability.reject;
    var result = perform(function () {
      var values = [];
      var index = 0;
      var remaining = 1;
      forOf(iterable, false, function (promise) {
        var $index = index++;
        var alreadyCalled = false;
        values.push(undefined);
        remaining++;
        C.resolve(promise).then(function (value) {
          if (alreadyCalled) return;
          alreadyCalled = true;
          values[$index] = value;
          --remaining || resolve(values);
        }, reject);
      });
      --remaining || resolve(values);
    });
    if (result.e) reject(result.v);
    return capability.promise;
  },
  // 25.4.4.4 Promise.race(iterable)
  race: function race(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var reject = capability.reject;
    var result = perform(function () {
      forOf(iterable, false, function (promise) {
        C.resolve(promise).then(capability.resolve, reject);
      });
    });
    if (result.e) reject(result.v);
    return capability.promise;
  }
});


/***/ }),
/* 472 */
/***/ (function(module, exports) {

module.exports = function (it, Constructor, name, forbiddenField) {
  if (!(it instanceof Constructor) || (forbiddenField !== undefined && forbiddenField in it)) {
    throw TypeError(name + ': incorrect invocation!');
  } return it;
};


/***/ }),
/* 473 */
/***/ (function(module, exports, __webpack_require__) {

var ctx = __webpack_require__(64);
var call = __webpack_require__(202);
var isArrayIter = __webpack_require__(203);
var anObject = __webpack_require__(35);
var toLength = __webpack_require__(136);
var getIterFn = __webpack_require__(147);
var BREAK = {};
var RETURN = {};
var exports = module.exports = function (iterable, entries, fn, that, ITERATOR) {
  var iterFn = ITERATOR ? function () { return iterable; } : getIterFn(iterable);
  var f = ctx(fn, that, entries ? 2 : 1);
  var index = 0;
  var length, step, iterator, result;
  if (typeof iterFn != 'function') throw TypeError(iterable + ' is not iterable!');
  // fast case for arrays with default iterator
  if (isArrayIter(iterFn)) for (length = toLength(iterable.length); length > index; index++) {
    result = entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
    if (result === BREAK || result === RETURN) return result;
  } else for (iterator = iterFn.call(iterable); !(step = iterator.next()).done;) {
    result = call(iterator, f, step.value, entries);
    if (result === BREAK || result === RETURN) return result;
  }
};
exports.BREAK = BREAK;
exports.RETURN = RETURN;


/***/ }),
/* 474 */
/***/ (function(module, exports) {

// fast apply, http://jsperf.lnkit.com/fast-apply/5
module.exports = function (fn, args, that) {
  var un = that === undefined;
  switch (args.length) {
    case 0: return un ? fn()
                      : fn.call(that);
    case 1: return un ? fn(args[0])
                      : fn.call(that, args[0]);
    case 2: return un ? fn(args[0], args[1])
                      : fn.call(that, args[0], args[1]);
    case 3: return un ? fn(args[0], args[1], args[2])
                      : fn.call(that, args[0], args[1], args[2]);
    case 4: return un ? fn(args[0], args[1], args[2], args[3])
                      : fn.call(that, args[0], args[1], args[2], args[3]);
  } return fn.apply(that, args);
};


/***/ }),
/* 475 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(12);
var macrotask = __webpack_require__(149).set;
var Observer = global.MutationObserver || global.WebKitMutationObserver;
var process = global.process;
var Promise = global.Promise;
var isNode = __webpack_require__(75)(process) == 'process';

module.exports = function () {
  var head, last, notify;

  var flush = function () {
    var parent, fn;
    if (isNode && (parent = process.domain)) parent.exit();
    while (head) {
      fn = head.fn;
      head = head.next;
      try {
        fn();
      } catch (e) {
        if (head) notify();
        else last = undefined;
        throw e;
      }
    } last = undefined;
    if (parent) parent.enter();
  };

  // Node.js
  if (isNode) {
    notify = function () {
      process.nextTick(flush);
    };
  // browsers with MutationObserver, except iOS Safari - https://github.com/zloirock/core-js/issues/339
  } else if (Observer && !(global.navigator && global.navigator.standalone)) {
    var toggle = true;
    var node = document.createTextNode('');
    new Observer(flush).observe(node, { characterData: true }); // eslint-disable-line no-new
    notify = function () {
      node.data = toggle = !toggle;
    };
  // environments with maybe non-completely correct, but existent Promise
  } else if (Promise && Promise.resolve) {
    // Promise.resolve without an argument throws an error in LG WebOS 2
    var promise = Promise.resolve(undefined);
    notify = function () {
      promise.then(flush);
    };
  // for other environments - macrotask based on:
  // - setImmediate
  // - MessageChannel
  // - window.postMessag
  // - onreadystatechange
  // - setTimeout
  } else {
    notify = function () {
      // strange IE + webpack dev server bug - use .call(global)
      macrotask.call(global, flush);
    };
  }

  return function (fn) {
    var task = { fn: fn, next: undefined };
    if (last) last.next = task;
    if (!head) {
      head = task;
      notify();
    } last = task;
  };
};


/***/ }),
/* 476 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(12);
var navigator = global.navigator;

module.exports = navigator && navigator.userAgent || '';


/***/ }),
/* 477 */
/***/ (function(module, exports, __webpack_require__) {

var hide = __webpack_require__(58);
module.exports = function (target, src, safe) {
  for (var key in src) {
    if (safe && target[key]) target[key] = src[key];
    else hide(target, key, src[key]);
  } return target;
};


/***/ }),
/* 478 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(12);
var core = __webpack_require__(7);
var dP = __webpack_require__(40);
var DESCRIPTORS = __webpack_require__(45);
var SPECIES = __webpack_require__(14)('species');

module.exports = function (KEY) {
  var C = typeof core[KEY] == 'function' ? core[KEY] : global[KEY];
  if (DESCRIPTORS && C && !C[SPECIES]) dP.f(C, SPECIES, {
    configurable: true,
    get: function () { return this; }
  });
};


/***/ }),
/* 479 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// https://github.com/tc39/proposal-promise-finally

var $export = __webpack_require__(18);
var core = __webpack_require__(7);
var global = __webpack_require__(12);
var speciesConstructor = __webpack_require__(208);
var promiseResolve = __webpack_require__(210);

$export($export.P + $export.R, 'Promise', { 'finally': function (onFinally) {
  var C = speciesConstructor(this, core.Promise || global.Promise);
  var isFunction = typeof onFinally == 'function';
  return this.then(
    isFunction ? function (x) {
      return promiseResolve(C, onFinally()).then(function () { return x; });
    } : onFinally,
    isFunction ? function (e) {
      return promiseResolve(C, onFinally()).then(function () { throw e; });
    } : onFinally
  );
} });


/***/ }),
/* 480 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/tc39/proposal-promise-try
var $export = __webpack_require__(18);
var newPromiseCapability = __webpack_require__(150);
var perform = __webpack_require__(209);

$export($export.S, 'Promise', { 'try': function (callbackfn) {
  var promiseCapability = newPromiseCapability.f(this);
  var result = perform(callbackfn);
  (result.e ? promiseCapability.reject : promiseCapability.resolve)(result.v);
  return promiseCapability.promise;
} });


/***/ }),
/* 481 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(482), __esModule: true };

/***/ }),
/* 482 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(483);
module.exports = __webpack_require__(7).setImmediate;


/***/ }),
/* 483 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(18);
var $task = __webpack_require__(149);
$export($export.G + $export.B, {
  setImmediate: $task.set,
  clearImmediate: $task.clear
});


/***/ }),
/* 484 */,
/* 485 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _toConsumableArray2 = __webpack_require__(630);

var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);

var _objectWithoutProperties2 = __webpack_require__(631);

var _objectWithoutProperties3 = _interopRequireDefault(_objectWithoutProperties2);

var _stringify = __webpack_require__(36);

var _stringify2 = _interopRequireDefault(_stringify);

var _utils = __webpack_require__(107);

var _utils2 = _interopRequireDefault(_utils);

var _parseUtils = __webpack_require__(214);

var _parseUtils2 = _interopRequireDefault(_parseUtils);

var _parsePage = __webpack_require__(637);

var _parsePage2 = _interopRequireDefault(_parsePage);

var _constants = __webpack_require__(639);

var eventDefine = _interopRequireWildcard(_constants);

var _logReport = __webpack_require__(510);

var reportRealtimeAction = _interopRequireWildcard(_logReport);

var _pageRouter = __webpack_require__(511);

var _pageRouter2 = _interopRequireDefault(_pageRouter);

var _parseFunction = __webpack_require__(226);

var _parseFunction2 = _interopRequireDefault(_parseFunction);

var _index = __webpack_require__(505);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var setWxRouteBegin;
var setWxRoute;
var setWxConfig;
var pageHolder;

var app = {
  appRouteTime: 0,
  newPageTime: 0,
  pageReadyTime: 0
};

var postMessagesRecord = {};

var speedReport = function speedReport(key, startTime, endTime) {
  Reporter.speedReport({
    key: key,
    timeMark: {
      startTime: startTime,
      endTime: endTime
    }
  });
};

pageHolder = function pageHolder(pageObj) {
  // Page 接口
  if (!__wxRouteBegin) {
    _utils2.default.error('Page 注册错误', 'Please do not register multiple Pages in ' + __wxRoute + '.js');
    new _utils2.default.AppServiceEngineKnownError('Please do not register multiple Pages in ' + __wxRoute + '.js');
  }
  __wxRouteBegin = false;
  var pages = __wxConfig__.pages;
  var pagePath = pages.find(function (p) {
    return p === __wxRoute;
  });
  if (!pagePath) {
    _utils2.default.warn('Page route 错误', 'Page[' + pagePath + '] not found. May be caused by: 1. Forgot to add page route in app.json. 2. Invoking Page() in async task.');
    return;
  }
  if (pagePath.startsWith('/')) {
    pagePath = pagePath.substring(1, pagePath.length);
  }
  var pageConfig = __wxConfig__.window.pages[pagePath];
  if (!pageConfig) {
    _utils2.default.error('Page 注册错误', 'Options is not object: ' + (0, _stringify2.default)(pageObj) + ' in ' + __wxRoute + '.js');
    return;
  }
  pageObj['config'] = pageConfig;
  if (_utils2.default.getDataType(pageObj) !== 'Object') {
    _utils2.default.error('Page 注册错误', 'Options is not object: ' + (0, _stringify2.default)(pageObj) + ' in ' + __wxRoute + '.js');
    new _utils2.default.AppServiceEngineKnownError('Options is not object: ' + (0, _stringify2.default)(pageObj) + ' in ' + __wxRoute + '.js');
  }
  _utils2.default.info('Register Page: ' + pagePath);
  if (pagePath.substring(0, 1) !== '/') {
    pagePath = '/' + pagePath;
  }
  pageObj['path'] = pagePath;
  pageObj['__isTruePage__'] = true;
  _pageRouter2.default.configObjs[pagePath] = pageObj;
};

var pageInitData = _utils2.default.surroundByTryCatch(function (pageObj, webviewId) {
  _utils2.default.info('Update view with init data');
  var ext = {};
  ext.webviewId = webviewId;
  ext.enablePullUpRefresh = pageObj.hasOwnProperty('onReachBottom');
  ext.enablePageScroll = pageObj.hasOwnProperty('onPageScroll');
  var usingComponents = null;
  if (pageObj['config'] && 'undefined' != typeof pageObj['config'].usingComponents) {
    usingComponents = pageObj['config'].usingComponents;
  }
  return {
    data: {
      data: pageObj.data,
      ext: ext,
      options: {
        firstRender: !0,
        usingCustomComponents: usingComponents,
        path: pageObj.path
      }
    }
    // utils.publish('appDataChange', params, [webviewId])
  };
});

// 解析page e:pagepath t:webviewId params:
var pageParse = function pageParse(routePath, webviewId, params) {
  routePath = routePath.replace(/\.htm[^\.]*$/, '');
  if (routePath.substring(0, 1) !== '/') {
    routePath = '/' + routePath;
  }
  var query = params || {};

  var _pageRouter$getPageCo = _pageRouter2.default.getPageConfig(routePath),
      __isTruePage__ = _pageRouter$getPageCo.__isTruePage__,
      curPageObj = (0, _objectWithoutProperties3.default)(_pageRouter$getPageCo, ['__isTruePage__']);

  if (!curPageObj) {
    _utils2.default.warn('Page route 错误', 'Page[' + routePath + '] not found. May be caused by: 1. Forgot to add page route in app.json. 2. Invoking Page() in async task.');
    curPageObj = {};
  }
  var newCurPageObj = _utils2.default.cloneObj(curPageObj || {});
  if (!newCurPageObj.data) {
    newCurPageObj.data = {};
  }
  newCurPageObj.data.__key_ = query.__key_;
  newCurPageObj.__query__ = query;
  app.newPageTime = Date.now();
  var page = new _parsePage2.default(newCurPageObj, webviewId, routePath, __isTruePage__);
  var initData = pageInitData(page, webviewId);
  if (_utils2.default.isDevTools()) {
    __wxAppData[routePath] = page.data;
    __wxAppData[routePath].__webviewId__ = webviewId;
    _utils2.default.publish(eventDefine.UPDATE_APP_DATA);
  }
  _pageRouter2.default.push(webviewId, page, routePath);

  _utils2.default.publish('appDataChange', _parseFunction2.default.functionToString(initData, webviewId), [webviewId]);
  reportRealtimeAction.triggerAnalytics('enterPage', page);
  speedReport('appRoute2newPage', app.appRouteTime, app.newPageTime);
};

var pageHide = function pageHide(pageItem) {
  // 执行page hide event
  _parseUtils2.default.doPageLifeTime(pageItem.page, 'onHide');
  reportRealtimeAction.triggerAnalytics('leavePage', pageItem.page);
};

var pageUnload = function pageUnload(pageItem) {
  // do page unload
  _parseUtils2.default.doPageLifeTime(pageItem.page, 'onUnload');
  if (_utils2.default.isDevTools()) {
    delete __wxAppData[pageItem.route];
    _utils2.default.publish(eventDefine.UPDATE_APP_DATA);
  }
  _pageRouter2.default.pop(pageItem.webviewId);
  reportRealtimeAction.triggerAnalytics('leavePage', pageItem.page);
};

function navigateTo(routePath, pWebViewId, pageParams, currentPage, isPageExist) {
  currentPage && pageHide(currentPage);
  isPageExist ? _utils2.default.error('Page route 错误(system error)', 'navigateTo with an already exist webviewId ' + pWebViewId) : pageParse(routePath, pWebViewId, pageParams);
}

function redirectTo(routePath, pWebViewId, pageParams, currentPage, isPageExist) {
  if (currentPage) {
    pageUnload(currentPage);
  }
  pageParse(routePath, pWebViewId, pageParams);
}

function navigateBack(routePath, pWebViewId, pageParams, currentPage, isPageExist) {
  var isExist = false;
  for (var i = _pageRouter2.default.stack.length - 1; i >= 0; i--) {
    var pageItem = _pageRouter2.default.stack[i];
    if (pageItem.webviewId === pWebViewId) {
      isExist = true;
      _pageRouter2.default.currentPage = pageItem;
      _parseUtils2.default.doPageLifeTime(pageItem.page, 'onShow');
      // pageItem.page.onShow()
      reportRealtimeAction.triggerAnalytics('enterPage', pageItem);
      break;
    }
    pageUnload(pageItem);
  }
  if (!isExist) {
    _utils2.default.error('Page route 错误(system error)', 'navigateBack with an unexist webviewId ' + pWebViewId);
  }
}

function reLaunch(routePath, pWebViewId, pageParams, currentPage, isPageExist) {
  var stack = [].concat((0, _toConsumableArray3.default)(_pageRouter2.default.stack));
  console.log('cur stack', stack);
  stack.forEach(function (page) {
    return pageUnload(page);
  });
  console.log('unload stack', _pageRouter2.default.stack);
  pageParse(routePath, pWebViewId, pageParams);
  console.log('parse stack', _pageRouter2.default.stack);
  // for () {
  //   pageUnload(stack[stack.length - 1])
  //   onlyOnePage = !1
  // }
  // currentPage && pageUnload(currentPage)
  // isPageExist ? utils.error('Page route 错误(system error)', 'redirectTo with an already exist webviewId ' + pWebViewId) : pageParse(routePath, pWebViewId, pageParams)
}

function switchTab(routePath, pWebViewId, pageParams, currentPage, isPageExist) {
  var stack = _pageRouter2.default.stack;
  if (stack.length === 0) {
    pageParse(routePath, pWebViewId, pageParams);
    return;
  }
  for (var onlyOnePage = !0; stack.length > 1;) {
    pageUnload(stack[stack.length - 1]);
    onlyOnePage = !1;
  }
  if (stack[0].webviewId === pWebViewId) {
    _pageRouter2.default.currentPage = stack[0];
    onlyOnePage || _parseUtils2.default.doPageLifeTime(currentPage.page, 'onShow');
  } else if (_pageRouter2.default.isTabBarsPage(stack[0]) ? onlyOnePage && pageHide(stack[0]) : pageUnload(stack[0]), isPageExist) {
    var pageObj = _pageRouter2.default.stackObjs[pWebViewId].page;
    _pageRouter2.default.currentPage = {
      webviewId: pWebViewId,
      route: routePath,
      page: pageObj
    };
    _pageRouter2.default.stack = [_pageRouter2.default.currentPage];
    _parseUtils2.default.doPageLifeTime(pageObj, 'onShow');
    reportRealtimeAction.triggerAnalytics('enterPage', pageObj);
  } else {
    _pageRouter2.default.stack = [];
    pageParse(routePath, pWebViewId, pageParams);
  }
}

function appLaunch(routePath, pWebViewId, pageParams, currentPage, isPageExist) {
  if (isPageExist) {
    _utils2.default.error('Page route 错误(system error)', 'appLaunch with an already exist webviewId ' + pWebViewId);
  } else {
    pageParse(routePath, pWebViewId, pageParams);
  }
}

var skipPage = function skipPage(routePath, pWebViewId, pageParams, pApiKey) {
  // 打开、跳转页面
  _utils2.default.info('On app route: ' + routePath);
  app.appRouteTime = Date.now();
  var isPageExist = _pageRouter2.default.isPageExist(pWebViewId);
  var currentPage = _pageRouter2.default.currentPage;

  switch (pApiKey) {
    case 'navigateTo':
      navigateTo(routePath, pWebViewId, pageParams, currentPage, isPageExist);
      break;
    case 'redirectTo':
      redirectTo(routePath, pWebViewId, pageParams, currentPage, isPageExist);
      break;
    case 'navigateBack':
      navigateBack(routePath, pWebViewId, pageParams, currentPage, isPageExist);
      break;
    case 'reLaunch':
      reLaunch(routePath, pWebViewId, pageParams, currentPage, isPageExist);
      break;
    case 'switchTab':
      switchTab(routePath, pWebViewId, pageParams, currentPage, isPageExist);
      break;
    case 'appLaunch':
      appLaunch(routePath, pWebViewId, pageParams, currentPage, isPageExist);
      break;
    default:
      _utils2.default.error('Page route 错误(system error)', 'Illegal open type: ' + pApiKey);
      break;
  }
};

var triggerBindMessage = function triggerBindMessage(shareapp) {
  if (_pageRouter2.default.currentPage && _pageRouter2.default.currentPage.page) {
    var bindmsgname = _pageRouter2.default.currentPage.page.__webviewbindmsgname;
    var webviewId = _pageRouter2.default.currentPage.webviewId;
    if (postMessagesRecord[webviewId] && postMessagesRecord[webviewId].length > 0) {
      bindmsgname && _pageRouter2.default.currentPage.page[bindmsgname]({
        detail: {
          data: postMessagesRecord[webviewId]
        }
      });
      !shareapp && (postMessagesRecord[webviewId] = []);
    }
  }
};

var doWebviewEvent = function doWebviewEvent(pWebviewId, pEvent, params) {
  // do dom ready
  var isPageExist = _pageRouter2.default.isPageExist(pWebviewId);
  if (!isPageExist) {
    _utils2.default.warn('事件警告', 'OnWebviewEvent: ' + pEvent + ', WebviewId: ' + pWebviewId + ' not found');
  }
  var pageItem = _pageRouter2.default.stackObjs[pWebviewId];
  var pageObj = pageItem.page;
  if (pEvent === eventDefine.DOM_READY_EVENT) {
    _parseUtils2.default.doPageLifeTime(pageObj, 'onLoad', params);
    _parseUtils2.default.doPageLifeTime(pageObj, 'onShow');
    _utils2.default.publish('pageOnLoad', {}, [pWebviewId]);
  } else if (pEvent === eventDefine.DOM_ONLOAD_DONE) {
    _parseUtils2.default.doComponentLifeTimeByWebviewId(pWebviewId, 'ready');
    pageObj.isInit = false;
    app.pageReadyTime = Date.now();
    _utils2.default.info('Invoke event onReady in page: ' + pageItem.route);
    _parseUtils2.default.doPageLifeTime(pageObj, 'onReady');
    reportRealtimeAction.triggerAnalytics('pageReady', pageObj);
    speedReport('newPage2pageReady', app.newPageTime, app.pageReadyTime);
  } else {
    _utils2.default.info('Invoke event ' + pEvent + ' in page: ' + pageItem.route);
    if (pageObj.hasOwnProperty(pEvent)) {
      _utils2.default.safeInvoke.call(pageObj, pEvent, params);
    } else {
      _utils2.default.warn('事件警告', 'Do not have ' + pEvent + ' handler in current page: ' + pageItem.route + '. Please make sure that ' + pEvent + ' handler has been defined in ' + pageItem.route + ', or ' + pageItem.route + ' has been added into app.json');
    }
  }
};

var pullDownRefresh = function pullDownRefresh(pWebviewId) {
  // do pulldownrefresh
  var isPageExist = _pageRouter2.default.isPageExist(pWebviewId);
  if (!isPageExist) {
    _utils2.default.warn('事件警告', 'onPullDownRefresh WebviewId: ' + pWebviewId + ' not found');
    return;
  }
  var pageItem = _pageRouter2.default.stackObjs[pWebviewId];
  var pageObj = pageItem.page;
  if (pageObj.hasOwnProperty('onPullDownRefresh')) {
    _utils2.default.info('Invoke event onPullDownRefresh in page: ' + pageItem.route);
    _utils2.default.safeInvoke.call(pageObj, 'onPullDownRefresh');
    reportRealtimeAction.triggerAnalytics('pullDownRefresh', pageObj);
  }
};

var invokeShareAppMessage = function invokeShareAppMessage(params, pWebviewId) {
  // invoke event onShareAppMessage
  var shareParams = params;
  var pageItem = _pageRouter2.default.stackObjs[pWebviewId];
  var pageObj = pageItem.page;
  var eventName = 'onShareAppMessage';
  var hasEventHandler = typeof pageObj[eventName] === 'function';
  if (params.isCheck) {
    return hasEventHandler;
  }
  if (hasEventHandler) {
    _utils2.default.info('Invoke event onShareAppMessage in page: ' + pageItem.route);
    var shareObj = _utils2.default.safeInvoke.call(pageObj, eventName, shareParams) || {};
    shareParams.title = shareObj.title || params.title;
    shareParams.desc = shareObj.desc || params.desc;
    shareParams.appInfo = shareObj.appInfo || params.appInfo;
    shareParams.path = shareObj.path ? shareObj.path : params.path;
    // shareParams.path = shareObj.path ? utils.addHtmlSuffixToUrl(shareObj.path) : params.path
    // if (shareParams.path.length > 0 && '/' === shareParams.path[0]) {
    //   shareParams.path = shareParams.path.substr(1)
    // }
    shareParams.success = shareObj.success;
    shareParams.cancel = shareObj.cancel;
    shareParams.imageUrl = shareObj.imageUrl;
    shareParams.fail = shareObj.fail;
    shareParams.complete = shareObj.complete;
  }
  return shareParams;
};
wx.onAppRoute(_utils2.default.surroundByTryCatch(function (params) {
  var path = params.path;
  var webviewId = params.webviewId;
  var query = params.query || {};
  var openType = params.openType || '';
  if (openType === 'navigateBack' || openType === 'redirectTo') {
    triggerBindMessage();
  }
  skipPage(path, webviewId, query, openType);
  (0, _index.cacheSystemInfo)();
}), 'onAppRoute');

wx.onWebviewEvent(_utils2.default.surroundByTryCatch(function (params) {
  var webviewId = params.webviewId;
  var eventName = params.eventName;
  var data = params.data;
  return doWebviewEvent(webviewId, eventName, data);
}, 'onWebviewEvent'));

ServiceJSBridge.on('onPullDownRefresh', _utils2.default.surroundByTryCatch(function (e, pWebViewId) {
  pullDownRefresh(pWebViewId);
}, 'onPullDownRefresh'));

var shareAppMessage = function shareAppMessage(params, webviewId) {
  var shareInfo = invokeShareAppMessage(params, webviewId);
  if (!params.isCheck) {
    triggerBindMessage(true);
    ServiceJSBridge.invoke('shareAppMessage', shareInfo, function (res) {
      if ('function' === typeof shareInfo.success && res.errMsg === 'ok') {
        shareInfo.success(res);
      } else {
        if ('function' === typeof shareInfo.fail) {
          shareInfo.fail(res);
        }
      }
      if ('function' === typeof shareInfo.complete) {
        shareInfo.complete(res);
      }
    });
  }
  return shareInfo;
};

var bindMessage = function bindMessage(params, webviewId) {
  postMessagesRecord[webviewId] = postMessagesRecord[webviewId] || [];
  postMessagesRecord[webviewId].push(params);
};

var insertHTMLWebView = function insertHTMLWebView(params, webviewId) {
  console.log('insertHTMLWebView', params, webviewId);
  _pageRouter2.default.stackObjs[webviewId].page['__webviewbindmsgname'] = params.bindmessage;
  _pageRouter2.default.stackObjs[webviewId].page['__webviewbindloadname'] = params.bindload;
  _pageRouter2.default.stackObjs[webviewId].page['__webviewbinderrorname'] = params.binderror;
  _pageRouter2.default.stackObjs[webviewId].page['__webviewsrc'] = params.src;
  _pageRouter2.default.stackObjs[webviewId].page['__ish5'] = true;
};

var webviewLoad = function webviewLoad() {
  /**
   * 包含web-view组件的页面会接收到两次onWebviewLoad事件
   * 第一次是渲染小程序原生页面，插入web-view组件。此时service层路由栈还没有页面信息，所以不触发bindload事件
   * 第二次是渲染制定url网页之后触发的，此时判断该页面定义了bindload事件即可执行
  **/
  if (_pageRouter2.default.stackObjs[arguments[1]] && _pageRouter2.default.stackObjs[arguments[1]].page['__ish5'] && _pageRouter2.default.stackObjs[arguments[1]].page['__webviewbindloadname']) {
    _pageRouter2.default.stackObjs[arguments[1]].page[_pageRouter2.default.stackObjs[arguments[1]].page.__webviewbindloadname]({
      detail: {
        src: _pageRouter2.default.stackObjs[arguments[1]].page.__webviewsrc
      }
    });
  }
};

var webviewError = function webviewError() {
  if (_pageRouter2.default.stackObjs[arguments[1]] && _pageRouter2.default.stackObjs[arguments[1]].page['__ish5'] && _pageRouter2.default.stackObjs[arguments[1]].page['__webviewbinderrorname']) {
    _pageRouter2.default.stackObjs[arguments[1]].page[_pageRouter2.default.stackObjs[arguments[1]].page.__webviewbinderrorname]({
      detail: {
        src: _pageRouter2.default.stackObjs[arguments[1]].page.__webviewsrc
      }
    });
  }
};

ServiceJSBridge.on('onShareAppMessage', _utils2.default.surroundByTryCatch(shareAppMessage, 'onShareAppMessage'));

ServiceJSBridge.on('onBindMessage', _utils2.default.surroundByTryCatch(bindMessage, 'onBindMessage'));

ServiceJSBridge.on('insertHTMLWebView', _utils2.default.surroundByTryCatch(insertHTMLWebView, 'insertHTMLWebView'));

ServiceJSBridge.on('onWebviewLoad', _utils2.default.surroundByTryCatch(webviewLoad, 'onWebviewLoad'));

ServiceJSBridge.on('onWebviewError', _utils2.default.surroundByTryCatch(webviewError, 'onWebviewError'));

setWxConfig = function setWxConfig(e) {
  __wxConfig__ = e;
};
setWxRoute = function setWxRoute(e) {
  __wxRoute = e;
};
setWxRouteBegin = function setWxRouteBegin(e) {
  __wxRouteBegin = e;
};

exports.default = {
  setWxRouteBegin: setWxRouteBegin,
  setWxRoute: setWxRoute,
  setWxConfig: setWxConfig,
  pageHolder: pageHolder,
  doWebviewEvent: doWebviewEvent,
  getRouteToPage: function getRouteToPage() {
    return _pageRouter2.default.getRouteToPage();
  },
  getWebviewIdToPage: function getWebviewIdToPage() {
    return _pageRouter2.default.getWebviewIdToPage();
  },
  reset: function reset() {
    return _pageRouter2.default.reset();
  },
  getCurrentPages: function getCurrentPages() {
    return _pageRouter2.default.getCurrentPages();
  },
  getCurrentPage: function getCurrentPage() {
    return _pageRouter2.default.getCurrentPage();
  }
};

/***/ }),
/* 486 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _assign = __webpack_require__(66);

var _assign2 = _interopRequireDefault(_assign);

var _create = __webpack_require__(30);

var _create2 = _interopRequireDefault(_create);

var _utils = __webpack_require__(107);

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var BehaviorMap = (0, _create2.default)(null);

var index = 1;

var LIFECYCLE_HOOKS = ['created', 'attached', 'ready', 'moved', 'detached'];

var sysBehavior = {
  'wx://form-field': {
    properties: {
      name: {
        type: String,
        public: true,
        observer: undefined,
        default: ''
      },
      value: {
        type: null,
        public: true,
        observer: undefined,
        default: ''
      }
    }
  }
};

function _getBehaviorId() {
  return '/' + index++ + '/' + _utils2.default.randomString(7);
}

function Behavior(behaviorobj) {
  var behaviorId = _getBehaviorId();
  for (var key in behaviorobj) {
    if (behaviorobj.hasOwnProperty(key)) {
      if (LIFECYCLE_HOOKS.includes(key)) {
        behaviorobj[key] = [behaviorobj[key]];
      }
    }
  }
  BehaviorMap[behaviorId] = behaviorobj;
  return behaviorId;
}

function getBehavior(id) {
  var behavior = void 0;
  if (id.startsWith('wx://')) {
    behavior = sysBehavior[id];
  } else {
    if (!BehaviorMap[id]) return;
    behavior = BehaviorMap[id];
    if (behavior.behaviors && Array.isArray(behavior.behaviors) && behavior.behaviors.length) {
      behavior.behaviors.forEach(function (i) {
        var subBehavior = getBehavior(i);
        for (var key in subBehavior) {
          if (subBehavior.hasOwnProperty(key)) {
            if (key === 'data' || key === 'properties' || key === 'methods') {
              behavior[key] = (0, _assign2.default)({}, subBehavior[key], behavior[key]);
            }
            if (LIFECYCLE_HOOKS.includes(key)) {
              behavior[key] = subBehavior[key].concat(behavior[key]);
            }
          }
        }
      });
      behavior.behaviors = [];
    }
  }

  return behavior;
}

function getBehaviorByKey(id, key) {
  var behavior = getBehavior(id);
  if (!behavior) return;
  return behavior[key];
}

exports.default = {
  Behavior: Behavior,
  LIFECYCLE_HOOKS: LIFECYCLE_HOOKS,
  getBehaviorByKey: getBehaviorByKey,
  getBehavior: getBehavior
};

/***/ }),
/* 487 */,
/* 488 */,
/* 489 */,
/* 490 */,
/* 491 */,
/* 492 */,
/* 493 */,
/* 494 */,
/* 495 */,
/* 496 */,
/* 497 */,
/* 498 */,
/* 499 */,
/* 500 */,
/* 501 */,
/* 502 */,
/* 503 */,
/* 504 */,
/* 505 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.cacheSystemInfo = exports.WX = undefined;

var _getIterator2 = __webpack_require__(205);

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _typeof2 = __webpack_require__(13);

var _typeof3 = _interopRequireDefault(_typeof2);

var _stringify = __webpack_require__(36);

var _stringify2 = _interopRequireDefault(_stringify);

var _keys = __webpack_require__(37);

var _keys2 = _interopRequireDefault(_keys);

var _assign = __webpack_require__(66);

var _assign2 = _interopRequireDefault(_assign);

var _bridge = __webpack_require__(103);

var _bridge2 = _interopRequireDefault(_bridge);

var _utils = __webpack_require__(79);

var _utils2 = _interopRequireDefault(_utils);

var _Animation = __webpack_require__(617);

var _Animation2 = _interopRequireDefault(_Animation);

var _createAudio = __webpack_require__(618);

var _createAudio2 = _interopRequireDefault(_createAudio);

var _createVideo = __webpack_require__(619);

var _createVideo2 = _interopRequireDefault(_createVideo);

var _map = __webpack_require__(620);

var _map2 = _interopRequireDefault(_map);

var _configFlags = __webpack_require__(213);

var _configFlags2 = _interopRequireDefault(_configFlags);

var _context = __webpack_require__(506);

var _context2 = _interopRequireDefault(_context);

var _canvas = __webpack_require__(507);

var _canvas2 = _interopRequireDefault(_canvas);

var _storage = __webpack_require__(622);

var storage = _interopRequireWildcard(_storage);

var _appContextSwitch = __webpack_require__(623);

var _appContextSwitch2 = _interopRequireDefault(_appContextSwitch);

var _SocketTask = __webpack_require__(624);

var _SocketTask2 = _interopRequireDefault(_SocketTask);

var _nextTick = __webpack_require__(508);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function addGetterForWX(apiKey) {
  WX.__defineGetter__(apiKey, function () {
    return _utils2.default.surroundByTryCatchFactory(apiObj[apiKey], 'wx.' + apiKey);
  });
}

function paramCheck(apiName, params, paramTpl) {
  var res = _utils2.default.paramCheck(params, paramTpl);
  return !res || (logErr(apiName, params, apiName + ':fail parameter error: ' + res), !1);
}

function paramCheckFail(apiName) {
  var res = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
      n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : '',
      errMsg = apiName + ':fail ' + n;
  console.error(errMsg);
  var fail = Reporter.surroundThirdByTryCatch(options.fail || emptyFn, 'at api ' + apiName + ' fail callback function'),
      complete = Reporter.surroundThirdByTryCatch(options.complete || emptyFn, 'at api ' + apiName + ' complete callback function');
  fail({
    errMsg: errMsg
  });
  complete({
    errMsg: errMsg
  });
}

function checkUrl(apiName, params) {
  // 判断当前页面是否在app.json里
  if (params.url.startsWith('/')) {
    params.url = params.url.slice(1);
  }
  var matchArr = /^(.*)\?/gi.exec(params.url);
  matchArr && (matchArr = /^(.*)\.html/gi.exec(matchArr[1]));
  return !matchArr || __wxConfig__.pages.indexOf(matchArr[1]) !== -1 || (logErr(apiName, params, apiName + ':fail url not in app.json'), !1);
}

typeof logxx === 'function' && logxx('sdk start');

var emptyFn = function emptyFn() {},
    pageData = {},
    currUrl = '',
    SDKVersion = '2.6.6',
    appRouteCallbacks = [],
    appRouteDoneCallback = [],
    pageEventFn = void 0,
    componentEventFn = void 0,
    WX = {},
    hasInvokeEnableAccelerometer = !1,
    hasInvokeEnableCompass = !1,
    accelerometerChangeFns = [],
    compassChangeFns = [],
    refreshSessionTimeHander = void 0,
    curWebViewId = void 0,
    currentClipBoardData = void 0,
    loginSourceUrl = '';

var gSystemInfo = {};
var gSocketTask = null;
var menubuttonboundingClientRect = {};

function cacheSystemInfo() {
  _bridge2.default.invokeMethod('getSystemInfo', {
    success: function success(res) {
      try {
        delete res.errMsg;
        res.platform = _utils2.default.getPlatform();
        gSystemInfo = res;
      } catch (e) {}
    }
  });
}

function cacheMenuButtonBoundingClientRect() {
  _bridge2.default.invokeMethod('getMenuButtonBoundingClientRect', {
    success: function success(res) {
      try {
        menubuttonboundingClientRect = res;
      } catch (e) {}
    }
  });
}

cacheSystemInfo();
cacheMenuButtonBoundingClientRect();

_bridge2.default.subscribe('SPECIAL_PAGE_EVENT', function (params) {
  var data = params.data,
      eventName = params.eventName,
      ext = params.ext,
      webViewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  if (data && data.type == 'input' && typeof pageEventFn === 'function') {
    var res = pageEventFn({
      data: data,
      eventName: eventName,
      webviewId: webViewId
    }),
        value = data.detail.value;
    if (ext && ext.setKeyboardValue) {
      if (res === undefined) {} else if (_utils2.default.getDataType(res) === 'Object') {
        var params = {};
        value != res.value && (params.value = res.value + '');
        isNaN(parseInt(res.cursor)) || (params.cursor = parseInt(res.cursor));
        _bridge2.default.publish('setKeyboardValue', params, [webViewId]);
      } else {
        value != res && _bridge2.default.publish('setKeyboardValue', {
          value: res + '',
          cursor: -1
        }, [webViewId]);
      }
    }
  }
});

var logErr = function logErr(apiName) {
  var options = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
      errMsg = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : '';
  console.error(errMsg);
  Reporter.triggerErrorMessage(errMsg);
  var fail = Reporter.surroundThirdByTryCatch(options.fail || emptyFn, 'at api ' + apiName + ' fail callback function'),
      complete = Reporter.surroundThirdByTryCatch(options.complete || emptyFn, 'at api ' + apiName + ' complete callback function');
  fail({
    errMsg: errMsg
  });
  complete({
    errMsg: errMsg
  });
};
var userAgent = window.navigator.userAgent;
var isAndroid = userAgent.indexOf('Android') != -1;
var isIOS = !isAndroid;
var webSocketList = [];
var apiObj = {
  // wx对象
  platform: function platform() {
    return isIOS ? 'finchat-ios' : 'finchat-android';
  },
  invoke: _bridge2.default.invoke,
  on: _bridge2.default.on,
  nextTick: _nextTick.nextTick,
  drawCanvas: _canvas2.default.drawCanvas,
  createContext: _canvas2.default.createContext,
  createCanvasContext: _canvas2.default.createCanvasContext,
  canvasToTempFilePath: _canvas2.default.canvasToTempFilePath,
  reportIDKey: function reportIDKey(e, t) {},
  reportKeyValue: function reportKeyValue(e, t) {},
  onPullDownRefresh: function onPullDownRefresh(e) {
    console.log('onPullDownRefresh has been removed from api list');
  },
  setNavigationBarColor: function setNavigationBarColor() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    if (paramCheck('setNavigationBarColor', params, {
      frontColor: '',
      backgroundColor: ''
    })) {
      if (['#ffffff', '#000000'].indexOf(params.frontColor) === -1) {
        logErr('setNavigationBarColor', params, 'invalid frontColor "' + params.frontColor + '"');
      }

      params.frontColor === '#ffffff' ? _bridge2.default.invokeMethod('setStatusBarStyle', {
        color: 'white'
      }) : params.frontColor === '#000000' && _bridge2.default.invokeMethod('setStatusBarStyle', {
        color: 'black'
      });

      var t = (0, _assign2.default)({}, params);
      delete t.alpha;
      _bridge2.default.invokeMethod('setNavigationBarColor', t);
    }
  },
  setNavigationBarTitle: function setNavigationBarTitle() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('setNavigationBarTitle', params, {
      title: ''
    }) && _bridge2.default.invokeMethod('setNavigationBarTitle', params);
  },
  showNavigationBarLoading: function showNavigationBarLoading(e) {
    _bridge2.default.invokeMethod('showNavigationBarLoading', e);
  },
  hideNavigationBarLoading: function hideNavigationBarLoading(e) {
    _bridge2.default.invokeMethod('hideNavigationBarLoading', e);
  },
  stopPullDownRefresh: function stopPullDownRefresh(e) {
    _bridge2.default.invokeMethod('stopPullDownRefresh', e);
  },
  setBackgroundColor: function setBackgroundColor(e) {
    _bridge2.default.invokeMethod('setBackgroundColor', e);
  },
  setBackgroundTextStyle: function setBackgroundTextStyle(e) {
    _bridge2.default.invokeMethod('setBackgroundTextStyle', e);
  },
  redirectTo: function redirectTo(params) {
    arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    if (paramCheck('redirectTo', params, {
      url: ''
    })) {
      params.url = _utils2.default.getRealRoute(currUrl, params.url);
      params.url = _utils2.default.encodeUrlQuery(params.url);
      checkUrl('redirectTo', params) && _bridge2.default.invokeMethod('redirectTo', params, {
        afterSuccess: function afterSuccess() {
          currUrl = params.url;
        }
      });
    }
  },
  // 关闭所有页面，打开到应用内的某个页面
  reLaunch: function reLaunch(params) {
    arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    if (_utils2.default.defaultRunningStatus != 'active') {
      return paramCheckFail('reLaunch', params, 'can not invoke reLaunch in background');
    }
    if (paramCheck('reLaunch', params, {
      url: ''
    })) {
      params.url = _utils2.default.getRealRoute(currUrl, params.url);
      params.url = _utils2.default.encodeUrlQuery(params.url);
      checkUrl('reLaunch', params) && _bridge2.default.invokeMethod('reLaunch', params, {
        afterSuccess: function afterSuccess() {
          currUrl = params.url;
        },
        afterFail: function afterFail() {}
      });
    }
  },
  createSelectorQuery: function createSelectorQuery(e) {
    // 返回一个SelectorQuery对象实例
    var t = null;
    if (e && e.page) {
      t.e.page__wxWebViewId__;
    } else {
      var n = getCurrentPages();
      t = n[n.length - 1].__wxWebviewId__;
    }
    return new _utils2.default.wxQuerySelector(t);
  },

  pageScrollTo: function pageScrollTo(param) {
    // 将页面滚动到目标位置
    var target = getCurrentPages(),
        viewId = target[target.length - 1].__wxWebviewId__;
    if (param.hasOwnProperty('page') && param.page.hasOwnProperty('__wxWebviewId__')) {
      viewId = param.page.__wxWebviewId__;
    }

    _bridge2.default.invokeMethod('pageScrollTo', param, [viewId]);
  },

  navigateTo: function navigateTo(params) {
    arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    if (paramCheck('navigateTo', params, {
      url: ''
    })) {
      params.url = _utils2.default.getRealRoute(currUrl, params.url);
      params.url = _utils2.default.encodeUrlQuery(params.url);
      checkUrl('navigateTo', params) && _bridge2.default.invokeMethod('navigateTo', params, {
        afterSuccess: function afterSuccess() {
          currUrl = params.url;
          _context2.default.notifyCurrentRoutetoContext(currUrl);
        }
      });
    }
  },
  switchTab: function switchTab() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    if (paramCheck('switchTab', params, {
      url: ''
    })) {
      ;
      /\?.*$/.test(params.url) && (console.warn('wx.switchTab: url 不支持 queryString'), params.url = params.url.replace(/\?.*$/, ''));
      params.url = _utils2.default.getRealRoute(currUrl, params.url);
      params.url = _utils2.default.encodeUrlQuery(params.url);
      checkUrl('switchTab', params) && _bridge2.default.invokeMethod('switchTab', params, {
        afterSuccess: function afterSuccess() {
          currUrl = params.url;
          _context2.default.notifyCurrentRoutetoContext(currUrl);
        }
      });
    }
  },
  navigateBack: function navigateBack() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    if (typeof params.delta !== 'number') {
      params.delta = 1;
    } else {
      params.delta = parseInt(params.delta);
      params.delta < 1 && (params.delta = 1);
    }
    _bridge2.default.invokeMethod('navigateBack', params);
  },
  getStorage: function getStorage(params) {
    if (paramCheck('getStorage', params, {
      key: ''
    })) {
      storage.getStorage(params);
    }
  },
  getStorageSync: function getStorageSync(key) {
    if (paramCheck('getStorageSync', key, '')) {
      var rt = storage.get(key);
      return rt && rt.data || '';
    }
  },
  setStorage: function setStorage(params) {
    if (paramCheck('setStorage', params, {
      key: ''
    })) {
      storage.setStorage(params);
    }
  },
  setStorageSync: function setStorageSync(key, value) {
    value = value || '';
    if (paramCheck('setStorageSync', key, '')) {
      storage.set(key, value);
    }
  },
  removeStorage: function removeStorage(params) {
    paramCheck('removeStorage', params, {
      key: ''
    }) && storage.removeStorage(params);
  },
  removeStorageSync: function removeStorageSync(key) {
    paramCheck('removeStorageSync', key, '') && storage.remove(key);
  },
  clearStorage: function clearStorage() {
    storage.clearStorage();
  },
  clearStorageSync: function clearStorageSync() {
    storage.clearStorage();
  },
  getStorageInfo: function getStorageInfo(params) {
    storage.getStorageInfo(params);
  },
  getStorageInfoSync: function getStorageInfoSync() {
    var rt = storage.getStorageInfoSync();
    return rt;
  },
  request: function request() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    if (paramCheck('request', params, {
      url: ''
    })) {
      if (_utils2.default.validateUrl(params.url) === !1) {
        return logErr('request', params, 'request:fail invalid url "' + params.url + '"');
      }
      if (params.data === 'function') {
        return logErr('request', params, 'request:fail data should not be Function');
      }
      var headerType = _utils2.default.getDataType(params.header);
      params.header = params.header || {};
      params.header = _utils2.default.convertObjectValueToString(params.header);
      headerType !== 'Undefined' && headerType !== 'Object' && (console.warn('wx.request: header must be an object'), params.header = {});
      params.header = (0, _keys2.default)(params.header).reduce(function (res, cur) {
        cur.toLowerCase() === 'content-type' ? res[cur.toLowerCase()] = params.header[cur] : res[cur] = params.header[cur];
        return res;
      }, {});
      params.method && (params.method = params.method.toUpperCase());
      var headers = params.header || {},
          requestMethod = 'GET';
      typeof params.method === 'string' && (requestMethod = params.method.toUpperCase());
      var data;
      params.dataType = params.dataType || 'json';
      headers['content-type'] = headers['content-type'] || 'application/json';
      // data = !params.data
      //   ? ''
      //   : typeof params.data !== 'string'
      //     ? headers['content-type'].indexOf(
      //         'application/x-www-form-urlencoded'
      //       ) > -1
      //       ? utils.urlEncodeFormData(params.data, !0)
      //       : headers['content-type'].indexOf('application/json') > -1
      //         ? JSON.stringify(params.data)
      //         : typeof params.data === 'object'
      //           ? JSON.stringify(params.data)
      //           : data.toString()
      //     : params.data
      data = !params.data ? '' : typeof params.data !== 'string' ? (0, _stringify2.default)(params.data) : params.data;
      requestMethod == 'GET' && (params.url = _utils2.default.addQueryStringToUrl(params.url, params.data));
      console.log('service api request: ', headers);
      _bridge2.default.invokeMethod('request', {
        url: params.url,
        data: data,
        header: headers,
        method: requestMethod,
        success: params.success,
        fail: params.fail,
        complete: params.complete
      }, {
        beforeSuccess: function beforeSuccess(res) {
          if (params.dataType === 'json') {
            try {
              res.data = JSON.parse(res.data);
            } catch (e) {}
          }
          res.statusCode = parseInt(res.statusCode);
        }
      });
    }
  },
  base64ToArrayBuffer: function base64ToArrayBuffer(str) {
    return _utils2.default.base64ToArrayBuffer(str);
  },
  arrayBufferToBase64: function arrayBufferToBase64(buffer) {
    return _utils2.default.arrayBufferToBase64(buffer);
  },
  connectSocket: function connectSocket(params) {
    if (webSocketList.filter(function (e) {
      return e.readyState === 1;
    }).length >= 2) {
      console.error('同时最多发起 2 个 socket 请求');
      webSocketList[1].onErrorCallback({
        errMsg: 'exceed max task count'
      });
      var error = new Error('exceed max task count');
      error.type = 'ConnectSocketError';
      throw error;
    }
    if (paramCheck('connectSocket', params, {
      url: ''
    })) {
      if ((0, _typeof3.default)(params.header) !== 'object' && typeof params.header !== 'undefined') {
        console.warn('connectSocket: header must be an object');
        delete params.header;
      }
      var header = {};
      if (params.header) {
        header = _utils2.default.convertObjectValueToString(params.header);
        params.header = header;
      }
      var socket = void 0;
      socket = new _SocketTask2.default(params);
      gSocketTask = socket;
      webSocketList.push(socket);
      // res(socket)
      return socket;
    }
  },
  closeSocket: function closeSocket(e) {
    if (gSocketTask) {
      gSocketTask.close();
      gSocketTask = null;
    }
  },
  sendSocketMessage: function sendSocketMessage(params) {
    if (gSocketTask && gSocketTask.readyState === 1) {
      gSocketTask.send(params);
    } else {
      console.error('sendSocketMessage:fail WebSocket is not connected');
    }
  },
  onSocketOpen: function onSocketOpen(callback) {
    if (gSocketTask) {
      gSocketTask.onOpen(callback);
    }
  },
  onSocketClose: function onSocketClose(callback) {
    if (gSocketTask) {
      gSocketTask.onClose(callback);
    }
  },
  onSocketMessage: function onSocketMessage(callback) {
    if (paramCheck('onSocketMessage', callback, emptyFn)) {

      callback = Reporter.surroundThirdByTryCatch(callback, 'at onSocketMessage callback function');
      if (gSocketTask) {
        gSocketTask.onMessage(callback);
      }

      // bridge.onMethod('onSocketMessage', function (params) {
      //   utils.getPlatform() !== 'devtools' &&
      //     params.isBuffer === !0 &&
      //     (params.data = utils.base64ToArrayBuffer(params.data))
      //   delete params.isBuffer
      //   utils.getPlatform() === 'devtools' &&
      //   utils.getDataType(params.data) === 'Blob'
      //     ? utils.blobToArrayBuffer(params.data, function (data) {
      //       ;(params.data = data), callback(params)
      //     })
      //     : callback(params)
      // })
    }
  },
  onSocketError: function onSocketError(callback) {
    if (gSocketTask) {
      gSocketTask.onError(callback);
    }
    // bridge.onMethod(
    //   'onSocketError',
    //   Reporter.surroundThirdByTryCatch(
    //     callback,
    //     'at onSocketError callback function'
    //   )
    // )
  },
  uploadFile: function uploadFile(params) {
    if (paramCheck('uploadFile', params, {
      url: '',
      filePath: '',
      name: ''
    })) {
      (0, _typeof3.default)(params.header) !== 'object' && typeof params.header !== 'undefined' && (console.warn('uploadFile: header must be an object'), delete params.header), (0, _typeof3.default)(params.formData) !== 'object' && typeof params.formData !== 'undefined' && (console.warn('uploadFile: formData must be an object'), delete params.formData);
      var header = {},
          formData = {};
      params.header && (header = _utils2.default.convertObjectValueToString(params.header));
      params.formData && (formData = _utils2.default.convertObjectValueToString(params.formData));
      _bridge2.default.invokeMethod('uploadFile', _utils2.default.assign({}, params, {
        header: header,
        formData: formData
      }), {
        beforeSuccess: function beforeSuccess(res) {
          res.statusCode = parseInt(res.statusCode);
        }
      });
    }
  },
  downloadFile: function downloadFile(params) {
    paramCheck('downloadFile', params, {
      url: ''
    }) && _bridge2.default.invokeMethod('downloadFile', params, {
      beforeSuccess: function beforeSuccess(res) {
        res.statusCode = parseInt(res.statusCode);
        var statusArr = [200, 304];
        statusArr.indexOf(res.statusCode) === -1 && delete res.tempFilePath;
      }
    });
  },
  chooseImage: function chooseImage() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    _bridge2.default.invokeMethod('chooseImage', _utils2.default.assign({
      count: 9,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera']
    }, params));
  },
  previewImage: function previewImage(params) {
    paramCheck('previewImage', params, {
      urls: ['']
    }) && _bridge2.default.invokeMethod('previewImage', params);
  },
  getImageInfo: function getImageInfo(params) {
    paramCheck('getImageInfo', params, {
      src: ''
    }) && (/^(http|https):\/\//.test(params.src) ? _bridge2.default.invokeMethod('downloadFile', {
      url: params.src
    }, {
      afterSuccess: function afterSuccess(res) {
        params.src = res.tempFilePath;
        _bridge2.default.invokeMethod('getImageInfo', params, {
          beforeSuccess: function beforeSuccess(rt) {
            rt.path = params.src;
          }
        });
      },
      afterFail: function afterFail() {
        logErr('getImageInfo', params, 'getImageInfo:fail download image fail');
      }
    }) : /^(wdfile|finfile):\/\//.test(params.src) ? _bridge2.default.invokeMethod('getImageInfo', params, {
      beforeSuccess: function beforeSuccess(rt) {
        rt.path = params.src;
      }
    }) : (params.src = _utils2.default.getRealRoute(currUrl, params.src, !1), _bridge2.default.invokeMethod('getImageInfo', params, {
      beforeSuccess: function beforeSuccess(rt) {
        rt.path = params.src;
      }
    })));
  },
  chooseVideo: function chooseVideo(params) {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    _bridge2.default.invokeMethod('chooseVideo', _utils2.default.assign({
      sourceType: ['album', 'camera'],
      compressed: true,
      maxDuration: 60,
      camera: 'back'
    }, params));
  },
  previewVideo: function previewVideo(params) {
    paramCheck('previewVideo', params, {
      url: '',
      autoplay: false
    }) && _bridge2.default.invokeMethod('previewVideo', params);
  },
  startRecord: function startRecord(params) {
    ;
    apiObj.appStatus === _configFlags2.default.AppStatus.BACK_GROUND && apiObj.hanged === !1 || _bridge2.default.invokeMethod('startRecord', params);
  },
  stopRecord: function stopRecord(params) {
    _bridge2.default.invokeMethod('stopRecord', params);
  },
  playVoice: function playVoice(params) {
    paramCheck('playVoice', params, {
      filePath: ''
    }) && _bridge2.default.invokeMethod('playVoice', params);
  },
  pauseVoice: function pauseVoice(e) {
    _bridge2.default.invokeMethod('pauseVoice', e);
  },
  stopVoice: function stopVoice(e) {
    _bridge2.default.invokeMethod('stopVoice', e);
  },
  onVoicePlayEnd: function onVoicePlayEnd(callback) {
    _bridge2.default.onMethod('onVoicePlayEnd', Reporter.surroundThirdByTryCatch(callback, 'at onVoicePlayEnd callback function'));
  },
  getLocation: function getLocation(params) {
    ;
    apiObj.appStatus === _configFlags2.default.AppStatus.BACK_GROUND && apiObj.hanged === !1 || _bridge2.default.invokeMethod('getLocation', params);
  },
  openLocation: function openLocation() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('openLocation', params, {
      latitude: 0.1,
      longitude: 0.1
    }) && _bridge2.default.invokeMethod('openLocation', params);
  },
  chooseLocation: function chooseLocation() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    _bridge2.default.invokeMethod('chooseLocation', params);
  },
  getNetworkType: function getNetworkType(params) {
    _bridge2.default.invokeMethod('getNetworkType', params);
  },
  getSystemInfo: function getSystemInfo(params) {
    var platform = _utils2.default.getPlatform();
    _bridge2.default.invokeMethod('getSystemInfo', params, {
      beforeSuccess: function beforeSuccess(rt) {
        delete rt.errMsg;
        rt.platform = platform;
        gSystemInfo = rt;
      }
    });
  },
  getSystemInfoSync: function getSystemInfoSync() {
    // 采用预计算方法
    return gSystemInfo;
  },
  onAccelerometerChange: function onAccelerometerChange(callback) {
    hasInvokeEnableAccelerometer || (_bridge2.default.invokeMethod('enableAccelerometer', {
      enable: !0
    }), hasInvokeEnableAccelerometer = !0);
    accelerometerChangeFns.push(Reporter.surroundThirdByTryCatch(callback, 'at onAccelerometerChange callback function'));
  },
  onCompassChange: function onCompassChange(callback) {
    hasInvokeEnableCompass || (_bridge2.default.invokeMethod('enableCompass', {
      enable: !0
    }), hasInvokeEnableCompass = !0);
    compassChangeFns.push(Reporter.surroundThirdByTryCatch(callback, 'at onCompassChange callback function'));
  },
  reportAction: function reportAction(params) {
    _bridge2.default.invokeMethod('reportAction', params);
  },
  getBackgroundAudioPlayerState: function getBackgroundAudioPlayerState(params) {
    _bridge2.default.invokeMethod('getMusicPlayerState', params, {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('getBackgroundAudioPlayerState', 'getMusicPlayerState');
      }
    });
  },
  playBackgroundAudio: function playBackgroundAudio() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    apiObj.appStatus === _configFlags2.default.AppStatus.BACK_GROUND && apiObj.hanged === !1 || _bridge2.default.invokeMethod('operateMusicPlayer', _utils2.default.assign({
      operationType: 'play'
    }, params), {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('operateMusicPlayer', 'playBackgroundAudio');
      }
    });
  },
  pauseBackgroundAudio: function pauseBackgroundAudio() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    _bridge2.default.invokeMethod('operateMusicPlayer', _utils2.default.assign({
      operationType: 'pause'
    }, params), {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('operateMusicPlayer', 'pauseBackgroundAudio');
      }
    });
  },
  seekBackgroundAudio: function seekBackgroundAudio() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('seekBackgroundAudio', params, {
      position: 1
    }) && _bridge2.default.invokeMethod('operateMusicPlayer', _utils2.default.assign({
      operationType: 'seek'
    }, params), {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('operateMusicPlayer', 'seekBackgroundAudio');
      }
    });
  },
  stopBackgroundAudio: function stopBackgroundAudio() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    _bridge2.default.invokeMethod('operateMusicPlayer', _utils2.default.assign({
      operationType: 'stop'
    }, params), {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('operateMusicPlayer', 'stopBackgroundAudio');
      }
    });
  },
  onBackgroundAudioPlay: function onBackgroundAudioPlay(callback) {
    _bridge2.default.onMethod('onMusicPlay', Reporter.surroundThirdByTryCatch(callback, 'at onBackgroundAudioPlay callback function'));
  },
  onBackgroundAudioPause: function onBackgroundAudioPause(callback) {
    _bridge2.default.onMethod('onMusicPause', Reporter.surroundThirdByTryCatch(callback, 'at onBackgroundAudioPause callback function'));
  },
  onBackgroundAudioStop: function onBackgroundAudioStop(callback) {
    _bridge2.default.onMethod('onMusicEnd', Reporter.surroundThirdByTryCatch(callback, 'at onBackgroundAudioStop callback function'));
  },
  login: function login(params) {
    if (__wxConfig__ && __wxConfig__.weweb && __wxConfig__.weweb.loginUrl) {
      // 引导到自定义的登录页面
      if (__wxConfig__.weweb.loginUrl.indexOf('/') != 0) {
        __wxConfig__.weweb.loginUrl = '/' + __wxConfig__.weweb.loginUrl;
      }
      var curPages = getCurrentPages();

      loginSourceUrl = curPages[curPages.length - 1].__route__;
      apiObj.redirectTo({
        url: __wxConfig__.weweb.loginUrl
      });
    } else {
      _bridge2.default.invokeMethod('login', params);
    }
  },
  loginSuccess: function loginSuccess() {
    var url = loginSourceUrl && loginSourceUrl != __wxConfig__.weweb.loginUrl && (loginSourceUrl.indexOf('/') === 0 ? loginSourceUrl : '/' + loginSourceUrl) || '/' + __root__;
    loginSourceUrl = '';

    apiObj.redirectTo({
      url: url
    });
  },
  checkLogin: function checkLogin(params) {
    _bridge2.default.invokeMethod('checkLogin', params);
  },
  checkSession: function checkSession(params) {
    refreshSessionTimeHander && clearTimeout(refreshSessionTimeHander);
    _bridge2.default.invokeMethod('refreshSession', params, {
      beforeSuccess: function beforeSuccess(res) {
        refreshSessionTimeHander = setTimeout(function () {
          _bridge2.default.invokeMethod('refreshSession');
        }, 1e3 * res.expireIn);
        delete res.err_code;
        delete res.expireIn;
      },
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('refreshSession', 'checkSession');
      }
    });
  },
  authorize: function authorize(params) {
    _bridge2.default.invokeMethod('authorize', params);
  },
  canIUse: function canIUse(params) {
    _bridge2.default.invokeMethod('operateWXData', _utils2.default.assign({
      data: {
        api_name: 'webapi_caniuse',
        data: params.data || {}
      }
    }, params), {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('operateWXData', 'canIUse');
      },
      beforeSuccess: function beforeSuccess(res) {
        try {
          res.useable = res.data.useable;
          delete res.data;
        } catch (e) {}
      }
    });
  },
  scanVehicle: function scanVehicle(params) {
    _bridge2.default.invokeMethod('scanVehicle', params || {}, {
      beforeAll: function beforeAll(res) {},
      beforeSuccess: function beforeSuccess(res) {}
    });
  },
  base64ToTempFilePath: function base64ToTempFilePath(params) {
    _bridge2.default.invokeMethod('base64ToTempFilePath', params || {}, {
      beforeAll: function beforeAll(res) {},
      beforeSuccess: function beforeSuccess(res) {}
    });
  },
  getSetting: function getSetting(params) {
    _bridge2.default.invokeMethod('operateWXData', _utils2.default.assign({
      data: {
        api_name: 'webapi_getsetting',
        data: params.data || {}
      }
    }, params), {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('operateWXData', 'getSetting');
      },
      beforeSuccess: function beforeSuccess(res) {
        try {
          res.authSetting = res.data.authSetting;
          delete res.data;
        } catch (e) {
          console.log(e);
        }
      }
    });
  },
  getUserInfo: function getUserInfo(params) {
    _bridge2.default.invokeMethod('operateWXData', _utils2.default.assign({
      data: {
        api_name: 'webapi_getuserinfo',
        data: params.data || {}
      }
    }, params), {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('operateWXData', 'getUserInfo');
      },
      beforeSuccess: function beforeSuccess(res) {
        // "android" ===  utils.getPlatform() && (res.data = JSON.parse(res.data))
        res.rawData = res.data.rawData;
        try {
          res.userInfo = res.data.userInfo;
          res.signature = res.data.signature;
          res.data.encryptData && (console.group(new Date() + ' encryptData 字段即将废除'), console.warn('请使用 encryptedData 和 iv 字段进行解密，详见：https://mp.weixin.qq.com/debug/wxadoc/dev/api/open.html'), console.groupEnd(), res.encryptData = res.data.encryptData);
          res.data.encryptedData && (res.encryptedData = res.data.encryptedData, res.iv = res.data.iv);
          delete res.data;
        } catch (e) {}
      }
    });
  },
  navigateToMiniProgram: function navigateToMiniProgram(params) {
    paramCheck('navigateToMiniProgram', params, {
      appId: ''
    }) && _bridge2.default.invokeMethod('navigateToMiniProgram', params);
  },
  navigateBackMiniProgram: function navigateBackMiniProgram(params) {
    _bridge2.default.invokeMethod('navigateBackMiniProgram', params);
  },
  getFriends: function getFriends(params) {
    _bridge2.default.invokeMethod('operateWXData', {
      data: {
        api_name: 'webapi_getfriends',
        data: params.data || {}
      },
      success: params.success,
      fail: params.fail,
      complete: params.complete
    }, {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('operateWXData', 'getFriends');
      },
      beforeSuccess: function beforeSuccess(res) {
        // "android" ===  utils.getPlatform() && (res.data = JSON.parse(res.data))
        res.rawData = res.data.data;
        try {
          res.friends = JSON.parse(res.data.data);
          res.signature = res.data.signature;
          delete res.data;
        } catch (e) {}
      }
    });
  },
  requestPayment: function requestPayment(params) {
    paramCheck('requestPayment', params, {
      timeStamp: '',
      nonceStr: '',
      package: '',
      signType: '',
      paySign: ''
    }) && _bridge2.default.invokeMethod('requestPayment', params);
  },
  verifyPaymentPassword: function verifyPaymentPassword(params) {
    _bridge2.default.invokeMethod('verifyPaymentPassword', params);
  },
  bindPaymentCard: function bindPaymentCard(params) {
    _bridge2.default.invokeMethod('bindPaymentCard', params);
  },
  requestPaymentToBank: function requestPaymentToBank(params) {
    _bridge2.default.invokeMethod('requestPaymentToBank', params);
  },
  addCard: function addCard(params) {
    paramCheck('addCard', params, {
      cardList: []
    }) && _bridge2.default.invokeMethod('addCard', params);
  },
  openCard: function openCard(params) {
    paramCheck('openCard', params, {
      cardList: []
    }) && _bridge2.default.invokeMethod('openCard', params);
  },
  scanCode: function scanCode() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('scanCode', params, {}) && _bridge2.default.invokeMethod('scanCode', params, {
      beforeSuccess: function beforeSuccess(res) {
        typeof res.path === 'string' && (res.path = res.path.replace(/\.html$/, ''), res.path = res.path.replace(/\.html\?/, '?'));
      }
    });
  },
  openAddress: function openAddress(params) {
    _bridge2.default.invokeMethod('openAddress', params);
  },
  saveFile: function saveFile(params) {
    paramCheck('saveFile', params, {
      tempFilePath: ''
    }) && _bridge2.default.invokeMethod('saveFile', params);
  },
  openDocument: function openDocument(params) {
    paramCheck('openDocument', params, {
      filePath: ''
    }) && _bridge2.default.invokeMethod('openDocument', params);
  },
  chooseContact: function chooseContact(params) {
    _bridge2.default.invokeMethod('chooseContact', params);
  },
  makePhoneCall: function makePhoneCall() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('makePhoneCall', params, {
      phoneNumber: ''
    }) && _bridge2.default.invokeMethod('makePhoneCall', params);
  },
  onAppRoute: function onAppRoute(params, t) {
    appRouteCallbacks.push(params);
  },
  onAppRouteDone: function onAppRouteDone(params, t) {
    appRouteDoneCallback.push(params);
  },
  onAppEnterBackground: function onAppEnterBackground(params) {
    _appContextSwitch2.default.onAppEnterBackground.call(apiObj, params);
  },
  onAppEnterForeground: function onAppEnterForeground(params) {
    _appContextSwitch2.default.onAppEnterForeground.call(apiObj, params);
  },
  onAppRunningStatusChange: function onAppRunningStatusChange(params) {
    _appContextSwitch2.default.onAppRunningStatusChange.call(apiObj, params);
  },
  setAppData: function setAppData(data) {
    var options = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
        webviewIds = arguments[2];
    arguments[3];
    options.forceUpdate = typeof options.forceUpdate !== 'undefined' && options.forceUpdate;
    if (_utils2.default.isObject(data) === !1) {
      throw new _utils2.default.AppServiceSdkKnownError('setAppData:data should be an object');
    }!function () {
      var hasUpdate = !1,
          tmpData = {},
          setCurData = function setCurData(key, value, type) {
        hasUpdate = !0;
        tmpData[key] = value;
        type === 'Array' || type === 'Object' ? pageData[key] = JSON.parse((0, _stringify2.default)(value)) : pageData[key] = value;
      };
      for (var oKey in data) {
        var curValue = data[oKey],
            gValue = pageData[oKey],
            gValueType = _utils2.default.getDataType(gValue),
            curValueType = _utils2.default.getDataType(curValue);
        gValueType !== curValueType ? setCurData(oKey, curValue, curValueType) : gValueType == 'Array' || gValueType == 'Object' ? (0, _stringify2.default)(gValue) !== (0, _stringify2.default)(curValue) && setCurData(oKey, curValue, curValueType) : gValueType == 'String' || gValueType == 'Number' || gValueType == 'Boolean' ? gValue.toString() !== curValue.toString() && setCurData(oKey, curValue, curValueType) : gValueType == 'Date' ? gValue.getTime().toString() !== curValue.getTime().toString() && setCurData(oKey, curValue, curValueType) : gValue !== curValue && setCurData(oKey, curValue, curValueType);
      }
      options.forceUpdate ? _bridge2.default.publish('appDataChange', {
        data: data,
        option: {
          timestamp: Date.now(),
          forceUpdate: !0
        }
      }, webviewIds) : hasUpdate && _bridge2.default.publish('appDataChange', {
        data: tmpData
      }, webviewIds);
    }();
  },
  onPageEvent: function onPageEvent(e, t) {
    console.warn("'onPageEvent' is deprecated, use 'Page[eventName]'");
  },
  createAnimation: function createAnimation() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    if (paramCheck('createAnimation', params, {})) return new _Animation2.default(params);
  },
  createAudioContext: function createAudioContext(audioId) {
    return _createAudio2.default.call(apiObj, audioId, curWebViewId);
  },
  createVideoContext: function createVideoContext(videoId) {
    return _createVideo2.default.call(apiObj, videoId, curWebViewId);
  },
  createMapContext: function createMapContext(e) {
    return new _map2.default.MapContext(e);
  },
  onComponentEvent: function onComponentEvent(fn, t) {
    componentEventFn = fn;
    _bridge2.default.subscribe('COMPONENT_EVENT', function (params) {
      var data = params.data,
          eventName = params.eventName,
          webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
      fn({
        data: data,
        eventName: eventName,
        webviewId: webviewId
      });
    });
  },
  onWebviewEvent: function onWebviewEvent(fn, t) {
    pageEventFn = fn;
    _bridge2.default.subscribe('PAGE_EVENT', function (params) {
      var data = params.data,
          eventName = params.eventName,
          webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
      fn({
        data: data,
        eventName: eventName,
        webviewId: webviewId
      });
    });
  },
  onNativeEvent: function onNativeEvent(fn) {
    ;
    ['onCanvasTouchStart', 'onCanvasTouchMove', 'onCanvasTouchEnd'].forEach(function (key) {
      _bridge2.default.onMethod(key, function (data, webviewId) {
        fn({
          data: data,
          eventName: key,
          webviewId: webviewId
        });
      });
    });
  },
  hideKeyboard: function hideKeyboard(params) {
    // bridge.publish('hideKeyboard', {}) // "devtools" ==  utils.getPlatform() ? bridge.publish("hideKeyboard", {}) :  bridge.invokeMethod("hideKeyboard", params)
    _bridge2.default.invokeMethod('hideKeyboard', params);
  },
  getPublicLibVersion: function getPublicLibVersion() {
    var rt;
    _bridge2.default.invokeMethod('getPublicLibVersion', {
      complete: function complete(res) {
        res.version ? rt = res.version : (rt = res, delete rt.errMsg);
      }
    });
    return rt;
  },
  showModal: function showModal() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        options = {
      title: '',
      content: '',
      confirmText: '确定',
      cancelText: '取消',
      showCancel: !0,
      confirmColor: '#3CC51F',
      cancelColor: '#000000'
    };
    options = _utils2.default.extend(options, params);
    if (paramCheck('showModal', options, {
      title: '',
      content: '',
      confirmText: '',
      cancelText: '',
      confirmColor: '',
      cancelColor: ''
    })) {
      return options.confirmText.length > 4 ? void logErr('showModal', params, 'showModal:fail confirmText length should not large then 4') : options.cancelText.length > 4 ? void logErr('showModal', params, 'showModal:fail cancelText length should not large then 4') : _bridge2.default.invokeMethod('showModal', options, {
        beforeSuccess: function beforeSuccess(rt) {
          rt.confirm = Boolean(rt.confirm);
        }
      });
    }
  },
  showToast: function showToast() {
    var params = arguments[0] || {};
    var options = {
      duration: 1500,
      title: '',
      icon: 'success',
      mask: false
    };
    options = _utils2.default.extend(options, params);
    // delete options.image
    if (['success', 'loading', 'none'].indexOf(options.icon) < 0) {
      options.icon = 'success';
    }
    if (options.duration > 10000) {
      options.duration = 10000;
    }
    var v = paramCheck('showToast', options, {
      duration: 1,
      title: '',
      icon: ''
    });
    if (v) {
      _bridge2.default.invokeMethod('showToast', options);
    }
  },
  hideToast: function hideToast(e) {
    _bridge2.default.invokeMethod('hideToast', e);
  },
  showLoading: function showLoading() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        defaultArgs = {
      title: '',
      mask: !1
    };
    defaultArgs = _utils2.default.extend(defaultArgs, params);
    paramCheck('showLoading', defaultArgs, {
      mask: false,
      title: ''
    }) && _bridge2.default.invokeMethod('showLoading', defaultArgs);
  },
  hideLoading: function hideLoading(args) {
    _bridge2.default.invokeMethod('hideLoading', args);
  },
  showActionSheet: function showActionSheet() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        options = {
      itemList: [],
      itemColor: '#000000'
    };
    options = _utils2.default.extend(options, params);
    options.cancelText = '取消';
    options.cancelColor = '#000000';
    if (paramCheck('showActionSheet', options, {
      itemList: ['1'],
      itemColor: ''
    })) {
      return params.itemList.length > 6 ? void logErr('showActionSheet', params, 'showActionSheet:fail parameter error: itemList should not be large than 6') : _bridge2.default.invokeMethod('showActionSheet', options, {
        beforeCancel: function beforeCancel(t) {
          try {
            typeof params.success === 'function' && params.success({
              errMsg: 'showActionSheet:ok',
              cancel: !0
            });
          } catch (e) {
            Reporter.thirdErrorReport({
              error: e,
              extend: 'showActionSheet success callback error'
            });
          }
        }
      });
    }
  },
  getSavedFileList: function getSavedFileList() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    _bridge2.default.invokeMethod('getSavedFileList', params);
  },
  getSavedFileInfo: function getSavedFileInfo() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('getSavedFileInfo', params, {
      filePath: ''
    }) && _bridge2.default.invokeMethod('getSavedFileInfo', params);
  },
  getFileInfo: function getFileInfo() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    if (_bridge2.default.beforeInvoke('getFileInfo', params, {
      filePath: ''
    })) {
      if (void 0 !== params.digestAlgorithm) {
        var res = _utils2.default.paramCheck(params, {
          digestAlgorithm: ''
        });
        if (res) {
          _bridge2.default.beforeInvokeFail('getFileInfo', params, 'parameter error: ' + res);
        }
        if (['md5', 'sha1'].indexOf(params.digestAlgorithm) === -1) {
          _bridge2.default.beforeInvokeFail('getFileInfo', params, 'parameter error: invalid digestAlgorithm "' + params.digestAlgorithm + '"');
        }
      }
      _bridge2.default.invokeMethod('getFileInfo', params, {});
    }
  },
  removeSavedFile: function removeSavedFile() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('removeSavedFile', params, {
      filePath: ''
    }) && _bridge2.default.invokeMethod('removeSavedFile', params);
  },
  getExtConfig: function getExtConfig() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    setTimeout(function () {
      var res = {
        errMsg: 'getExtConfig: ok',
        extConfig: (0, apiObj.getExtConfigSync)()
      };
      typeof params.success === 'function' && params.success(res);
      typeof params.complete === 'function' && params.complete(res);
    }, 0);
  },
  getClipboardData: function getClipboardData() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    _bridge2.default.invokeMethod('getClipboardData', params, {});
    // bridge.invokeMethod("getClipboardData",params,{})
  },
  setClipboardData: function setClipboardData() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('setClipboardData', params, {
      data: ''
    }) && _bridge2.default.invokeMethod('setClipboardData', params, {
      beforeSuccess: function beforeSuccess() {
        currentClipBoardData = params.data;
        apiObj.reportClipBoardData(!0);
      }
    });
  },
  reportClipBoardData: function reportClipBoardData(param) {
    if (currentClipBoardData !== '') {
      var t = getCurrentPages().find(function (e) {
        return e.__wxWebviewId__ === curWebViewId;
      }) || {},
          value = [currentClipBoardData, t.__route__, param ? 1 : 0, (0, _keys2.default)(t.options).map(function (e) {
        return encodeURIComponent(e) + '=' + encodeURIComponent(t.options[e]);
      }).join('&')].map(encodeURIComponent).join(',');
      Reporter.reportKeyValue({
        key: 'Clipboard',
        value: value,
        force: !0
      });
    }
  },
  getExtConfigSync: function getExtConfigSync() {
    if (!__wxConfig__.ext) return {};
    try {
      return JSON.parse((0, _stringify2.default)(__wxConfig__.ext));
    } catch (e) {
      return {};
    }
  },
  chooseAddress: function chooseAddress(params) {
    _bridge2.default.invokeMethod('openAddress', params, {
      beforeSuccess: function beforeSuccess(res) {
        _utils2.default.renameProperty(res, 'addressPostalCode', 'postalCode');
        _utils2.default.renameProperty(res, 'proviceFirstStageName', 'provinceName');
        _utils2.default.renameProperty(res, 'addressCitySecondStageName', 'cityName');
        _utils2.default.renameProperty(res, 'addressCountiesThirdStageName', 'countyName');
        _utils2.default.renameProperty(res, 'addressDetailInfo', 'detailInfo');
      },
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('openAddress', 'chooseAddress');
        delete res.err_msg;
      }
    });
  },
  canIuse: function canIuse() {
    var param1 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : '',
        param2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : SDKVersion;
    if (typeof param1 !== 'string') {
      throw new _utils2.default.AppServiceSdkKnownError('canIUse: schema should be an object');
    }
    var params = param1.split('.');
    return _utils2.default.canIUse(_utils2.default.toArray(params), param2);
  },
  reportLog: function reportLog(name, data) {
    _bridge2.default.publish('H5_USER_LOG', {
      event: name,
      desc: data || ''
    });
  },
  // ------------------ FinChat Api ---------------------------
  walletSignIn: function walletSignIn(params) {
    _bridge2.default.invokeMethod('walletSignIn', params || {}, {
      beforeSuccess: function beforeSuccess(res) {}
    });
  },
  nfcRead: function nfcRead(params) {
    _bridge2.default.invokeMethod('nfcRead', params || {}, {
      beforeSuccess: function beforeSuccess(res) {}
    });
  },
  finchatShare: function finchatShare(params) {
    _bridge2.default.invokeMethod('finchatShare', params || {}, {
      beforeSuccess: function beforeSuccess(res) {}
    });
  },

  getFinstoreConfig: function getFinstoreConfig(params) {
    _bridge2.default.invokeMethod('getFinstoreConfig', params || {}, {
      beforeSuccess: function beforeSuccess(res) {
        var customData = res.customData || {};
        var previewUrl = Array.isArray(customData.preview) && customData.preview[0];
        var wihteKeys = ['errMsg', 'appId', 'developerId', 'name', 'description', 'logo', 'thumbnail', 'version', 'extConfig'];
        res.description = res.coreDescription || '', res.thumbnail = previewUrl || '', res.extConfig = customData.extConfig || {}, (0, _keys2.default)(res).forEach(function (key) {
          if (wihteKeys.includes(key)) {
            return;
          }
          delete res[key];
        });
      }
    });
  },
  // --- 注入接口 start ---
  // 默认在framework声明，兼容老版本小程序
  getFinChatSession: function getFinChatSession(params) {
    _bridge2.default.invokeMethod('getFinChatSession', params || {}, {
      beforeSuccess: function beforeSuccess(res) {
        // res.session=res.data
      }
    });
  },
  shareToWechat: function shareToWechat(params) {
    _bridge2.default.invokeMethod('shareToWechat', params || {}, {
      beforeSuccess: function beforeSuccess(res) {}
    });
  },
  openRoom: function openRoom(params) {
    _bridge2.default.invokeMethod('openRoom', params || {}, {
      beforeSuccess: function beforeSuccess(res) {}
    });
  },
  getAppConfig: function getAppConfig(params) {
    _bridge2.default.invokeMethod('getAppConfig', params || {}, {
      beforeSuccess: function beforeSuccess(res) {}
    });
  },
  setTabBarBadge: function setTabBarBadge(params) {
    _bridge2.default.invokeMethod('setTabBarBadge', params || {}, {
      beforeSuccess: function beforeSuccess(res) {}
    });
  },
  removeTabBarBadge: function removeTabBarBadge(params) {
    _bridge2.default.invokeMethod('removeTabBarBadge', params || {}, {
      beforeSuccess: function beforeSuccess(res) {}
    });
  },
  getMenuButtonBoundingClientRect: function getMenuButtonBoundingClientRect() {
    return menubuttonboundingClientRect;
  }
  // -------------------------- FinChat Api end -------------------------------
};

apiObj.onAppEnterBackground(function () {
  // apiObj.getClipboardData({
  //   success: function (e) {
  //     e && e.data !== currentClipBoardData &&
  //       ((currentClipBoardData = e.data), apiObj.reportClipBoardData)(!1)
  //   }
  // })
}), apiObj.onAppEnterForeground(), apiObj.appStatus = _configFlags2.default.AppStatus.FORE_GROUND, apiObj.hanged = !1, _bridge2.default.subscribe('INVOKE_METHOD', function (params, t) {
  var name = params.name,
      args = params.args;
  apiObj[name](args, !0);
}), _bridge2.default.subscribe('WEBVIEW_ERROR_MSG', function (params, t) {
  var msg = params.msg;
  Reporter.triggerErrorMessage(msg);
}), _bridge2.default.onMethod('onAppRoute', function (params) {
  var webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  params.path = params.path.replace(/\.\w+(\?|$)/, '$1'); // .substring(0, params.path.length - 5);
  params.webviewId = params.webviewId ? params.webviewId : webviewId;
  currUrl = params.path;
  if (_utils2.default.isObject(params.query)) {
    for (var n in params.query) {
      params.query[n] = decodeURIComponent(params.query[n]);
    }
  }
  if (params.openType == 'navigateBack' || params.openType == 'redirectTo') {
    _canvas2.default.clearOldWebviewCanvas();
  }
  _canvas2.default.notifyWebviewIdtoCanvas(params.webviewId);
  _map2.default.notifyWebviewIdtoMap(params.webviewId);
  curWebViewId = params.webviewId;
  appRouteCallbacks.forEach(function (callback) {
    callback(params);
  });
}), _bridge2.default.onMethod('onAppRouteDone', function (params) {
  var webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  params.path = params.path.replace(/\.\w+(\?|$)/, '$1'); // params.path.substring(0, params.path.length - 5);
  params.webviewId = typeof params.webviewId !== 'undefined' ? params.webviewId : webviewId;
  currUrl = params.path;
  appRouteDoneCallback.forEach(function (fn) {
    fn(params);
  });
  _bridge2.default.publish('onAppRouteDone', {}, [webviewId]);
}), _bridge2.default.onMethod('onKeyboardValueChange', function (params) {
  var webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
      pValue = params.value,
      pCursor = params.cursor;
  var fn = pageEventFn || componentEventFn;
  if (params.data && typeof fn === 'function') {
    var data = JSON.parse(params.data);
    if (data.bindinput) {
      var peRes;
      try {
        peRes = fn({
          data: {
            type: 'input',
            target: data.target,
            currentTarget: data.target,
            timeStamp: Date.now(),
            touches: [],
            detail: {
              value: params.value,
              cursor: params.cursor
            }
          },
          eventName: data.bindinput,
          webviewId: webviewId
        });
      } catch (e) {
        throw new _utils2.default.AppServiceSdkKnownError('bind key input error');
      }
      if (data.setKeyboardValue) {
        if (void 0 === peRes || peRes === null || peRes === !1) ;else if (_utils2.default.getDataType(peRes) === 'Object') {
          var opt = {
            inputId: params.inputId
          };
          pValue != peRes.value && (opt.value = peRes.value + '');
          isNaN(parseInt(peRes.cursor)) || (opt.cursor = parseInt(peRes.cursor), typeof opt.value === 'undefined' && (opt.value = pValue), opt.cursor > opt.value.length && (opt.cursor = -1));
          _bridge2.default.invokeMethod('setKeyboardValue', opt);
        } else {
          pValue != peRes && _bridge2.default.invokeMethod('setKeyboardValue', {
            value: peRes + '',
            cursor: -1,
            inputId: params.inputId
          });
        }
      }
    }
  }
  _bridge2.default.publish('setKeyboardValue', {
    value: pValue,
    cursor: pCursor,
    inputId: params.inputId
  }, [webviewId]);
});

var getTouchInfo = function getTouchInfo(touchInfo, eventKey, eventInfo) {
  // 返回touch信息
  var touches = [],
      changedTouches = [];
  if (eventKey === 'onTouchStart') {
    for (var i in touchInfo) {
      touches.push(touchInfo[i]);
    }
    var touchObj = {
      x: eventInfo.touch.x,
      y: eventInfo.touch.y,
      identifier: eventInfo.touch.id
    };
    changedTouches.push(touchObj);
    touches.push(touchObj);
  } else if (eventKey === 'onTouchMove') {
    for (var s in touchInfo) {
      var curTouchInfo = touchInfo[s],
          hasUpdate = !1;
      for (var f in eventInfo.touches) {
        var touchObj = {
          x: eventInfo.touches[f].x,
          y: eventInfo.touches[f].y,
          identifier: eventInfo.touches[f].id
        };
        if (touchObj.identifier === curTouchInfo.identifier && (curTouchInfo.x !== touchObj.x || curTouchInfo.y !== touchObj.y)) {
          touches.push(touchObj);
          changedTouches.push(touchObj);
          hasUpdate = !0;
          break;
        }
      }
      hasUpdate || touches.push(curTouchInfo);
    }
  } else if (eventKey === 'onTouchEnd') {
    var touchObj = {
      x: eventInfo.touch.x,
      y: eventInfo.touch.y,
      identifier: eventInfo.touch.id
    };
    for (var p in touchInfo) {
      var curTouchInfo = touchInfo[p];
      curTouchInfo.identifier === touchObj.identifier ? changedTouches.push(touchObj) : touches.push(curTouchInfo);
    }
  } else if (eventKey === 'onTouchCancel') {
    for (var v in eventInfo.touches) {
      var touchObj = {
        x: eventInfo.touches[v].x,
        y: eventInfo.touches[v].y,
        identifier: eventInfo.touches[v].id
      };
      changedTouches.push(touchObj);
    }
  } else if (eventKey === 'onLongPress') {
    var touchObj = {
      x: eventInfo.touch.x,
      y: eventInfo.touch.y,
      identifier: eventInfo.touch.id
    };
    for (var b in touchInfo) {
      touchInfo[b].identifier === touchObj.identifier ? touches.push(touchObj) : touches.push(touchInfo[b]);
    }
    changedTouches.push(touchObj);
  }
  return {
    touches: touches,
    changedTouches: changedTouches
  };
},
    touchEvents = {
  onTouchStart: 'touchstart',
  onTouchMove: 'touchmove',
  onTouchEnd: 'touchend',
  onTouchCancel: 'touchcancel',
  onLongPress: 'longtap'
};
['onTouchStart', 'onTouchMove', 'onTouchEnd', 'onTouchCancel', 'onLongPress'].forEach(function (eventName) {
  _bridge2.default.onMethod(eventName, function (params) {
    var webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
        data = JSON.parse(params.data),
        canvasNumber = data.canvasNumber;
    _canvas2.default.canvasInfo.hasOwnProperty(canvasNumber) || console.error('No such canvas ' + canvasNumber + ' register in ' + webviewId + ', but trigger ' + eventName + ' event.');
    var canvasData = _canvas2.default.canvasInfo[canvasNumber].data;
    var fn = pageEventFn || componentEventFn;
    if (canvasData[eventName] && typeof fn === 'function') {
      var touchInfo = getTouchInfo(canvasData.lastTouches, eventName, params),
          touches = touchInfo.touches,
          changedTouches = touchInfo.changedTouches;
      canvasData.lastTouches = touches, eventName === 'onTouchMove' && changedTouches.length === 0 || fn({
        data: {
          type: touchEvents[eventName],
          timeStamp: new Date() - canvasData.startTime,
          target: canvasData.target,
          touches: touches,
          changedTouches: changedTouches
        },
        eventName: canvasData[eventName],
        webviewId: webviewId
      });
    }
  });
}), ['onVideoPlay', 'onVideoPause', 'onVideoEnded', 'onVideoTimeUpdate', 'onVideoClickFullScreenBtn', 'onVideoClickDanmuBtn'].forEach(function (eventName) {
  _bridge2.default.onMethod(eventName, function () {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        webviewId = arguments[1],
        bindEventName = 'bind' + eventName.substring(7).toLowerCase(),
        dataObj = JSON.parse(params.data),
        handlers = dataObj.handlers,
        event = dataObj.event,
        createdTimestamp = dataObj.createdTimestamp;
    var fn = pageEventFn || componentEventFn;
    if (handlers[bindEventName] && typeof fn === 'function') {
      var data = {
        type: bindEventName.substring(4),
        target: event.target,
        currentTarget: event.currentTarget,
        timeStamp: Date.now() - createdTimestamp,
        detail: {}
      };
      bindEventName === 'bindtimeupdate' && (data.detail = {
        currentTime: params.position
      });
      fn({
        data: data,
        eventName: handlers[bindEventName],
        webviewId: webviewId
      });
    }
  });
}), _bridge2.default.onMethod('onAccelerometerChange', function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  accelerometerChangeFns.forEach(function (fn) {
    typeof fn === 'function' && fn(params);
  });
}), _bridge2.default.onMethod('onCompassChange', function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  compassChangeFns.forEach(function (fn) {
    typeof fn === 'function' && fn(params);
  });
}), _bridge2.default.onMethod('onError', function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  console.error('thirdScriptError', '\n', 'sdk uncaught third Error', '\n', params.message, '\n', params.stack);
}), _bridge2.default.onMethod('onMapMarkerClick', function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
      webViewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  var fn = pageEventFn || componentEventFn;
  if (params.data && typeof fn === 'function') {
    var data = JSON.parse(params.data);
    data.bindmarkertap && fn({
      data: {
        markerId: data.markerId
      },
      eventName: data.bindmarkertap,
      webviewId: webViewId
    });
  }
}), _bridge2.default.onMethod('onMapControlClick', function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
      webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  var fn = pageEventFn || componentEventFn;
  if (params.data && typeof fn === 'function') {
    var data = JSON.parse(params.data);
    data.bindcontroltap && fn({
      data: {
        controlId: data.controlId
      },
      eventName: data.bindcontroltap,
      webviewId: webviewId
    });
  }
}), _bridge2.default.onMethod('onMapRegionChange', function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
      webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
      mapInfo = _map2.default.mapInfo[webviewId + '_' + params.mapId];
  mapInfo && mapInfo.bindregionchange;
  var fn = pageEventFn || componentEventFn;
  if (typeof fn === 'function') {
    fn({
      data: {
        type: params.type
      },
      eventName: mapInfo.bindregionchange,
      webviewId: webviewId
    });
  }
}), _bridge2.default.onMethod('onMapClick', function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
      webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
      mapInfo = _map2.default.mapInfo[webviewId + '_' + params.mapId];
  mapInfo && mapInfo.bindtap;
  var fn = pageEventFn || componentEventFn;
  if (typeof fn === 'function') {
    fn({
      data: {},
      eventName: mapInfo.bindtap,
      webviewId: webviewId
    });
  }
});
for (var key in apiObj) {
  addGetterForWX(key);
}

function bindApi(item) {
  if (!item.name) {
    return;
  }
  WX[item.name] = function (params) {
    params = params || {};
    if (item.params && !paramCheck(item.name, params, item.params)) {
      return;
    }
    if (item.fn) {
      item.fn.call(apiObj, params);
    } else {
      _bridge2.default.invokeMethod(item.name, params, item.option);
    }
  };
}
WX.loadExtApi = function (conf) {
  if (conf) {
    var type = _utils2.default.getDataType(conf);
    if (type == 'Array') {
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = (0, _getIterator3.default)(conf), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var item = _step.value;

          bindApi(item);
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }
    } else if (type == 'Object') {
      bindApi(conf);
    }
  }
};
window.FinChatExtApiConf && WX.loadExtApi(window.FinChatExtApiConf);

window.onerror = function (e, t, n, i, o) {
  Reporter.errorReport({
    key: 'appServiceScriptError',
    error: o
  });
  console.error(o);
};

window.addEventListener('unhandledrejection', function (event) {
  Reporter.errorReport({
    key: 'appServiceScriptError',
    error: event.reason
  });
  console.error(event.reason.message + event.reason.stack);
});

window.wx = WX;
window.fc = WX;

exports.WX = WX;
exports.cacheSystemInfo = cacheSystemInfo;

/***/ }),
/* 506 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__(36);

var _stringify2 = _interopRequireDefault(_stringify);

var _defineProperty = __webpack_require__(105);

var _defineProperty2 = _interopRequireDefault(_defineProperty);

var _createClass2 = __webpack_require__(29);

var _createClass3 = _interopRequireDefault(_createClass2);

var _classCallCheck2 = __webpack_require__(23);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _typeof2 = __webpack_require__(13);

var _typeof3 = _interopRequireDefault(_typeof2);

var _utils = __webpack_require__(79);

var _utils2 = _interopRequireDefault(_utils);

var _canvas = __webpack_require__(507);

var _canvas2 = _interopRequireDefault(_canvas);

var _predefinedColor = __webpack_require__(621);

var _bridge = __webpack_require__(103);

var _bridge2 = _interopRequireDefault(_bridge);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Canvas Context API
function notifyCurrentRoutetoContext(url) {
  curUrl = url;
}

function isNum(e) {
  return typeof e === 'number';
}

function parseColorValue(colorStr) {
  var matchArr = null;
  if ((matchArr = /^#([0-9|A-F|a-f]{6})$/.exec(colorStr)) != null) {
    var red = parseInt(matchArr[1].slice(0, 2), 16),
        green = parseInt(matchArr[1].slice(2, 4), 16),
        blue = parseInt(matchArr[1].slice(4), 16);
    return [red, green, blue, 255];
  }
  if (null != (matchArr = /^#([0-9|A-F|a-f]{3})$/.exec(colorStr))) {
    var red = matchArr[1].slice(0, 1),
        green = matchArr[1].slice(1, 2),
        blue = matchArr[1].slice(2, 3);
    return red = parseInt(red + red, 16), green = parseInt(green + green, 16), blue = parseInt(blue + blue, 16), [red, green, blue, 255];
  }
  if ((matchArr = /^rgb\((.+)\)$/.exec(colorStr)) != null) {
    return matchArr[1].split(',').map(function (e) {
      return parseInt(e.trim());
    }).concat(255);
  }

  if ((matchArr = /^rgba\((.+)\)$/.exec(colorStr)) != null) {
    return matchArr[1].split(',').map(function (e, t) {
      return t == 3 ? Math.floor(255 * parseFloat(e.trim())) : parseInt(e.trim());
    });
  }

  var color = colorStr.toLowerCase();

  if (_predefinedColor.predefinedColor.hasOwnProperty(color)) {
    matchArr = /^#([0-9|A-F|a-f]{6})$/.exec(_predefinedColor.predefinedColor[color]);
    var red = parseInt(matchArr[1].slice(0, 2), 16),
        green = parseInt(matchArr[1].slice(2, 4), 16),
        blue = parseInt(matchArr[1].slice(4), 16);
    return [red, green, blue, 255];
  }

  console.group('非法颜色: ' + colorStr);
  console.error('不支持颜色：' + colorStr);
  console.groupEnd();
  return [0, 0, 0, 255];
}

function deepCopy(obj) {
  // 复制对象
  if (Array.isArray(obj)) {
    var res = [];
    obj.forEach(function (e) {
      res.push(deepCopy(e));
    });
    return res;
  }
  if ((typeof obj === 'undefined' ? 'undefined' : (0, _typeof3.default)(obj)) === 'object') {
    var res = {};
    for (var n in obj) {
      res[n] = deepCopy(obj[n]);
    }
    return res;
  }
  return obj;
}

var Pattern = function Pattern(t, n) {
  (0, _classCallCheck3.default)(this, Pattern);

  this.image = t, this.repetition = n;
};

function Gradient(e, t, n) {
  if (typeof n === 'string') {
    e.actions.push({
      method: t,
      data: ["normal", parseColorValue(n)]
    });
  } else if ((typeof n === 'undefined' ? 'undefined' : (0, _typeof3.default)(n)) === 'object') {
    e.actions.push({
      method: t,
      data: [n.type, n.data, n.colorStop]
    });
  } else if (n instanceof Pattern) {
    e.actions.push({
      method: t,
      data: ["pattern", n.image, n.repetition]
    });
  }
}
function _e(e) {
  if (Array.isArray(e)) {
    var t = [];
    e.forEach(function (e) {
      t.push(_e(e));
    });
    return t;
  }
  if ("object" == (typeof e === 'undefined' ? 'undefined' : (0, _typeof3.default)(e))) {
    var t = {};
    for (var n in e) {
      t[n] = _e(e[n]);
    }return t;
  }
  return e;
}

function _P(t) {
  this.width = t;
}

var transformAndOthersAPI = ["scale", "rotate", "translate", "setTransform", "transform"],
    drawingAPI = ["drawImage", "fillText", "fill", "stroke", "fillRect", "strokeRect", "clearRect", "strokeText"],
    drawPathAPI = ["setFillStyle", "setTextAlign", "setStrokeStyle", "setGlobalAlpha", "setShadow", "setFontSize", "setLineCap", "setLineJoin", "setLineWidth", "setMiterLimit", "setTextBaseline", "setLineDash"],
    curUrl = '';

var ColorStop = function () {
  function ColorStop(type, data) {
    (0, _classCallCheck3.default)(this, ColorStop);

    this.type = type;
    this.data = data;
    this.colorStop = [];
  }

  (0, _createClass3.default)(ColorStop, [{
    key: 'addColorStop',
    value: function addColorStop(e, t) {
      this.colorStop.push([e, parseColorValue(t)]);
    }
  }]);
  return ColorStop;
}();

var Context = function () {
  function Context(t) {
    var _this2 = this;

    (0, _classCallCheck3.default)(this, Context);

    this.actions = [];
    this.path = [];
    this.drawingState = [];
    this.canvasId = t;
    this.state = {
      lineDash: [0, 0],
      shadowOffsetX: 0,
      shadowOffsetY: 0,
      shadowBlur: 0,
      shadowColor: [0, 0, 0, 0],
      font: "10px sans-serif",
      fontSize: 10,
      fontWeight: "normal",
      fontStyle: "normal",
      fontFamily: "sans-serif"
    };
    var a = document.createElement("canvas");
    this._context = a.getContext("2d");
    this.listenProps = ['fillStyle', 'strokeStyle', 'font', 'globalAlpha', 'textAlign', 'lineCap', 'lineJoin', 'lineWidth', 'miterLimit', 'textBaseline'];
    var _this = this;

    var _loop = function _loop(_i) {
      var prop = _this2.listenProps[_i];
      (0, _defineProperty2.default)(_this2, prop, {
        set: function set(newValue) {
          //需要触发的渲染函数写在这...
          var s = 'set' + prop;
          var key = 'set' + s[3].toUpperCase() + s.slice(4);
          if (prop === 'fillStyle' || prop === 'strokeStyle') {
            Gradient(_this, key, newValue);
          } else if (prop === 'font') {
            var _t = function _t() {
              _this.actions.push({
                method: "setFontStyle",
                data: ["normal"]
              });
              _this.state.fontStyle = "normal";
            };

            var n = function n() {
              _this.actions.push({
                method: "setFontWeight",
                data: ["normal"]
              });
              _this.state.fontWeight = "normal";
            };

            var o = _this;
            _this.state.font = newValue;
            var r = newValue.match(/^(([\w\-]+\s)*)(\d+r?px)(\/(\d+\.?\d*(r?px)?))?\s+(.*)/);
            if (!r) {
              console.warn("Failed to set 'font' on 'CanvasContext': invalid format.");
              return;
            }
            var i = r[1].trim().split(/\s/),
                a = parseFloat(r[3]),
                u = r[7],
                s = [],
                c = "",
                l = _this;

            i.forEach(function (e, r) {
              if (["italic", "oblique", "normal"].indexOf(e) > -1) {
                s.push({
                  method: "setFontStyle",
                  data: [e]
                });
                o.state.fontStyle = e;
              } else if (["bold", "normal"].indexOf(e) > -1) {
                s.push({
                  method: "setFontWeight",
                  data: [e]
                });
                o.state.fontWeight = e;
              } else if (0 === r) {
                _t();
              } else if (1 === r) {
                n();
              }
            });
            if (1 === i.length) {
              n();
              c = s.map(function (e) {
                return e.data[0];
              }).join(" ");
              _this.state.fontSize = a;
              _this.state.fontFamily = u;
              c = c + " " + a + "px " + u;
              _this.actions.push({
                method: "setFont",
                data: [c]
              });
              return;
            }
            _this.actions.push.apply(_this.actions, s);
            _this.actions.push({
              method: "setFontSize",
              data: [a]
            });
            _this.actions.push({
              method: "setFontFamily",
              data: [u]
            });
          } else if (prop === 'globalAlpha') {
            var v = Math.floor(255 * parseFloat(newValue));
            _this.actions.push({
              method: "setGlobalAlpha",
              data: [v]
            });
          } else {
            _this.actions.push({
              method: key,
              data: [newValue]
            });
          }
        },
        configurable: true
      });
    };

    for (var _i in this.listenProps) {
      _loop(_i);
    }
  }

  (0, _createClass3.default)(Context, [{
    key: 'getActions',
    value: function getActions() {
      var actions = deepCopy(this.actions);
      this.actions = [];
      this.path = [];
      return actions;
    }
  }, {
    key: 'clearActions',
    value: function clearActions() {
      this.actions = [];
      this.path = [];
    }
  }, {
    key: 'draw',
    value: function draw() {
      var reserve = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          canvasId = this.canvasId,
          actions = deepCopy(this.actions);
      this.actions = [];
      this.path = [];
      _canvas2.default.drawCanvas({
        canvasId: canvasId,
        actions: actions,
        reserve: reserve
      });
    }
    /**
     * 
     * @param {Number} x0 起点的x坐标
     * @param {Number} y0 起点的y坐标
     * @param {Number} x1 终点的x坐标
     * @param {Number} y1 终点的y坐标
     */

  }, {
    key: 'createLinearGradient',
    value: function createLinearGradient(x0, y0, x1, y1) {
      return new ColorStop('linear', [x0, y0, x1, y1]);
    }
    /**
     * 
     * @param {Number} x 圆心的x坐标
     * @param {Number} y 圆心的y坐标
     * @param {Number} r 圆的半径
     */

  }, {
    key: 'createCircularGradient',
    value: function createCircularGradient(x, y, r) {
      return new ColorStop('radial', [x, y, r]);
    }
    // add api

  }, {
    key: 'measureText',
    value: function measureText(txt) {
      this._context.font = this.state.font;
      return this._context.measureText(txt);
    }
  }, {
    key: 'save',
    value: function save() {
      this.actions.push({
        method: "save",
        data: [(0, _stringify2.default)(this.state)]
      });
      this.drawingState.push(this.state);
    }
  }, {
    key: 'restore',
    value: function restore() {
      this.state = this.drawingState.pop() || {
        lineDash: [0, 0],
        shadowOffsetX: 0,
        shadowOffsetY: 0,
        shadowBlur: 0,
        shadowColor: [0, 0, 0, 0],
        font: "10px sans-serif",
        fontSize: 10,
        fontWeight: "normal",
        fontStyle: "normal",
        fontFamily: "sans-serif"
      };
      this.actions.push({
        method: "restore",
        data: []
      });
    }
    /**
     * 
     * @param {Number} x 
     * @param {Number} y 
     * @param {Number} width 
     * @param {Number} height 
     */

  }, {
    key: 'rect',
    value: function rect(x, y, width, height) {
      this.path.push({
        method: "rect",
        data: [x, y, width, height]
      }), this.subpath = [[x, y]], "android" === _utils2.default.getPlatform() && this.path.push({
        method: "closePath",
        data: []
      });
    }
  }, {
    key: 'getLineDash',
    value: function getLineDash() {
      return this.state.lineDash;
    }
  }, {
    key: 'beginPath',
    value: function beginPath() {
      this.path = [];
      this.subpath = [];
    }
  }, {
    key: 'moveTo',
    value: function moveTo(x, y) {
      this.path.push({
        method: "moveTo",
        data: [x, y]
      });
      this.subpath = [[x, y]];
    }
  }, {
    key: 'closePath',
    value: function closePath() {
      this.path.push({
        method: "closePath",
        data: []
      });
      this.subpath.length && (this.subpath = [this.subpath.shift()]);
    }
    /**
     * 
     * @param {Number} x 目标位置的x坐标
     * @param {Number} y 目标位置的y坐标
     */

  }, {
    key: 'lineTo',
    value: function lineTo(x, y) {
      0 === this.path.length && 0 === this.subpath.length ? this.path.push({
        method: "moveTo",
        data: [].slice.apply(arguments)
      }) : this.path.push({
        method: "lineTo",
        data: [].slice.apply(arguments)
      });
      this.subpath.push([x, y]);
    }
    /**
     * 
     * @param {Number} cpx 贝塞尔控制点的x坐标
     * @param {Number} cpy 贝塞尔控制点的y坐标
     * @param {Number} x 结束点的x坐标
     * @param {Number} y 结束点的y坐标
     */

  }, {
    key: 'quadraticCurveTo',
    value: function quadraticCurveTo(cpx, cpy, x, y) {
      this.path.push({
        method: "quadraticCurveTo",
        data: [cpx, cpy, x, y]
      }), this.subpath.push([x, y]);
    }
    /**
     * 
     * @param {Number} cp1x 第一个贝塞尔控制点的 x 坐标
     * @param {Number} cp1y 第一个贝塞尔控制点的 y 坐标
     * @param {Number} cp2x 第二个贝塞尔控制点的 x 坐标
     * @param {Number} cp2y 第二个贝塞尔控制点的 y 坐标
     * @param {Number} x 结束点的 x 坐标
     * @param {Number} y 结束点的 y 坐标
     */

  }, {
    key: 'bezierCurveTo',
    value: function bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y) {
      this.path.push({
        method: "bezierCurveTo",
        data: [cp1x, cp1y, cp2x, cp2y, x, y]
      }), this.subpath.push([x, y]);
    }
    /**
     * 
     * @param {Number} x 圆的x坐标
     * @param {Number} y 圆的y坐标
     * @param {Number} r 圆的半径
     * @param {Number} sAngle 起始弧度，单位弧度（在3点钟方向）
     * @param {Number} eAngle 终止弧度
     * @param {Boolean} counterclockwise 可选。指定弧度的方向是逆时针还是顺时针。默认是false，即顺时针。
     */

  }, {
    key: 'arc',
    value: function arc(x, y, r, sAngle, eAngle) {
      var i = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
      return this.path.push({
        method: "arc",
        data: [x, y, r, sAngle, eAngle, i]
      });
    }
    /**
     * 
     * @param {Number} x1 第一个控制点的 x 轴坐标
     * @param {Number} y1 第一个控制点的 y 轴坐标
     * @param {Number} x2 第二个控制点的 x 轴坐标
     * @param {Number} y2 第二个控制点的 y 轴坐标
     * @param {Number} radius 圆弧的半径
     */
    // e, t, n, r, o, i

  }, {
    key: 'arcTo',
    value: function arcTo(x1, y1, x2, y2, radius) {
      return this.path.push({
        method: "arcTo",
        data: [x1, y1, x2, y2, radius]
      });
    }
    /**
     * clip() 方法从原始画布中剪切任意形状和尺寸。
     * 一旦剪切了某个区域，则所有之后的绘图都会被限制在被剪切的区域内（不能访问画布上的其他区域）。
     * 可以在使用 clip() 方法前通过使用 save() 方法对当前画布区域进行保存，并在以后的任意时间对其进行恢复（通过 restore() 方法）
     */

  }, {
    key: 'clip',
    value: function clip() {
      this.actions.push({
        method: "clip",
        data: _e(this.path)
      });
    }
    /**
     * 
     * @param {Number} value 偏移量，初始值为 0
     */

  }, {
    key: 'lineDashOffset',
    value: function lineDashOffset(value) {
      this.actions.push({
        method: "setLineDashOffset",
        data: [value]
      });
    }
    /**
     * 
     * @param {String} image 重复的图像源，仅支持包内路径和临时路径
     * @param {String} repetition 指定如何重复图像，有效值有: repeat, repeat-x, repeat-y, no-repeat
     */

  }, {
    key: 'createPattern',
    value: function createPattern(image, repetition) {
      if (repetition === 0) {
        console.error("Failed to execute 'createPattern' on 'CanvasContext': 2 arguments required, but only 1 present.");
        return;
      } else if (["repeat", "repeat-x", "repeat-y", "no-repeat"].indexOf(repetition) === -1) {
        console.error("Failed to execute 'createPattern' on 'CanvasContext': The provided type ('" + repetition + "') is not one of 'repeat', 'no-repeat', 'repeat-x', or 'repeat-y'.");
      } else {
        return new Pattern(image, repetition);
      }
    }
  }]);
  return Context;
}();
// Class Context end

;[].concat(transformAndOthersAPI, drawingAPI).forEach(function (apiName) {

  apiName == 'fill' || apiName == 'stroke' ? Context.prototype[apiName] = function () {
    // if (this.fillStyle) {
    //   Gradient(this,'setFillStyle',this.fillStyle)
    // }
    // if (this.strokeStyle) {
    //   Gradient(this,'setStrokeStyle',this.strokeStyle)
    // }
    this.actions.push({
      method: apiName + 'Path',
      data: deepCopy(this.path)
    });
  } : apiName === 'fillRect' ? Context.prototype[apiName] = function (e, t, n, o) {
    this.actions.push({
      method: 'fillPath',
      data: [{
        method: 'rect',
        data: [e, t, n, o]
      }]
    });
  } : apiName === 'strokeRect' ? Context.prototype[apiName] = function (e, t, n, o) {
    this.actions.push({
      method: 'strokePath',
      data: [{
        method: 'rect',
        data: [e, t, n, o]
      }]
    });
  } : apiName == 'fillText' ? Context.prototype[apiName] = function (t, n, o) {
    // if (this.font) {
    //   this.actions.push({
    //     method: 'setFont',
    //     data: [this.font]
    //   })
    // }
    // if (this.fillStyle) {
    //   Gradient(this,'setFillStyle',this.fillStyle)
    // }
    this.actions.push({
      method: apiName,
      data: [t.toString(), n, o]
    });
  } : apiName == 'drawImage' ? Context.prototype[apiName] = function (t, n, o, r, a) {
    // "devtools" == utils.getPlatform() || /wdfile:\/\//.test(t) || (t = utils.getRealRoute(curUrl, t).replace(/.html$/, "")),
    var data = isNum(r) && isNum(a) ? [t, n, o, r, a] : [t, n, o];
    this.actions.push({
      method: apiName,
      data: data
    });
  } : Context.prototype[apiName] = function () {
    this.actions.push({
      method: apiName,
      data: [].slice.apply(arguments)
    });
  };
});
drawPathAPI.forEach(function (apiName) {
  'setFillStyle' == apiName || 'setStrokeStyle' == apiName ? Context.prototype[apiName] = function () {
    var t = arguments[0];
    Gradient(this, apiName, t);
  } : 'setGlobalAlpha' === apiName ? Context.prototype[apiName] = function () {
    var t = [].slice.apply(arguments, [0, 1]);
    t[0] = Math.floor(255 * parseFloat(t[0])), this.actions.push({
      method: apiName,
      data: t
    });
  } : 'setShadow' == apiName ? Context.prototype[apiName] = function () {
    var t = [].slice.apply(arguments, [0, 4]);
    t[3] = i(t[3]), this.actions.push({
      method: apiName,
      data: t
    }), this.state.shadowBlur = t[2], this.state.shadowColor = t[3], this.state.shadowOffsetX = t[0], this.state.shadowOffsetY = t[1];
  } : 'setLineDash' == apiName ? Context.prototype[apiName] = function () {
    var t = [].slice.apply(arguments, [0, 2]);
    t[0] = t[0] || [0, 0], t[1] = t[1] || 0, this.actions.push({
      method: apiName,
      data: t
    }), this.state.lineDash = t[0];
  } : 'setFontSize' === apiName ? Context.prototype.setFontSize = function (apiName) {
    this.state.font = this.state.font.replace(/\d+\.?\d*px/, apiName + 'px'), this.state.fontSize = apiName, this.actions.push({
      method: 'setFontSize',
      data: [apiName]
    });
  } : Context.prototype[apiName] = function () {
    this.actions.push({
      method: apiName,
      data: [].slice.apply(arguments, [0, 1])
    });
  };
});

exports.default = {
  notifyCurrentRoutetoContext: notifyCurrentRoutetoContext,
  Context: Context
};

/***/ }),
/* 507 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _bridge = __webpack_require__(103);

var _bridge2 = _interopRequireDefault(_bridge);

var _context = __webpack_require__(506);

var _context2 = _interopRequireDefault(_context);

var _utils = __webpack_require__(79);

var _utils2 = _interopRequireDefault(_utils);

var _EventEmitter = __webpack_require__(212);

var _EventEmitter2 = _interopRequireDefault(_EventEmitter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function canvasDesString(webviewID, canvasId) {
  return webviewID + 'canvas' + canvasId;
}

function clearOldWebviewCanvas() {
  // for (var key in canvasIDs) {
  //   if (key.indexOf(webviewID + 'canvas') == 0) {
  //     canvasIDs[key]
  //     delete canvasIDs[key]
  //   }
  // }
}

function notifyWebviewIdtoCanvas(e) {
  webviewID = e;
}

function invokeDrawCanvas(canvasId, actions) {
  var reserve = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
  /*
        success = arguments[3],
        fail = arguments[4],
        complte = arguments[5],
        platform = utils.getPlatform();
    "ios" == platform || "android" == platform ?
        ServiceJSBridge.invoke("drawCanvas", {
            canvasId: canvasId,
            reserve: reserve,
            actions: actions
        },
        function (e) {
            e.errMsg && /ok/.test(e.errMsg) ?
            "function" == typeof success && success(e) :
            "function" == typeof fail && fail(e)
            "function" == typeof complte && complte(e)
        }) :
  */
  ServiceJSBridge.publish('canvas' + canvasId + 'actionsChanged', {
    actions: actions,
    reserve: reserve
  }, [webviewID]);
}

function drawCanvas(params) {
  var canvasId = params.canvasId,
      actions = params.actions,
      reserve = params.reserve,
      success = params.success,
      fail = params.fail,
      complete = params.complete;
  // if (params.actions.length > 3) {
  //   debugger;
  // }
  if (canvasId && Array.isArray(actions)) {
    var key = canvasDesString(webviewID, canvasId);
    if (typeof canvasIDs[key] === 'number') {
      var canvasId = canvasIDs[key];
      invokeDrawCanvas(canvasId, actions, reserve, success, fail, complete);
    } else {
      canvasOptions[key] = canvasOptions[key] || [];
      canvasOptions[key] = canvasOptions[key].concat({
        actions: actions,
        reserve: reserve,
        success: success,
        fail: fail,
        complete: complete
      });
    }
  }
}

function canvasToTempFilePathImpl(obj) {
  ServiceJSBridge.subscribe('onCanvasToDataUrl_' + obj.canvasId, function (params) {
    var dataUrl = params.dataUrl;
    _bridge2.default.invokeMethod('base64ToTempFilePath', _utils2.default.assign({
      base64Data: dataUrl
    }, obj), {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('base64ToTempFilePath', 'canvasToTempFilePath');
      }
    });
  });
  _bridge2.default.publish('invokeCanvasToDataUrl_' + obj.canvasId, _utils2.default.assign({
    canvasId: obj.canvasId
  }, obj), [webviewID]);
}

function canvasToTempFilePath(obj) {
  if (obj.canvasId) {
    var key = canvasDesString(webviewID, obj.canvasId);
    if (typeof canvasIDs[key] === 'number') {
      obj.canvasId = canvasIDs[key];
      canvasToTempFilePathImpl(obj);
    } else {
      var res = {
        errMsg: 'canvasToTempFilePath: fail canvas is empty'
      };
      typeof obj.fail === 'function' && obj.fail(res), typeof obj.complete === 'function' && obj.complete(res);
    }
  }
}

var webviewID = (new _EventEmitter2.default.EventEmitter2(), 0),
    canvasInfo = {},
    canvasIDs = {},
    canvasOptions = {};

ServiceJSBridge.subscribe('canvasInsert', function (event, t) {
  var canvasId = event.canvasId,
      canvasNumber = event.canvasNumber,
      data = event.data,
      key = canvasDesString(webviewID, canvasId);

  canvasInfo[canvasNumber] = {
    lastTouches: [],
    data: data
  };

  canvasIDs[key] = canvasIDs[key] || canvasNumber;

  Array.isArray(canvasOptions[key]) && (canvasOptions[key].forEach(function (e) {
    invokeDrawCanvas(canvasNumber, e.actions, e.reserve, e.success, e.fail, e.complete);
  }), delete canvasOptions[key]);
});

ServiceJSBridge.subscribe('canvasRemove', function (params, t) {
  var canvasId = params.canvasId,
      canvasIndex = canvasDesString(webviewID, canvasId);
  canvasIDs[canvasIndex] && delete canvasIDs[canvasIndex];
});

var createContext = function createContext() {
  return new _context2.default.Context();
},
    createCanvasContext = function createCanvasContext(e) {
  return new _context2.default.Context(e);
};

exports.default = {
  canvasInfo: canvasInfo,
  clearOldWebviewCanvas: clearOldWebviewCanvas,
  notifyWebviewIdtoCanvas: notifyWebviewIdtoCanvas,
  drawCanvas: drawCanvas,
  canvasToTempFilePath: canvasToTempFilePath,
  createContext: createContext,
  createCanvasContext: createCanvasContext
};

/***/ }),
/* 508 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _promise = __webpack_require__(207);

var _promise2 = _interopRequireDefault(_promise);

var _setImmediate2 = __webpack_require__(481);

var _setImmediate3 = _interopRequireDefault(_setImmediate2);

exports.withMacroTask = withMacroTask;
exports.nextTick = nextTick;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var callbacks = [];
var pending = false;

function noop() {}
var ua = window.navigator.userAgent.toLowerCase();
var isIOS = /(iphone|ipad)/.test(ua);
var isNative = function isNative() {
  return false;
};

function handleError(e) {
  console.log(e);
}

function flushCallbacks() {
  pending = false;
  var copies = callbacks.slice(0);
  callbacks.length = 0;
  for (var i = 0; i < copies.length; i++) {
    copies[i]();
  }
}

// Here we have async deferring wrappers using both microtasks and (macro) tasks.
// In < 2.4 we used microtasks everywhere, but there are some scenarios where
// microtasks have too high a priority and fire in between supposedly
// sequential events (e.g. #4521, #6690) or even between bubbling of the same
// event (#6566). However, using (macro) tasks everywhere also has subtle problems
// when state is changed right before repaint (e.g. #6813, out-in transitions).
// Here we use microtask by default, but expose a way to force (macro) task when
// needed (e.g. in event handlers attached by v-on).
var microTimerFunc = void 0;
var macroTimerFunc = void 0;
var useMacroTask = false;

// Determine (macro) task defer implementation.
// Technically setImmediate should be the ideal choice, but it's only available
// in IE. The only polyfill that consistently queues the callback after all DOM
// events triggered in the same loop is by using MessageChannel.
/* istanbul ignore if */
if (typeof _setImmediate3.default !== 'undefined' && isNative(_setImmediate3.default)) {
  macroTimerFunc = function macroTimerFunc() {
    (0, _setImmediate3.default)(flushCallbacks);
  };
} else if (typeof MessageChannel !== 'undefined' && (isNative(MessageChannel) ||
// PhantomJS
MessageChannel.toString() === '[object MessageChannelConstructor]')) {
  var channel = new MessageChannel();
  var port = channel.port2;
  channel.port1.onmessage = flushCallbacks;
  macroTimerFunc = function macroTimerFunc() {
    port.postMessage(1);
  };
} else {
  /* istanbul ignore next */
  macroTimerFunc = function macroTimerFunc() {
    setTimeout(flushCallbacks, isIOS ? -1 : 0);
  };
}

// Determine microtask defer implementation.
/* istanbul ignore next, $flow-disable-line */
if (typeof _promise2.default !== 'undefined' && isNative(_promise2.default)) {
  var p = _promise2.default.resolve();
  microTimerFunc = function microTimerFunc() {
    p.then(flushCallbacks);
    // in problematic UIWebViews, Promise.then doesn't completely break, but
    // it can get stuck in a weird state where callbacks are pushed into the
    // microtask queue but the queue isn't being flushed, until the browser
    // needs to do some other work, e.g. handle a timer. Therefore we can
    // "force" the microtask queue to be flushed by adding an empty timer.
    if (isIOS) {
      setTimeout(noop, -1);
    }
  };
} else {
  // fallback to macro
  microTimerFunc = macroTimerFunc;
}

/**
 * Wrap a function so that if any code inside triggers state change,
 * the changes are queued using a (macro) task instead of a microtask.
 */
function withMacroTask(fn) {
  return fn._withTask || (fn._withTask = function () {
    useMacroTask = true;
    var res = fn.apply(null, arguments);
    useMacroTask = false;
    return res;
  });
}

function nextTick(cb, ctx) {
  var _resolve = void 0;
  callbacks.push(function () {
    if (cb) {
      try {
        cb.call(ctx);
      } catch (e) {
        handleError(e, ctx, 'nextTick');
      }
    } else if (_resolve) {
      _resolve(ctx);
    }
  });
  if (!pending) {
    pending = true;
    if (useMacroTask) {
      macroTimerFunc();
    } else {
      microTimerFunc();
    }
  }
  // $flow-disable-line
  if (!cb && typeof _promise2.default !== 'undefined') {
    return new _promise2.default(function (resolve) {
      _resolve = resolve;
    });
  }
}

/***/ }),
/* 509 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.parsePath = parsePath;
exports.getObjectByPath = getObjectByPath;
exports.setObjectDataByPath = setObjectDataByPath;

var _utils = __webpack_require__(107);

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function parsePath(pathStr) {
  // 解析data path
  for (var length = pathStr.length, paths = [], key = '', arrKey = 0, hasNum = false, arrStartFlag = false, index = 0; index < length; index++) {
    var curStr = pathStr[index];
    if ('\\' === curStr) {
      if (index + 1 < length && ('.' === pathStr[index + 1] || '[' === pathStr[index + 1] || ']' === pathStr[index + 1])) {
        key += pathStr[index + 1];
        index++;
      } else {
        key += '\\';
      }
      //   index + 1 < length && ('.' === pathStr[index + 1] || '[' === pathStr[index + 1] || ']' === pathStr[index + 1]) ? (key += pathStr[index + 1], index++) : key += '\\'
    } else if ('.' === curStr) {
      if (key) {
        paths.push(key);
        key = '';
      }
      //   key && (paths.push(key), key = '')
    } else if ('[' === curStr) {
      if (key && (paths.push(key), key = ''), 0 === paths.length) {
        throw _utils2.default.error('数据路径错误', 'Path can not start with []: ' + pathStr);
        new _utils2.default.AppServiceEngineKnownError('Path can not start with []: ' + pathStr);
      }
      arrStartFlag = true;
      hasNum = false;
    } else if (']' === curStr) {
      if (!hasNum) {
        throw _utils2.default.error('数据路径错误', 'Must have number in []: ' + pathStr);
        new _utils2.default.AppServiceEngineKnownError('Must have number in []: ' + pathStr);
      }
      arrStartFlag = false;
      paths.push(arrKey);
      arrKey = 0;
    } else if (arrStartFlag) {
      if (curStr < '0' || curStr > '9') {
        throw _utils2.default.error('数据路径错误', 'Only number 0-9 could inside []: ' + pathStr);
        new _utils2.default.AppServiceEngineKnownError('Only number 0-9 could inside []: ' + pathStr);
      }
      hasNum = true;
      arrKey = 10 * arrKey + curStr.charCodeAt(0) - 48;
    } else {
      key += curStr;
    }
  }
  if (key && paths.push(key), 0 === paths.length) {
    throw _utils2.default.error('数据路径错误', 'Path can not be empty');
    new _utils2.default.AppServiceEngineKnownError('Path can not be empty');
  }
  return paths;
}
function getObjectByPath(data, pathString) {
  var paths = parsePath(pathString),
      obj,
      curKey,
      curData = data;
  for (var index = 0; index < paths.length; index++) {
    Number(paths[index]) === paths[index] && paths[index] % 1 === 0 ? // isint
    Array.isArray(curData) || (curData = []) : _utils2.default.isPlainObject(curData) || (curData = {});
    curKey = paths[index]; // key
    obj = curData; // parentObj
    curData = curData[paths[index]]; // node value
  }
  return {
    obj: obj,
    key: curKey
  };
}

var arrReg = /[\[0-9]+]/;
function setObjectDataByPath(data, pathString, value) {
  var keyList = !Array.isArray(pathString) ? pathString.replace(/\[/g, '.[').replace(/\]/g, '].').split('.').filter(function (i) {
    return i;
  }) : pathString;
  var lastIndex = keyList.length - 1;
  try {
    keyList.reduce(function (obj, key, index, list) {
      key = arrReg.test(key) ? key.replace('[', '').replace(']', '') : key;
      if (index === lastIndex) obj[key] = value;
      var res = obj[key];
      if (res === undefined) {
        res = obj[key] = arrReg.test(list[index + 1]) ? [] : {};
      }
      return res;
    }, data);
  } catch (error) {
    console.error('数据路径错误', pathString + ' is undefined');
  }
}

/***/ }),
/* 510 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
var triggerAnalytics = exports.triggerAnalytics = function triggerAnalytics(eventName, pageObj, desc) {
    var data = {};
    if (pageObj) {
        data.pageRoute = pageObj.__route__;
    }
    if (desc) {
        data.desc = desc;
    }
    ServiceJSBridge.publish("H5_LOG_MSG", { event: eventName, desc: data }, [pageObj && pageObj.__wxWebviewId__ || '']);
};

/***/ }),
/* 511 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _create = __webpack_require__(30);

var _create2 = _interopRequireDefault(_create);

var _keys = __webpack_require__(37);

var _keys2 = _interopRequireDefault(_keys);

var _typeof2 = __webpack_require__(13);

var _typeof3 = _interopRequireDefault(_typeof2);

var _classCallCheck2 = __webpack_require__(23);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(29);

var _createClass3 = _interopRequireDefault(_createClass2);

var _parseFunction = __webpack_require__(226);

var _parseFunction2 = _interopRequireDefault(_parseFunction);

var _parseUtils = __webpack_require__(214);

var _parseUtils2 = _interopRequireDefault(_parseUtils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var sysKeys = ['isInit', 'isTruePage', 'config'];

var PageRouter = function () {
  function PageRouter() {
    var _this = this;

    (0, _classCallCheck3.default)(this, PageRouter);

    this.tabBars = [];
    this.stack = [];
    this.stackObjs = {};
    this.configObjs = {};
    this.currentPage = null;

    if (__wxConfig__.tabBar && __wxConfig__.tabBar.list && (0, _typeof3.default)(__wxConfig__.tabBar.list) === 'object' && typeof __wxConfig__.tabBar.list.forEach === 'function') {
      __wxConfig__.tabBar.list.forEach(function (item) {
        _this.tabBars.push(item.pagePath);
      });
    }
  }

  (0, _createClass3.default)(PageRouter, [{
    key: 'getPageConfig',
    value: function getPageConfig(pagePath) {
      return this.configObjs[pagePath];
    }
  }, {
    key: 'isTabBarsPage',
    value: function isTabBarsPage(route) {
      //
      var path = route.route.indexOf('/') === 0 ? route.route.substr(1) : route.route;
      return this.tabBars.indexOf(path) !== -1 || this.tabBars.indexOf(path + '.html') !== -1;
    }
  }, {
    key: 'push',
    value: function push(webviewId, page, route) {
      this.currentPage = {
        webviewId: webviewId,
        page: page,
        route: route
      };
      this.stack.push(this.currentPage);
      this.stackObjs[webviewId] = {
        page: page,
        route: route
      };
    }
  }, {
    key: 'pop',
    value: function pop(webviewId) {
      delete this.stackObjs[webviewId];
      _parseFunction2.default.deleteFunctions(webviewId);
      _parseUtils2.default.deleteComponentInstancesByWebviewId(webviewId);
      _parseUtils2.default.deleteSelectorMapByWebviewId(webviewId);
      this.stack.pop();
      // this.stack = this.stack.slice(0, this.stack.length - 1)
    }
  }, {
    key: 'isPageExist',
    value: function isPageExist(webviewId) {
      return this.stackObjs.hasOwnProperty(webviewId);
    }
  }, {
    key: 'reset',
    value: function reset() {
      this.stack = [];
      this.stackObjs = {};
      this.configObjs = {};
      this.currentPage = null;
      _parseFunction2.default.resetFuncion();
    }
  }, {
    key: 'getWebviewIdToPage',
    value: function getWebviewIdToPage() {
      return this.stackObjs;
    }
  }, {
    key: 'getRouteToPage',
    value: function getRouteToPage() {
      return this.configObjs;
    }
  }, {
    key: 'getCurrentPage',
    value: function getCurrentPage() {
      return this.currentPage;
    }
  }, {
    key: 'getCurrentPages',
    value: function getCurrentPages() {
      return this.stack.map(function (pageObj) {
        var keys = (0, _keys2.default)(pageObj.page);
        var page = (0, _create2.default)(pageObj.page.constructor.prototype);
        keys.forEach(function (key) {
          if (sysKeys.includes(key)) return;
          if (key === 'path') {
            var path = pageObj.page.path;

            page.route = path.startsWith('/') ? path.substr(1) : path;
            return;
          }
          page[key] = pageObj.page[key];
        });
        return page;
      });
    }
  }]);
  return PageRouter;
}();

exports.default = new PageRouter();

/***/ }),
/* 512 */,
/* 513 */,
/* 514 */,
/* 515 */,
/* 516 */,
/* 517 */,
/* 518 */,
/* 519 */,
/* 520 */,
/* 521 */,
/* 522 */,
/* 523 */,
/* 524 */,
/* 525 */,
/* 526 */,
/* 527 */,
/* 528 */,
/* 529 */,
/* 530 */,
/* 531 */,
/* 532 */,
/* 533 */,
/* 534 */,
/* 535 */,
/* 536 */,
/* 537 */,
/* 538 */,
/* 539 */,
/* 540 */,
/* 541 */,
/* 542 */,
/* 543 */,
/* 544 */,
/* 545 */,
/* 546 */,
/* 547 */,
/* 548 */,
/* 549 */,
/* 550 */,
/* 551 */,
/* 552 */,
/* 553 */,
/* 554 */,
/* 555 */,
/* 556 */,
/* 557 */,
/* 558 */,
/* 559 */,
/* 560 */,
/* 561 */,
/* 562 */,
/* 563 */,
/* 564 */,
/* 565 */,
/* 566 */,
/* 567 */,
/* 568 */,
/* 569 */,
/* 570 */,
/* 571 */,
/* 572 */,
/* 573 */,
/* 574 */,
/* 575 */,
/* 576 */,
/* 577 */,
/* 578 */,
/* 579 */,
/* 580 */,
/* 581 */,
/* 582 */,
/* 583 */,
/* 584 */,
/* 585 */,
/* 586 */,
/* 587 */,
/* 588 */,
/* 589 */,
/* 590 */,
/* 591 */,
/* 592 */,
/* 593 */,
/* 594 */,
/* 595 */,
/* 596 */,
/* 597 */,
/* 598 */,
/* 599 */,
/* 600 */,
/* 601 */,
/* 602 */,
/* 603 */,
/* 604 */,
/* 605 */,
/* 606 */,
/* 607 */,
/* 608 */,
/* 609 */,
/* 610 */,
/* 611 */,
/* 612 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(227);

__webpack_require__(613);

__webpack_require__(614);

__webpack_require__(615);

__webpack_require__(431);

__webpack_require__(505);

__webpack_require__(625);

__webpack_require__(627);

__webpack_require__(628);

__webpack_require__(629);

__webpack_require__(642);

delete window.indexedDB;

/***/ }),
/* 613 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 614 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 615 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(36);

var _stringify2 = _interopRequireDefault(_stringify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// 在 iOS 上，小程序的 javascript 代码是运行在 JavaScriptCore 中，是由 WKWebView 来渲染的，环境有 iOS8、iOS9、iOS10
// 在 Android 上，小程序的 javascript 代码是通过 X5 JSCore来解析，是由 X5 基于 Mobile Chrome 37 内核来渲染的
// 在 开发工具上， 小程序的 javascript 代码是运行在 nwjs 中，是由 Chrome Webview 来渲染的

!function (global) {
  // ServiceJSBridge 对象兼容层
  if (typeof logxx === 'function' && logxx('jsbridge start'), !global.ServiceJSBridge) {
    var hasDocument = global.hasOwnProperty('document'),
        isIOS = !1,
        callbacks = {},
        callbackIndex = 0,
        defaultEventHandlers = {},
        eventPrefix = 'custom_event_',
        handlers = {},
        PROTOCAL = 'FinChat',
        IFRAME_PREFIX = 'hybridjsbrige_';
    if (hasDocument) {
      var userAgent = global.navigator.userAgent,
          isAndroid = userAgent.indexOf('Android') != -1;
      isIOS = !isAndroid;
    }
    var utils = {
      parseData: function parseData(str) {
        var result;
        if (str && typeof str === 'string') {
          try {
            result = JSON.parse(str);
          } catch (e) {
            result = {
              status: {
                code: 1,
                msg: 'PARAM_PARSE_ERROR'
              }
            };
          }
        } else {
          result = str || {};
        }
        return result;
      }
    };
    var postMessage = function postMessage(event, paramsString, callbackId) {
      // postMessage
      if (isIOS) {
        global.webkit.messageHandlers.invokeHandler.postMessage({
          C: event,
          paramsString: paramsString,
          callbackId: callbackId
        });
      } else {
        var jsCoreHandleResult = FinChatJSCore.invokeHandler(event, paramsString, callbackId);
        if (typeof jsCoreHandleResult !== 'undefined' && typeof callbacks[callbackId] === 'function' && jsCoreHandleResult !== '') {
          try {
            jsCoreHandleResult = JSON.parse(jsCoreHandleResult);
          } catch (e) {
            jsCoreHandleResult = {};
          }
          callbacks[callbackId](jsCoreHandleResult), delete callbacks[callbackId];
        }
      }
    },
        createIframe = function createIframe(uri, sid) {
      var iframe = document.createElement('iframe'),
          iframeId = IFRAME_PREFIX + sid;
      iframe.style.display = 'none';
      iframe.setAttribute('id', iframeId);
      iframe.setAttribute('frameborder', '0');
      iframe.setAttribute('src', uri);
      document.documentElement.appendChild(iframe);
      // this.messageIframe = messageIframe
    },
        retrieveIframe = function retrieveIframe(sid) {
      var iframeId = IFRAME_PREFIX + sid,
          iframe = document.querySelector('#' + iframeId);
      if (iframe) {
        document.documentElement.removeChild(iframe);
      }
    },
        publishHandler = function publishHandler(event, paramsString, webviewIds) {
      // publishHandler
      isIOS ? global.webkit.messageHandlers.publishHandler.postMessage({
        event: event,
        paramsString: paramsString,
        webviewIds: webviewIds
      }) : FinChatJSCore.publishHandler(event, paramsString, webviewIds);
    },
        invoke = function invoke(event, params, callback) {
      // postMessage
      var paramsString = (0, _stringify2.default)(params || {}),
          callbackId = ++callbackIndex;
      // reportLog(event,params,'','invoke');
      callbacks[callbackId] = callback;
      postMessage(event, paramsString, callbackId);
    },
        invokeCallbackHandler = function invokeCallbackHandler(callbackId, params) {
      var callback = callbacks[callbackId];
      // reportLog('invokeCallbackHandler:'+callbackId,params,'','api2app2service_get');
      typeof callback === 'function' && callback(params), delete callbacks[callbackId];
      if (isIOS) retrieveIframe(callbackId);
    },
        oldCallbackHandler = function oldCallbackHandler(data) {
      // {"bridgeParam":{"action":"call","callbackID":"1468927578039","status":{"status_code":-5,"status_reason":"'module' or 'identifier' is unsupported."}}}
      if (data) {
        if (typeof data === 'string') {
          data = utils.parseData(data);
        }
        var callbackId = data.bridgeParam.callbackID;
        // 延迟是为了避免：
        // 在 ios 中，如果 onComplete 回调中有 alert 等有阻塞作用的代码时，会导致页面“卡死”（Native UI层级覆盖导致点击无效）
        if (callbackId) {
          setTimeout(function () {
            invokeCallbackHandler(callbackId, data.param);
          }, 1);
        }
      }
    },
        publishCallbackHandler = function publishCallbackHandler(callbackId) {
      if (isIOS) retrieveIframe(callbackId);
    },
        on = function on(eventName, handler) {
      defaultEventHandlers[eventName] = handler;
    },
        publish = function publish(eventName, params, webviewIds) {
      // publishHandler
      webviewIds = webviewIds || [];
      var paramsString,
          event = eventPrefix + eventName;

      paramsString = (0, _stringify2.default)(params);
      webviewIds = (0, _stringify2.default)(webviewIds);
      publishHandler(event, paramsString, webviewIds);
    },
        subscribe = function subscribe(eventName, handler) {
      handlers[eventPrefix + eventName] = handler;
    },
        subscribeHandler = function subscribeHandler(eventName, data, webviewId, reportParams) {
      // 执行注册的回调
      var handler;
      handler = eventName.indexOf(eventPrefix) != -1 ? handlers[eventName] : defaultEventHandlers[eventName];
      if (typeof handler === 'function') {
        return handler(data, webviewId, reportParams);
      }
    };
    global.ServiceJSBridge = {
      invoke: invoke,
      invokeCallbackHandler: invokeCallbackHandler,
      oldCallbackHandler: oldCallbackHandler,
      publishCallbackHandler: publishCallbackHandler,
      on: on,
      publish: publish,
      subscribe: subscribe,
      subscribeHandler: subscribeHandler
    };
  }
}(window);

/***/ }),
/* 616 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _defineProperty = __webpack_require__(105);

var _defineProperty2 = _interopRequireDefault(_defineProperty);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (obj, key, value) {
  if (key in obj) {
    (0, _defineProperty2.default)(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
};

/***/ }),
/* 617 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _keys = __webpack_require__(37);

var _keys2 = _interopRequireDefault(_keys);

var _classCallCheck2 = __webpack_require__(23);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(29);

var _createClass3 = _interopRequireDefault(_createClass2);

var _utils = __webpack_require__(79);

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Animation = function () {
    function Animation() {
        (0, _classCallCheck3.default)(this, Animation);

        var option = arguments.length <= 0 ? undefined : arguments[0];
        this.actions = [];
        this.currentTransform = [];
        this.currentStepAnimates = [];
        this.option = {
            transition: {
                duration: typeof option.duration !== 'undefined' ? option.duration : 400,
                timingFunction: typeof option.timingFunction !== 'undefined' ? option.timingFunction : 'linear',
                delay: typeof option.delay !== 'undefined' ? option.delay : 0
            },
            transformOrigin: option.transformOrigin || '50% 50% 0'
        };
    }

    (0, _createClass3.default)(Animation, [{
        key: 'export',
        value: function _export() {
            var temp = this.actions;
            this.actions = [];
            return { actions: temp };
        }
    }, {
        key: 'step',
        value: function step() {
            var that = this,
                params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};

            this.currentStepAnimates.forEach(function (animate) {
                animate.type !== 'style' ? that.currentTransform[animate.type] = animate : that.currentTransform[animate.type + '.' + animate.args[0]] = animate;
            });
            this.actions.push({
                animates: (0, _keys2.default)(this.currentTransform).reduce(function (res, cur) {
                    return [].concat(_utils2.default.toArray(res), [that.currentTransform[cur]]);
                }, []),
                option: {
                    transformOrigin: typeof params.transformOrigin !== 'undefined' ? params.transformOrigin : this.option.transformOrigin,
                    transition: {
                        duration: typeof params.duration !== 'undefined' ? params.duration : this.option.transition.duration,
                        timingFunction: typeof params.timingFunction !== 'undefined' ? params.timingFunction : this.option.transition.timingFunction,
                        delay: typeof params.delay !== 'undefined' ? params.delay : this.option.transition.delay
                    }
                }
            });
            this.currentStepAnimates = [];
            return this;
        }
    }, {
        key: 'matrix',
        value: function matrix() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1,
                r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1,
                i = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 1;
            this.currentStepAnimates.push({
                type: 'matrix',
                args: [e, t, n, o, r, i]
            });
            return this;
        }
    }, {
        key: 'matrix3d',
        value: function matrix3d() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
                r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0,
                i = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 1,
                a = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 0,
                s = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 0,
                c = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 0,
                u = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : 0,
                f = arguments.length > 10 && void 0 !== arguments[10] ? arguments[10] : 1,
                l = arguments.length > 11 && void 0 !== arguments[11] ? arguments[11] : 0,
                d = arguments.length > 12 && void 0 !== arguments[12] ? arguments[12] : 0,
                p = arguments.length > 13 && void 0 !== arguments[13] ? arguments[13] : 0,
                h = arguments.length > 14 && void 0 !== arguments[14] ? arguments[14] : 0,
                v = arguments.length > 15 && void 0 !== arguments[15] ? arguments[15] : 1;
            this.currentStepAnimates.push({
                type: 'matrix3d',
                args: [e, t, n, o, r, i, a, s, c, u, f, l, d, p, h, v]
            });
            this.stepping = !1;
            return this;
        }
    }, {
        key: 'rotate',
        value: function rotate() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'rotate',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'rotate3d',
        value: function rotate3d() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
            this.currentStepAnimates.push({
                type: 'rotate3d',
                args: [e, t, n, o]
            });
            this.stepping = !1;
            return this;
        }
    }, {
        key: 'rotateX',
        value: function rotateX() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'rotateX',
                args: [e]
            });
            this.stepping = !1;
            return this;
        }
    }, {
        key: 'rotateY',
        value: function rotateY() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'rotateY',
                args: [e]
            });
            this.stepping = !1;
            return this;
        }
    }, {
        key: 'rotateZ',
        value: function rotateZ() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'rotateZ',
                args: [e]
            });
            this.stepping = !1;
            return this;
        }
    }, {
        key: 'scale',
        value: function scale() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
                t = arguments[1];
            t = typeof t !== 'undefined' ? t : e;
            this.currentStepAnimates.push({
                type: 'scale',
                args: [e, t]
            });
            return this;
        }
    }, {
        key: 'scale3d',
        value: function scale3d() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
            this.currentStepAnimates.push({
                type: 'scale3d',
                args: [e, t, n]
            });
            return this;
        }
    }, {
        key: 'scaleX',
        value: function scaleX() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
            this.currentStepAnimates.push({
                type: 'scaleX',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'scaleY',
        value: function scaleY() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
            this.currentStepAnimates.push({
                type: 'scaleY',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'scaleZ',
        value: function scaleZ() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
            this.currentStepAnimates.push({
                type: 'scaleZ',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'skew',
        value: function skew() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
            this.currentStepAnimates.push({
                type: 'skew',
                args: [e, t]
            });
            return this;
        }
    }, {
        key: 'skewX',
        value: function skewX() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'skewX',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'skewY',
        value: function skewY() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'skewY',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'translate',
        value: function translate() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
            this.currentStepAnimates.push({
                type: 'translate',
                args: [e, t]
            });
            return this;
        }
    }, {
        key: 'translate3d',
        value: function translate3d() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
            this.currentStepAnimates.push({
                type: 'translate3d',
                args: [e, t, n]
            });
            return this;
        }
    }, {
        key: 'translateX',
        value: function translateX() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'translateX',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'translateY',
        value: function translateY() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'translateY',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'translateZ',
        value: function translateZ() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'translateZ',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'opacity',
        value: function opacity(e) {
            this.currentStepAnimates.push({
                type: 'style',
                args: ['opacity', e]
            });
            return this;
        }
    }, {
        key: 'backgroundColor',
        value: function backgroundColor(e) {
            this.currentStepAnimates.push({
                type: 'style',
                args: ['backgroundColor', e]
            });
            return this;
        }
    }, {
        key: 'width',
        value: function width(e) {
            typeof e === 'number' && (e += 'px');
            this.currentStepAnimates.push({
                type: 'style',
                args: ['width', e]
            });
            return this;
        }
    }, {
        key: 'height',
        value: function height(e) {
            typeof e === 'number' && (e += 'px');
            this.currentStepAnimates.push({
                type: 'style',
                args: ['height', e]
            });
            return this;
        }
    }, {
        key: 'left',
        value: function left(e) {
            typeof e === 'number' && (e += 'px');
            this.currentStepAnimates.push({
                type: 'style',
                args: ['left', e]
            });
            return this;
        }
    }, {
        key: 'right',
        value: function right(e) {
            typeof e === 'number' && (e += 'px');
            this.currentStepAnimates.push({
                type: 'style',
                args: ['right', e]
            });
            return this;
        }
    }, {
        key: 'top',
        value: function top(e) {
            typeof e === 'number' && (e += 'px');
            this.currentStepAnimates.push({
                type: 'style',
                args: ['top', e]
            });
            return this;
        }
    }, {
        key: 'bottom',
        value: function bottom(e) {
            typeof e === 'number' && (e += 'px');
            this.currentStepAnimates.push({
                type: 'style',
                args: ['bottom', e]
            });
            return this;
        }
    }]);
    return Animation;
}();

exports.default = Animation;

/***/ }),
/* 618 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _classCallCheck2 = __webpack_require__(23);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(29);

var _createClass3 = _interopRequireDefault(_createClass2);

__webpack_require__(103);

__webpack_require__(79);

var _EventEmitter = __webpack_require__(212);

var _EventEmitter2 = _interopRequireDefault(_EventEmitter);

var _configFlags = __webpack_require__(213);

var _configFlags2 = _interopRequireDefault(_configFlags);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function createAudio(e, t) {
    var self = this,
        audioObj = new Audio(e, t);
    audioObj._getAppStatus = function () {
        return self.appStatus;
    };
    audioObj._getHanged = function () {
        return self.hanged;
    };
    this.onAppEnterBackground(function () {
        audioObj.pause();
    });
    return audioObj;
}

var audioFlags = {},
    eventEmitter2 = new _EventEmitter2.default.EventEmitter2();

ServiceJSBridge.subscribe("audioInsert", function (params, webviewId) {
    var audioId = params.audioId;
    audioFlags[webviewId + "_" + audioId] = !0;
    eventEmitter2.emit("audioInsert_" + webviewId + "_" + audioId);
});

var Audio = function () {
    function Audio(audioId, webviewId) {
        (0, _classCallCheck3.default)(this, Audio);

        if ("string" != typeof audioId) throw new Error("audioId should be a String");
        this.audioId = audioId;
        this.webviewId = webviewId;
    }

    (0, _createClass3.default)(Audio, [{
        key: 'setSrc',
        value: function setSrc(data) {
            this._sendAction({
                method: "setSrc",
                data: data
            });
        }
    }, {
        key: 'play',
        value: function play() {
            var status = this._getAppStatus();
            this._getHanged();
            status === _configFlags2.default.AppStatus.BACK_GROUND || this._sendAction({
                method: "play"
            });
        }
    }, {
        key: 'pause',
        value: function pause() {
            this._sendAction({
                method: "pause"
            });
        }
    }, {
        key: 'seek',
        value: function seek(data) {
            this._sendAction({
                method: "setCurrentTime",
                data: data
            });
        }
    }, {
        key: '_ready',
        value: function _ready(fn) {
            audioFlags[this.webviewId + "_" + this.audioId] ? fn() : eventEmitter2.on("audioInsert_" + this.webviewId + "_" + this.audioId, function () {
                fn();
            });
        }
    }, {
        key: '_sendAction',
        value: function _sendAction(params) {
            var self = this;
            this._ready(function () {
                ServiceJSBridge.publish("audio_" + self.audioId + "_actionChanged", params, [self.webviewId]);
            });
        }
    }]);
    return Audio;
}();

exports.default = createAudio;

/***/ }),
/* 619 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _classCallCheck2 = __webpack_require__(23);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(29);

var _createClass3 = _interopRequireDefault(_createClass2);

var _bridge = __webpack_require__(103);

var _bridge2 = _interopRequireDefault(_bridge);

var _utils = __webpack_require__(79);

var _utils2 = _interopRequireDefault(_utils);

var _EventEmitter = __webpack_require__(212);

var _EventEmitter2 = _interopRequireDefault(_EventEmitter);

var _configFlags = __webpack_require__(213);

var _configFlags2 = _interopRequireDefault(_configFlags);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function createVideo(videoId, webviewId) {
  var self = this,
      videoObj = new VideoControl(videoId, webviewId);
  videoObj._getAppStatus = function () {
    return self.appStatus;
  };
  videoObj._getHanged = function () {
    return self.hanged;
  };
  this.onAppEnterBackground(function () {
    videoObj.pause();
  });
  return videoObj;
}

var notIOS = _utils2.default.getPlatform() !== 'ios',
    videoPlayerIds = {},
    EventEmitter = new _EventEmitter2.default.EventEmitter2();

ServiceJSBridge.subscribe('videoPlayerInsert', function (params, t) {
  var domId = params.domId,
      videoPlayerId = params.videoPlayerId;
  videoPlayerIds[domId] = videoPlayerIds[domId] || videoPlayerId;
  EventEmitter.emit('videoPlayerInsert', domId);
});

ServiceJSBridge.subscribe('videoPlayerRemoved', function (params, t) {
  var domId = params.domId;
  params.videoPlayerId;
  delete videoPlayerIds[domId];
});

var VideoControl = function () {
  function VideoControl(videoId, webviewId) {
    (0, _classCallCheck3.default)(this, VideoControl);

    if (typeof videoId !== 'string') {
      throw new Error('video ID should be a String');
    }
    this.domId = videoId;
    this.webviewId = webviewId;
  }

  (0, _createClass3.default)(VideoControl, [{
    key: 'play',
    value: function play() {
      var appStatus = this._getAppStatus();
      appStatus === _configFlags2.default.AppStatus.BACK_GROUND || appStatus === _configFlags2.default.AppStatus.LOCK || this._invokeMethod('play');
    }
  }, {
    key: 'pause',
    value: function pause() {
      this._invokeMethod('pause');
    }
  }, {
    key: 'seek',
    value: function seek(e) {
      this._invokeMethod('seek', [e]);
    }
  }, {
    key: 'sendDanmu',
    value: function sendDanmu(params) {
      var text = params.text,
          color = params.color;
      this._invokeMethod('sendDanmu', [text, color]);
    }
  }, {
    key: '_invokeMethod',
    value: function _invokeMethod(type, data) {
      this.action = { method: type, data: data };
      this._sendAction();

      // function invoke () {
      //   // notIOS
      //   //   ? ((this.action = { method: type, data: data }), this._sendAction())
      //   //   : pubsub.invokeMethod('operateVideoPlayer', {
      //   //     data: data,
      //   //     videoPlayerId: videoPlayerIds[this.domId],
      //   //     type: type
      //   //   })
      // }
      // var self = this
      // typeof videoPlayerIds[this.domId] === 'number'
      //   ? invoke.apply(this)
      //   : EventEmitter.on('videoPlayerInsert', function (e) {
      //     invoke.apply(self)
      //   })
    }
  }, {
    key: '_sendAction',
    value: function _sendAction() {
      ServiceJSBridge.publish('video_' + this.domId + '_actionChanged', this.action, [this.webviewId]);
    }
  }]);
  return VideoControl;
}();

exports.default = createVideo;

/***/ }),
/* 620 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _classCallCheck2 = __webpack_require__(23);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(29);

var _createClass3 = _interopRequireDefault(_createClass2);

var _bridge = __webpack_require__(103);

var _bridge2 = _interopRequireDefault(_bridge);

var _utils = __webpack_require__(79);

var _utils2 = _interopRequireDefault(_utils);

var _EventEmitter = __webpack_require__(212);

var _EventEmitter2 = _interopRequireDefault(_EventEmitter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function notifyWebviewIdtoMap(e) {
    webviewID = e;
} //1-8 map相关事件和方法

var mapIds = {},
    mapInfo = {},
    EventEmitter = new _EventEmitter2.default.EventEmitter2(),
    webviewID = 0,
    callbackIndex = 0;

ServiceJSBridge.subscribe("mapInsert", function (params, viewId) {
    var domId = params.domId,
        mapId = params.mapId,
        bindregionchange = params.bindregionchange,
        bindtap = params.bindtap,
        showLocation = params.showLocation,
        key = viewId + "_" + domId;
    mapIds[key] = mapIds[key] || mapId;

    mapInfo[viewId + "_" + mapId] = {
        bindregionchange: bindregionchange,
        bindtap: bindtap,
        showLocation: showLocation
    };
    EventEmitter.emit("mapInsert");
});

var MapContext = function () {
    function MapContext(mapId) {
        (0, _classCallCheck3.default)(this, MapContext);

        var that = this;
        if ("string" != typeof mapId) throw new Error("map ID should be a String");
        this.domId = mapId;

        ServiceJSBridge.subscribe("doMapActionCallback", function (event, t) {
            var callbackId = event.callbackId;
            "getMapCenterLocation" === event.method && callbackId && "function" == typeof that[callbackId] && (that[callbackId]({
                longitude: event.longitude,
                latitude: event.latitude
            }), delete that[callbackId]);
        });
    }

    (0, _createClass3.default)(MapContext, [{
        key: '_invoke',
        value: function _invoke(methodName, params) {
            var platform = _utils2.default.getPlatform();
            if ("ios" === platform || "android" === platform) {
                var curMapInfo = mapInfo[webviewID + "_" + params.mapId];
                if ("moveToMapLocation" === methodName) {
                    return void (curMapInfo && curMapInfo.showLocation ? _bridge2.default.invokeMethod(methodName, params) : console.error("only show-location set to true can invoke moveToLocation"));
                }
                _bridge2.default.invokeMethod(methodName, params);
            } else {
                params.method = methodName;
                var callbackId = "callback" + webviewID + "_" + params.mapId + "_" + callbackIndex++;
                this[callbackId] = params.success;
                params.callbackId = callbackId;
                _bridge2.default.publish("doMapAction" + params.mapId, params, [webviewID]);
            }
        }
    }, {
        key: '_invokeMethod',
        value: function _invokeMethod(name, params) {
            var self = this,
                index = webviewID + "_" + this.domId;
            "number" == typeof mapIds[index] || mapIds[index] ? (params.mapId = mapIds[index], this._invoke(name, params)) : EventEmitter.on("mapInsert", function () {
                params.mapId = mapIds[index];
                self._invoke(name, params);
            });
        }
    }, {
        key: 'getCenterLocation',
        value: function getCenterLocation() {
            var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            this._invokeMethod("getMapCenterLocation", params);
        }
    }, {
        key: 'moveToLocation',
        value: function moveToLocation() {
            var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            this._invokeMethod("moveToMapLocation", params);
        }
    }]);
    return MapContext;
}();

exports.default = {
    notifyWebviewIdtoMap: notifyWebviewIdtoMap,
    MapContext: MapContext, //class
    mapInfo: mapInfo
};

/***/ }),
/* 621 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
// module14 predefinedColor

var predefinedColor = exports.predefinedColor = {
    aliceblue: "#f0f8ff",
    antiquewhite: "#faebd7",
    aqua: "#00ffff",
    aquamarine: "#7fffd4",
    azure: "#f0ffff",
    beige: "#f5f5dc",
    bisque: "#ffe4c4",
    black: "#000000",
    blanchedalmond: "#ffebcd",
    blue: "#0000ff",
    blueviolet: "#8a2be2",
    brown: "#a52a2a",
    burlywood: "#deb887",
    cadetblue: "#5f9ea0",
    chartreuse: "#7fff00",
    chocolate: "#d2691e",
    coral: "#ff7f50",
    cornflowerblue: "#6495ed",
    cornsilk: "#fff8dc",
    crimson: "#dc143c",
    cyan: "#00ffff",
    darkblue: "#00008b",
    darkcyan: "#008b8b",
    darkgoldenrod: "#b8860b",
    darkgray: "#a9a9a9",
    darkgrey: "#a9a9a9",
    darkgreen: "#006400",
    darkkhaki: "#bdb76b",
    darkmagenta: "#8b008b",
    darkolivegreen: "#556b2f",
    darkorange: "#ff8c00",
    darkorchid: "#9932cc",
    darkred: "#8b0000",
    darksalmon: "#e9967a",
    darkseagreen: "#8fbc8f",
    darkslateblue: "#483d8b",
    darkslategray: "#2f4f4f",
    darkslategrey: "#2f4f4f",
    darkturquoise: "#00ced1",
    darkviolet: "#9400d3",
    deeppink: "#ff1493",
    deepskyblue: "#00bfff",
    dimgray: "#696969",
    dimgrey: "#696969",
    dodgerblue: "#1e90ff",
    firebrick: "#b22222",
    floralwhite: "#fffaf0",
    forestgreen: "#228b22",
    fuchsia: "#ff00ff",
    gainsboro: "#dcdcdc",
    ghostwhite: "#f8f8ff",
    gold: "#ffd700",
    goldenrod: "#daa520",
    gray: "#808080",
    grey: "#808080",
    green: "#008000",
    greenyellow: "#adff2f",
    honeydew: "#f0fff0",
    hotpink: "#ff69b4",
    indianred: "#cd5c5c",
    indigo: "#4b0082",
    ivory: "#fffff0",
    khaki: "#f0e68c",
    lavender: "#e6e6fa",
    lavenderblush: "#fff0f5",
    lawngreen: "#7cfc00",
    lemonchiffon: "#fffacd",
    lightblue: "#add8e6",
    lightcoral: "#f08080",
    lightcyan: "#e0ffff",
    lightgoldenrodyellow: "#fafad2",
    lightgray: "#d3d3d3",
    lightgrey: "#d3d3d3",
    lightgreen: "#90ee90",
    lightpink: "#ffb6c1",
    lightsalmon: "#ffa07a",
    lightseagreen: "#20b2aa",
    lightskyblue: "#87cefa",
    lightslategray: "#778899",
    lightslategrey: "#778899",
    lightsteelblue: "#b0c4de",
    lightyellow: "#ffffe0",
    lime: "#00ff00",
    limegreen: "#32cd32",
    linen: "#faf0e6",
    magenta: "#ff00ff",
    maroon: "#800000",
    mediumaquamarine: "#66cdaa",
    mediumblue: "#0000cd",
    mediumorchid: "#ba55d3",
    mediumpurple: "#9370db",
    mediumseagreen: "#3cb371",
    mediumslateblue: "#7b68ee",
    mediumspringgreen: "#00fa9a",
    mediumturquoise: "#48d1cc",
    mediumvioletred: "#c71585",
    midnightblue: "#191970",
    mintcream: "#f5fffa",
    mistyrose: "#ffe4e1",
    moccasin: "#ffe4b5",
    navajowhite: "#ffdead",
    navy: "#000080",
    oldlace: "#fdf5e6",
    olive: "#808000",
    olivedrab: "#6b8e23",
    orange: "#ffa500",
    orangered: "#ff4500",
    orchid: "#da70d6",
    palegoldenrod: "#eee8aa",
    palegreen: "#98fb98",
    paleturquoise: "#afeeee",
    palevioletred: "#db7093",
    papayawhip: "#ffefd5",
    peachpuff: "#ffdab9",
    peru: "#cd853f",
    pink: "#ffc0cb",
    plum: "#dda0dd",
    powderblue: "#b0e0e6",
    purple: "#800080",
    rebeccapurple: "#663399",
    red: "#ff0000",
    rosybrown: "#bc8f8f",
    royalblue: "#4169e1",
    saddlebrown: "#8b4513",
    salmon: "#fa8072",
    sandybrown: "#f4a460",
    seagreen: "#2e8b57",
    seashell: "#fff5ee",
    sienna: "#a0522d",
    silver: "#c0c0c0",
    skyblue: "#87ceeb",
    slateblue: "#6a5acd",
    slategray: "#708090",
    slategrey: "#708090",
    snow: "#fffafa",
    springgreen: "#00ff7f",
    steelblue: "#4682b4",
    tan: "#d2b48c",
    teal: "#008080",
    thistle: "#d8bfd8",
    tomato: "#ff6347",
    turquoise: "#40e0d0",
    violet: "#ee82ee",
    wheat: "#f5deb3",
    white: "#ffffff",
    whitesmoke: "#f5f5f5",
    yellow: "#ffff00",
    yellowgreen: "#9acd32"
};

/***/ }),
/* 622 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _assign = __webpack_require__(66);

var _assign2 = _interopRequireDefault(_assign);

var _keys = __webpack_require__(37);

var _keys2 = _interopRequireDefault(_keys);

var _stringify = __webpack_require__(36);

var _stringify2 = _interopRequireDefault(_stringify);

exports.set = set;
exports.setStorage = setStorage;
exports.get = get;
exports.getStorage = getStorage;
exports.clearStorageSync = clearStorageSync;
exports.clearStorage = clearStorage;
exports.remove = remove;
exports.removeStorage = removeStorage;
exports.getStorageInfo = getStorageInfo;
exports.getStorageInfoSync = getStorageInfoSync;

var _emitter = __webpack_require__(151);

var _emitter2 = _interopRequireDefault(_emitter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// 5MB
var LIMIT_SIZE = 5 * 1024;

var directory = '__FinChat__storage__';

function currentSize() {
  var total = 0;
  for (var x in localStorage) {
    var amount = localStorage[x].length * 2 / 1024;
    total += amount;
  }
  return Math.ceil(total);
}

var storage = {
  set: function set(key, value) {
    if (window.localStorage == null) {
      return console.error('localStorage not supported');
    }
    var str = localStorage.getItem(directory);
    var obj = void 0;
    obj = str ? JSON.parse(str) : {};
    obj[key] = value;
    localStorage.setItem(directory, (0, _stringify2.default)(obj));
    this.emit('change');
  },
  get: function get(key) {
    if (window.localStorage == null) {
      return console.error('localStorage not supported');
    }
    var str = localStorage.getItem(directory);
    var obj = void 0;
    obj = str ? JSON.parse(str) : {};
    return {
      data: obj[key]
    };
  },
  remove: function remove(key) {
    if (window.localStorage == null) {
      return console.error('localStorage not supported');
    }
    var str = localStorage.getItem(directory);
    if (!str) return;
    var obj = JSON.parse(str);
    var data = obj[key];
    delete obj[key];
    localStorage.setItem(directory, (0, _stringify2.default)(obj));
    this.emit('change');
    return data;
  },
  clear: function clear() {
    if (window.localStorage == null) {
      return console.error('localStorage not supported');
    }
    localStorage.removeItem(directory);
    this.emit('change');
  },
  getAll: function getAll() {
    if (window.localStorage == null) {
      return console.error('localStorage not supported');
    }
    var str = localStorage.getItem(directory);
    var obj = str ? JSON.parse(str) : {};
    var res = {};
    (0, _keys2.default)(obj).forEach(function (key) {
      res[key] = {
        data: obj[key]
      };
    });
    return res;
  },
  info: function info() {
    if (window.localStorage == null) {
      return console.error('localStorage not supported');
    }
    var str = localStorage.getItem(directory);
    var obj = str ? JSON.parse(str) : {};
    return {
      keys: (0, _keys2.default)(obj),
      limitSize: LIMIT_SIZE,
      currentSize: currentSize()
    };
  }
};

(0, _emitter2.default)(storage);

function toResult(msg, data, command) {
  var obj = {
    ext: data, // 传过来的数据
    msg: msg // 调用api返回的结果
  };
  if (command) obj.command = command;
  return obj;
}

function toError(data) {
  var result = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
  var extra = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

  // let name = data.sdkName.replace(/Sync$/, '')
  var name = data.sdkName;
  var obj = (0, _assign2.default)({
    errMsg: name + ':fail'
  }, extra);
  return toResult(obj, data, result ? 'GET_ASSDK_RES' : null);
}

function toSuccess(data) {
  var result = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
  var extra = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

  // let name = data.sdkName.replace(/Sync$/, '')
  var name = data.sdkName;
  var obj = (0, _assign2.default)({
    errMsg: name + ':ok'
  }, extra);
  return toResult(obj, data, result ? 'GET_ASSDK_RES' : null);
}

function set(key, data) {
  storage.set(key, data);
}

function setStorage(args) {
  var res = {
    errMsg: 'setStorage:ok'
  };
  if (args.key === undefined || args.data === undefined) {
    args.fail && args.fail(args);
  }
  storage.set(args.key, args.data);
  args.success && args.success(res);
  args.complete && args.complete(res);
}

function get(key) {
  return storage.get(key);
}

function getStorage(args) {
  if (args.key == null) {
    args.fail && args.fail();
  }
  var rt = storage.get(args.key);
  var res = null;
  if (rt.data === undefined) {
    res = {
      errMsg: 'getStorage:fail data not found'
    };
    args.fail && args.fail(res);
  } else {
    res = rt;
    args.success && args.success(res);
  }
  args.complete && args.complete(res);
}

function clearStorageSync(data) {
  storage.clear();
}

function clearStorage(data) {
  storage.clear();
}

function remove(key) {
  storage.remove(key);
}

function removeStorage(args) {
  if (args.key == null) {
    args.fail && args.fail();
  }
  storage.remove(args.key);
  args.success && args.success();
  args.complete && args.complete();
}

function getStorageInfo(args) {
  var obj = storage.info();
  args.success && args.success(obj);
  args.complete && args.complete(obj);
}

function getStorageInfoSync() {
  var obj = storage.info();
  return obj;
}

/***/ }),
/* 623 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _bridge = __webpack_require__(103);

var _bridge2 = _interopRequireDefault(_bridge);

var _EventEmitter = __webpack_require__(212);

var _EventEmitter2 = _interopRequireDefault(_EventEmitter);

var _configFlags = __webpack_require__(213);

var _configFlags2 = _interopRequireDefault(_configFlags);

var _utils = __webpack_require__(79);

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//1-15 绑定AppEnterForeground与AppEnterBackground

var eventEmitter = new _EventEmitter2.default();
_bridge2.default.onMethod("onAppEnterForeground", function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  eventEmitter.emit("onAppEnterForeground", params);
});
_bridge2.default.onMethod("onAppEnterBackground", function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  eventEmitter.emit("onAppEnterBackground", params);
});
_bridge2.default.onMethod("onAppRunningStatusChange", function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  _utils2.default.defaultRunningStatus = params.status;
  eventEmitter.emit("onAppRunningStatusChange", params);
});

var onAppEnterForeground = function onAppEnterForeground(fn) {
  var self = this;
  "function" == typeof fn && setTimeout(fn, 0);
  eventEmitter.on("onAppEnterForeground", function (params) {
    _bridge2.default.publish("onAppEnterForeground", params), self.appStatus = _configFlags2.default.AppStatus.FORE_GROUND, "function" == typeof fn && fn(params);
  });
};

var onAppEnterBackground = function onAppEnterBackground(fn) {
  var self = this;
  eventEmitter.on("onAppEnterBackground", function (params) {
    params = params || {};
    _bridge2.default.publish("onAppEnterBackground", params);
    "hide" === params.mode ? self.appStatus = _configFlags2.default.AppStatus.LOCK : self.appStatus = _configFlags2.default.AppStatus.BACK_GROUND, "close" === params.mode ? self.hanged = !1 : "hang" === params.mode && (self.hanged = !0), "function" == typeof fn && fn(params);
  });
};
var onAppRunningStatusChange = function onAppRunningStatusChange(fn) {
  eventEmitter.on("onAppRunningStatusChange", function (params) {
    "function" == typeof fn && fn(params);
  });
};

exports.default = {
  onAppEnterForeground: onAppEnterForeground,
  onAppEnterBackground: onAppEnterBackground,
  onAppRunningStatusChange: onAppRunningStatusChange
};

/***/ }),
/* 624 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _classCallCheck2 = __webpack_require__(23);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(29);

var _createClass3 = _interopRequireDefault(_createClass2);

var _bridge = __webpack_require__(103);

var _bridge2 = _interopRequireDefault(_bridge);

var _utils = __webpack_require__(79);

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var socketId = 1;

var SocketTask = function () {
  function SocketTask(params) {
    (0, _classCallCheck3.default)(this, SocketTask);

    this.socketId = socketId++;
    this.websocket = new WebSocket(params.url);
    this.websocket.onopen = function (evt) {
      this.readyState = 1;
      if (typeof this.onOpenCallback === 'function') {
        this.onOpenCallback(evt);
      }
    }.bind(this);
    this.websocket.onclose = function (evt) {
      this.readyState = 3;
      this.onCloseCallback({ code: evt.code, reason: evt.reason });
    }.bind(this);
    this.websocket.onmessage = function (evt) {
      this.onMessageCallback({ data: evt.data });
    }.bind(this);
    this.websocket.onerror = function (evt) {
      this.onErrorCallback(evt);
    }.bind(this);
  }

  (0, _createClass3.default)(SocketTask, [{
    key: 'onOpen',
    value: function onOpen(callback) {
      this.onOpenCallback = callback;
      // bridge.onMethod('onSocketOpen',callback)
    }
  }, {
    key: 'onClose',
    value: function onClose(callback) {
      this.onCloseCallback = callback;
      // bridge.onMethod('onSocketClose',callback)
    }
  }, {
    key: 'onError',
    value: function onError(callback) {
      this.onErrorCallback = callback;
      // bridge.onMethod('onSocketError',callback)
    }
  }, {
    key: 'onMessage',
    value: function onMessage(callback) {
      this.onMessageCallback = callback;
      // bridge.onMethod('onSocketMessage',callback)
    }

    /**
     * 
     * @param {Object} param 
     * {
     *  data: [string/ArrayBuffer],
     *  success: function() {},
     *  fail: function() {},
     *  complete: function() {}
     * }
     */

  }, {
    key: 'send',
    value: function send(param) {
      this.websocket.send(param.data);
      // var paramType = utils.getDataType(params.data)
      // if (paramType === 'String') {
      //   bridge.invokeMethod('sendSocketMessage', params)
      // } else if (aramType === 'ArrayBuffer' ) {
      //   bridge.invokeMethod('sendSocketMessage',utils.assign(params, {
      //     data: utils.arrayBufferToBase64(params.data),
      //     isBuffer: true
      //   }))
      // }
    }
    /**
     * 
     * @param {Object} param 
     * {
     *  code: 1000,
     *  reason: '',
     *  success: function() {},
     *  fail: function() {},
     *  complete: function() {}
     * }
     */

  }, {
    key: 'close',
    value: function close(param) {
      this.websocket.close();
    }
  }]);
  return SocketTask;
}();

exports.default = SocketTask;

/***/ }),
/* 625 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _typeof2 = __webpack_require__(13);

var _typeof3 = _interopRequireDefault(_typeof2);

var _common = __webpack_require__(626);

var _nextTick = __webpack_require__(508);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var userAgent = window.navigator.userAgent;
var isAndroid = userAgent.indexOf('Android') !== -1;
var isIOS = !isAndroid;
var cbQueue = [];
if (isIOS) {
  // iOS setTimeOut需要特别处理
  var callbacks = {};
  ServiceJSBridge.on('onSetTimeout', function (params, webviewId) {
    var cbId = params.timeoutID || params.callbackId || '';
    if (typeof callbacks[cbId] === 'function') {
      // callbacks[params.callbackId]()
      callbacks[cbId]();
      delete callbacks[cbId];
    }
  }, 'onSetTimeout');
  ServiceJSBridge.on('onSetInterval', function (params, webviewId) {
    var cbId = params.timeoutID || params.callbackId || '';
    if (typeof callbacks[cbId] === 'function') {
      // callbacks[params.callbackId]()
      callbacks[cbId]();
    }
  }, 'onSetInterval');

  var originalSetTimeOut = setTimeout;

  window.setTimeout = function (fn, timer) {
    if (typeof fn !== 'function') {
      throw new TypeError('setTimetout expects a function as first argument but got ' + (typeof fn === 'undefined' ? 'undefined' : (0, _typeof3.default)(fn)) + '.');
    }
    var callback = Reporter.surroundThirdByTryCatch(fn, 'at setTimeout callback function');
    // debugger
    if (timer === -1) {
      cbQueue.unshift(callback);
      return;
    }
    if (!timer) {
      // cbQueue.unshift(callback)
      // fn()
      (0, _nextTick.nextTick)(callback);
      return;
    }
    var id = (0, _common.getGlobalId)();
    callbacks[id] = callback;
    ServiceJSBridge.publish('setTimeout', {
      delay: timer,
      timeoutID: id,
      callbackId: id,
      timer: timer
    }, '');
    return id;
  };
  window.setInterval = function (fn, timer) {
    if (typeof fn !== 'function') {
      throw new TypeError('setTimetout expects a function as first argument but got ' + (typeof fn === 'undefined' ? 'undefined' : (0, _typeof3.default)(fn)) + '.');
    }
    var callback = Reporter.surroundThirdByTryCatch(fn, 'at setTimeout callback function');
    var id = (0, _common.getGlobalId)();
    callbacks[id] = callback;
    if (!timer) {
      timer = 1000;
    }
    ServiceJSBridge.publish('setInterval', {
      delay: timer,
      timeoutID: id,
      callbackId: id,
      timer: timer
    }, '');
    return id;
  };
  window.clearTimeout = function (timerId) {
    ServiceJSBridge.publish('clearTimeout', timerId, '');
    for (var i in callbacks) {
      if (i === timerId) {
        delete callbacks[i];
        break;
      }
    }
  };
  window.clearInterval = function (timerId) {
    ServiceJSBridge.publish('clearTimeout', timerId, '');
    for (var i in callbacks) {
      if (i === timerId) {
        delete callbacks[i];
        break;
      }
    }
  };
  var cbQueueId = (0, _common.getGlobalId)();
  callbacks[cbQueueId] = function () {
    var cb = cbQueue.pop();
    if (cb) {
      cb();
    }
  };
  ServiceJSBridge.publish('setInterval', {
    delay: 100,
    timeoutID: cbQueueId
  }, '');
} else {
  var originalSetTimeOut = setTimeout;
  window.setTimeout = function (fn, timer) {
    if (typeof fn !== 'function') {
      throw new TypeError('setTimetout expects a function as first argument but got ' + (typeof fn === 'undefined' ? 'undefined' : (0, _typeof3.default)(fn)) + '.');
    }
    var callback = Reporter.surroundThirdByTryCatch(fn, 'at setTimeout callback function');
    return originalSetTimeOut(callback, timer);
  };
  var originalSetInterval = setInterval;
  window.setInterval = function (fn, timer) {
    if (typeof fn !== 'function') {
      throw new TypeError('setInterval expects a function as first argument but got ' + (typeof fn === 'undefined' ? 'undefined' : (0, _typeof3.default)(fn)) + '.');
    }
    Reporter.surroundThirdByTryCatch(fn, 'at setInterval callback function');
    return originalSetInterval(fn, timer);
  };
}

/***/ }),
/* 626 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getGlobalId = getGlobalId;
var globalId = 1;

function getGlobalId() {
    return globalId++;
}

/***/ }),
/* 627 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


if ("undefined" == typeof navigator) {
    try {
        eval("const GeneratorFunction = Object.getPrototypeOf(function *() {}).constructor; const canvas = new GeneratorFunction('', 'console.log(0)'); canvas().__proto__.__proto__.next = () => {};");
    } catch (e) {}
}

/***/ }),
/* 628 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _bridge = __webpack_require__(103);

var _bridge2 = _interopRequireDefault(_bridge);

var _utils = __webpack_require__(79);

var _utils2 = _interopRequireDefault(_utils);

var _configFlags = __webpack_require__(213);

var _configFlags2 = _interopRequireDefault(_configFlags);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

"undefined" != typeof __wxConfig__ && __wxConfig__.debug && "devtools" !== _utils2.default.getPlatform() && !function () {
    var logQueue = [],
        viewIds = [],
        consoleMethods = ["log", "warn", "error", "info", "debug"];
    consoleMethods.forEach(function (key) {
        var consoleMethod = console[key];
        console[key] = function () {
            logQueue.length > _configFlags2.default.LOG_LIMIT && logQueue.shift();
            var logArr = Array.prototype.slice.call(arguments);
            logQueue.push({
                method: key,
                log: logArr
            });

            consoleMethod.apply(console, arguments), viewIds.length > 0 && _bridge2.default.publish(key, { log: logArr }, viewIds);
        };
    });
    // pubsub.subscribe("DOMContentLoaded", function (n, viewId) {
    //     viewIds.push(viewId)
    //     pubsub.publish("initLogs", { logs: logQueue}, [viewId])
    // })
    _bridge2.default.on('DOMContentLoaded', function (params, viewId) {
        viewIds.push(viewId);
        _bridge2.default.publish("initLogs", { logs: logQueue }, [viewId]);
    });
}(), "undefined" == typeof console.group && (console.group = function () {}), "undefined" == typeof console.groupEnd && (console.groupEnd = function () {}); //1-11 线上针对debug相关函数做处理

/***/ }),
/* 629 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _pageInit = __webpack_require__(485);

var _pageInit2 = _interopRequireDefault(_pageInit);

var _initApp = __webpack_require__(640);

var _initApp2 = _interopRequireDefault(_initApp);

var _component = __webpack_require__(641);

var _component2 = _interopRequireDefault(_component);

var _parseBehavior = __webpack_require__(486);

var _parseBehavior2 = _interopRequireDefault(_parseBehavior);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// 小程序service 接口api 导出
window.Component = _component2.default.componentHolder;
window.getComponent = _component2.default.getComponent;
window.Page = _pageInit2.default.pageHolder;
window.App = _initApp2.default.appHolder;
window.getApp = _initApp2.default.getApp;
window.getCurrentPages = _pageInit2.default.getCurrentPages;
window.Behavior = _parseBehavior2.default.Behavior;

window.requirePlugin = function () {
  console.warn('not implement');
};

/***/ }),
/* 630 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _from = __webpack_require__(102);

var _from2 = _interopRequireDefault(_from);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (arr) {
  if (Array.isArray(arr)) {
    for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) {
      arr2[i] = arr[i];
    }

    return arr2;
  } else {
    return (0, _from2.default)(arr);
  }
};

/***/ }),
/* 631 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

exports.default = function (obj, keys) {
  var target = {};

  for (var i in obj) {
    if (keys.indexOf(i) >= 0) continue;
    if (!Object.prototype.hasOwnProperty.call(obj, i)) continue;
    target[i] = obj[i];
  }

  return target;
};

/***/ }),
/* 632 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof2 = __webpack_require__(13);

var _typeof3 = _interopRequireDefault(_typeof2);

var _copyUtils = __webpack_require__(633);

var _copyUtils2 = _interopRequireDefault(_copyUtils);

var _symbolHandle = __webpack_require__(634);

var _symbolHandle2 = _interopRequireDefault(_symbolHandle);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function emptyFn(e) {}
function copyHandle(data) {
    var method = arguments.length <= 1 || undefined === arguments[1] ? emptyFn : arguments[1];
    if (null === data) {
        return null;
    }
    var value = _copyUtils2.default.copyValue(data);
    if (null !== value) {
        return value;
    }
    var coll = _copyUtils2.default.copyCollection(data, method),
        newAttr = null !== coll ? coll : data,
        attrArr = [data],
        newAttrArr = [newAttr];
    return iteratorHandle(data, method, newAttr, attrArr, newAttrArr);
}
function iteratorHandle(data, method, newAttr, attrArr, newAttrArr) {
    //处理对象循环引用情况
    if (null === data) {
        return null;
    }
    var value = _copyUtils2.default.copyValue(data);
    if (null !== value) {
        return value;
    }
    var keys = _symbolHandle2.default.getKeys(data).concat(_symbolHandle2.default.getSymbols(data));
    var index, length, key, attrValue, attrValueIndex, newAttrValue, curAttrValue, tmpObj;
    for (index = 0, length = keys.length; index < length; ++index) {
        key = keys[index];
        attrValue = data[key];
        attrValueIndex = _symbolHandle2.default.indexOf(attrArr, attrValue); //确定data的子属性有没引用自身
        tmpObj = undefined;
        curAttrValue = undefined;
        newAttrValue = undefined;
        attrValueIndex === -1 ? (newAttrValue = _copyUtils2.default.copy(attrValue, method), curAttrValue = null !== newAttrValue ? newAttrValue : attrValue, null !== attrValue && /^(?:function|object)$/.test(typeof attrValue === 'undefined' ? 'undefined' : (0, _typeof3.default)(attrValue)) && (attrArr.push(attrValue), newAttrArr.push(curAttrValue))) : tmpObj = newAttrArr[attrValueIndex];
        newAttr[key] = tmpObj || iteratorHandle(attrValue, method, curAttrValue, attrArr, newAttrArr);
    }
    return newAttr;
}

exports.default = copyHandle;

/***/ }),
/* 633 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof2 = __webpack_require__(13);

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function copy(obj, customizerFn) {
    var res = copyValue(obj);
    return null !== res ? res : copyCollection(obj, customizerFn);
}
function copyCollection(obj, customizerFn) {
    if ("function" != typeof customizerFn) {
        throw new TypeError("customizer is must be a Function");
    }
    if ("function" == typeof obj) {
        return obj;
    }
    var typeString = toString.call(obj);
    if ("[object Array]" === typeString) {
        return [];
    }
    if ("[object Object]" === typeString && obj.constructor === Object) {
        return {};
    }
    if ("[object Date]" === typeString) {
        return new Date(obj.getTime());
    }
    if ("[object RegExp]" === typeString) {
        var toStr = String(obj),
            pos = toStr.lastIndexOf("/");
        return new RegExp(toStr.slice(1, pos), toStr.slice(pos + 1));
    }
    var res = customizerFn(obj);
    return undefined !== res ? res : null;
}
function copyValue(param) {
    var type = typeof param === "undefined" ? "undefined" : (0, _typeof3.default)(param);
    return null !== param && "object" !== type && "function" !== type ? param : null;
}
var toString = Object.prototype.toString;
exports.default = {
    copy: copy,
    copyCollection: copyCollection,
    copyValue: copyValue
};

/***/ }),
/* 634 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _getOwnPropertySymbols = __webpack_require__(635);

var _getOwnPropertySymbols2 = _interopRequireDefault(_getOwnPropertySymbols);

var _symbol = __webpack_require__(199);

var _symbol2 = _interopRequireDefault(_symbol);

var _typeof2 = __webpack_require__(13);

var _typeof3 = _interopRequireDefault(_typeof2);

var _keys = __webpack_require__(37);

var _keys2 = _interopRequireDefault(_keys);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function indexOf(arr, element) {
  if ('[object Array]' !== toString.call(arr)) {
    throw new TypeError('array must be an Array');
  }
  var index = void 0,
      arrLen = void 0,
      cur = void 0;
  for (index = 0, arrLen = arr.length; index < arrLen; ++index) {
    cur = arr[index];
    if (cur === element || cur !== cur && element !== element) {
      return index;
    }
  }
  return -1;
}

var toString = Object.prototype.toString;

var getKeys = void 0;

if ('function' === typeof _keys2.default) {
  getKeys = function getKeys(obj) {
    return (0, _keys2.default)(obj);
  };
} else {
  getKeys = function getKeys(obj) {
    var type = typeof obj === 'undefined' ? 'undefined' : (0, _typeof3.default)(obj);
    if (null === obj || 'function' !== type && 'object' !== type) {
      throw new TypeError('obj must be an Object');
    }
    var res = [],
        key;
    for (key in obj) {
      Object.prototype.hasOwnProperty.call(obj, key) && res.push(key);
    }
    return res;
  };
}

var getSymbols;
if ('function' === typeof _symbol2.default) {
  getSymbols = function getSymbols(e) {
    return (0, _getOwnPropertySymbols2.default)(e);
  };
} else {
  getSymbols = function getSymbols() {
    return [];
  };
}

exports.default = {
  getKeys: getKeys,
  getSymbols: getSymbols,
  indexOf: indexOf
};

/***/ }),
/* 635 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(636), __esModule: true };

/***/ }),
/* 636 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(217);
module.exports = __webpack_require__(7).Object.getOwnPropertySymbols;


/***/ }),
/* 637 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _stringify = __webpack_require__(36);

var _stringify2 = _interopRequireDefault(_stringify);

var _classCallCheck2 = __webpack_require__(23);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(29);

var _createClass3 = _interopRequireDefault(_createClass2);

var _utils = __webpack_require__(107);

var _utils2 = _interopRequireDefault(_utils);

var _parseUtils = __webpack_require__(214);

var _parseUtils2 = _interopRequireDefault(_parseUtils);

var _parsePath = __webpack_require__(509);

var parsePath = _interopRequireWildcard(_parsePath);

var _toAppView = __webpack_require__(638);

var _toAppView2 = _interopRequireDefault(_toAppView);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var ParsePage = function () {
    function ParsePage() {
        var pageObj = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        var webviewId = arguments[1];
        var routePath = arguments[2];
        var isTruePage = arguments[3];
        (0, _classCallCheck3.default)(this, ParsePage);

        this.isInit = true;
        this.isTruePage = isTruePage;
        var pageBaseAttr = {
            __wxWebviewId__: webviewId,
            __route__: routePath,
            route: routePath
        };
        _parseUtils2.default.setBaseAttrs(this, pageBaseAttr);
        pageObj.data = pageObj.data || {};
        _utils2.default.isPlainObject(pageObj.data) || _utils2.default.error("Page data error", "data must be an object, your data is " + (0, _stringify2.default)(pageObj.data));

        this.data = _utils2.default.cloneObj(pageObj.data);
        this.__query__ = pageObj.__query__;

        if (isTruePage) {
            _parseUtils2.default.copyPageObjBySysEvent(this, pageObj);
            for (var key in pageObj) {
                _parseUtils2.default.copyPageObjByKey(this, pageObj, key);
            }
        } else {
            for (var key in pageObj) {
                _parseUtils2.default.copyComponentObjByKey(this, pageObj, key);
            }
        }
        "function" == typeof pageObj.onShareAppMessage && ServiceJSBridge.invoke("showShareMenu", {}, _utils2.default.info);
    }

    (0, _createClass3.default)(ParsePage, [{
        key: 'update',
        value: function update() {
            _utils2.default.warn("将被废弃", "Page.update is deprecated, setData updates the view implicitly. [It will be removed in 2016.11]");
        }
    }, {
        key: 'forceUpdate',
        value: function forceUpdate() {
            _utils2.default.warn("将被废弃", "Page.forceUpdate is deprecated, setData updates the view implicitly. [It will be removed in 2016.11]");
        }
    }, {
        key: 'setData',
        value: function setData(dataObj, cb) {
            try {
                var type = _utils2.default.getDataType(dataObj);
                "Object" !== type && _utils2.default.error("类型错误", "setData accepts an Object rather than some " + type);
                for (var key in dataObj) {
                    parsePath.setObjectDataByPath(this.data, key, dataObj[key]);
                    // var curValue = parsePath.getObjectByPath(this.data, key),
                    //     curObj = curValue.obj,
                    //     curKey = curValue.key;
                    // curObj && (curObj[curKey] = organize(dataObj[key]));
                }
                _toAppView2.default.emit(dataObj, this.__wxWebviewId__);
                typeof cb === 'function' && cb.call(this);
            } catch (e) {
                _utils2.default.errorReport(e);
            }
        }
    }, {
        key: 'selectComponent',
        value: function selectComponent(selector) {
            if (typeof selector !== 'string') return;
            var res = _parseUtils2.default.getSelectComponent(selector, this.__wxWebviewId__);
            return Array.isArray(res) ? res[0] : null;
        }
    }, {
        key: 'selectAllComponents',
        value: function selectAllComponents(selector) {
            if (typeof selector !== 'string') return;
            var res = _parseUtils2.default.getSelectComponent(selector, this.__wxWebviewId__);
            return res || [];
        }
    }]);
    return ParsePage;
}();

exports.default = ParsePage;

/***/ }),
/* 638 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _classCallCheck2 = __webpack_require__(23);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(29);

var _createClass3 = _interopRequireDefault(_createClass2);

var _utils = __webpack_require__(107);

var _utils2 = _interopRequireDefault(_utils);

var _parseFunction = __webpack_require__(226);

var _parseFunction2 = _interopRequireDefault(_parseFunction);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var toAppView = function () {
  function toAppView() {
    (0, _classCallCheck3.default)(this, toAppView);
  }

  (0, _createClass3.default)(toAppView, null, [{
    key: 'emit',

    //   constructor () {}
    value: function emit(data, webviewId) {
      _utils2.default.publish('appDataChange', {
        data: {
          data: _parseFunction2.default.functionToString(data, webviewId)
        }
      }, [webviewId]);
    }
  }]);
  return toAppView;
}();

exports.default = toAppView;

/***/ }),
/* 639 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var DOM_READY_EVENT = "__DOMReady";
var DOM_ONLOAD_DONE = "__OnLoadDone";
var UPDATE_APP_DATA = "__updateAppData";

exports.DOM_READY_EVENT = DOM_READY_EVENT;
exports.UPDATE_APP_DATA = UPDATE_APP_DATA;
exports.DOM_ONLOAD_DONE = DOM_ONLOAD_DONE;

/***/ }),
/* 640 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _assign = __webpack_require__(66);

var _assign2 = _interopRequireDefault(_assign);

var _classCallCheck2 = __webpack_require__(23);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(29);

var _createClass3 = _interopRequireDefault(_createClass2);

var _utils = __webpack_require__(107);

var _utils2 = _interopRequireDefault(_utils);

var _pageInit = __webpack_require__(485);

var _pageInit2 = _interopRequireDefault(_pageInit);

var _parseUtils = __webpack_require__(214);

var _parseUtils2 = _interopRequireDefault(_parseUtils);

var _logReport = __webpack_require__(510);

var reportRealtimeAction = _interopRequireWildcard(_logReport);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* eslint yoda: [2, "always"] */
/* eslint-disable no-new */
/* eslint-disable no-global-assign */
/* global Reporter wx */
var events = ['onLaunch', 'onShow', 'onHide', 'onUnlaunch'];

var firstRender = true;

var launchOptions = {};

// var gSystemInfo = {}

var isSysEvent = function isSysEvent(key) {
  // 判断是否为app 事件
  for (var index = 0; index < events.length; ++index) {
    if (events[index] === key) {
      return true;
    }
  }
  return false;
};
var isGetCurrentPage = function isGetCurrentPage(key) {
  return 'getCurrentPage' === key;
};

var AppClass = function () {
  function AppClass(appObj) {
    (0, _classCallCheck3.default)(this, AppClass);
    // t:app
    var self = this;
    events.forEach(function (eventKey) {
      // 给app绑定事件
      var tempFun = function tempFun() {
        var eventFun = (appObj[eventKey] || _utils2.default.noop).bind(this);
        _utils2.default.info('App: ' + eventKey + ' have been invoked');
        try {
          eventFun.apply(this, arguments);
        } catch (t) {
          Reporter.thirdErrorReport({
            error: t,
            extend: 'App catch error in lifeCycleMethod ' + eventKey + ' function'
          });
        }
      };
      self[eventKey] = tempFun.bind(self);
    });
    var bindApp = function bindApp(attrKey) {
      // 给app绑定其它方法与属性
      isGetCurrentPage(attrKey) ? _utils2.default.warn('关键字保护', "App's " + attrKey + ' is write-protected') : isSysEvent(attrKey) || ('[object Function]' === Object.prototype.toString.call(appObj[attrKey]) ? self[attrKey] = function () {
        var method;
        try {
          method = appObj[attrKey].apply(this, arguments);
        } catch (t) {
          Reporter.thirdErrorReport({
            error: t,
            extend: 'App catch error in  ' + attrKey + ' function'
          });
        }
        return method;
      }.bind(self) : self[attrKey] = appObj[attrKey]);
    };
    for (var attrKey in appObj) {
      bindApp(attrKey);
    }

    function hide() {
      // hide
      var pages = _pageInit2.default.getCurrentPages();
      pages.length && _parseUtils2.default.doPageLifeTime(pages[pages.length - 1], 'onHide');
      this.onHide();
      reportRealtimeAction.triggerAnalytics('background', null, '小程序转到后台');
    }

    function show(e) {
      // show
      var routePath = _pageInit2.default.getCurrentPage();
      var params = (0, _assign2.default)({}, launchOptions, {
        path: routePath ? routePath.route : __wxConfig__.pages[0]
      });
      this.onShow(params);
      if (firstRender) {
        firstRender = false;
      } else {
        var pages = _pageInit2.default.getCurrentPages();
        if (pages.length) {
          _parseUtils2.default.doPageLifeTime(pages[pages.length - 1], 'onShow');
          // pages[pages.length - 1].onShow()
          reportRealtimeAction.triggerAnalytics('foreground', null, '小程序转到前台');
        }
      }
    }
    ServiceJSBridge.on('onServiceReadyDone', function (params, webviewId) {
      var pages = __wxConfig__.pages;
      var pagePath = pages[0];
      launchOptions = {
        path: params.path || pagePath,
        query: params.query || {},
        scene: params.scene || 1001,
        referrerInfo: params.referrerInfo || {}
      };
      self.onLaunch(launchOptions);
      wx.onAppEnterBackground(hide.bind(self));
      wx.onAppEnterForeground(show.bind(self));
      ServiceJSBridge.publish('onLaunchCalled', {}, [100000]);
    }, 'onServiceReadyDone');
    this.onError && Reporter.registerErrorListener(this.onError);
    reportRealtimeAction.triggerAnalytics('launch', null, '小程序启动');
  }

  (0, _createClass3.default)(AppClass, [{
    key: 'getCurrentPage',
    value: function getCurrentPage() {
      _utils2.default.warn('将被废弃', 'App.getCurrentPage is deprecated, please use getCurrentPages. [It will be removed in 2016.11]');
      var currentPage = _pageInit2.default.getCurrentPage();
      if (currentPage) {
        return currentPage.page;
      }
    }
  }]);
  return AppClass;
}();

var tempObj;

var appHolder = _utils2.default.surroundByTryCatch(function (appObj) {
  tempObj = new AppClass(appObj);
}, 'create app instance');
var getApp = function getApp() {
  return tempObj;
};
exports.default = {
  appHolder: appHolder,
  getApp: getApp
};

/***/ }),
/* 641 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__(36);

var _stringify2 = _interopRequireDefault(_stringify);

var _extends2 = __webpack_require__(225);

var _extends3 = _interopRequireDefault(_extends2);

var _keys = __webpack_require__(37);

var _keys2 = _interopRequireDefault(_keys);

var _assign = __webpack_require__(66);

var _assign2 = _interopRequireDefault(_assign);

var _classCallCheck2 = __webpack_require__(23);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(29);

var _createClass3 = _interopRequireDefault(_createClass2);

var _utils = __webpack_require__(107);

var _utils2 = _interopRequireDefault(_utils);

var _parseUtils = __webpack_require__(214);

var _parseUtils2 = _interopRequireDefault(_parseUtils);

var _parsePath = __webpack_require__(509);

var parsePath = _interopRequireWildcard(_parsePath);

var _pageRouter = __webpack_require__(511);

var _pageRouter2 = _interopRequireDefault(_pageRouter);

var _path = __webpack_require__(220);

var _path2 = _interopRequireDefault(_path);

var _pageInit = __webpack_require__(485);

var _pageInit2 = _interopRequireDefault(_pageInit);

var _parseFunction = __webpack_require__(226);

var _parseFunction2 = _interopRequireDefault(_parseFunction);

var _parseBehavior = __webpack_require__(486);

var _parseBehavior2 = _interopRequireDefault(_parseBehavior);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// 自定义组件，JS逻辑
var com;
// import organize from './iteratorHandle'
// import toAppView from './toAppView'

var components = {};

var ParseComponent = function () {
  function ParseComponent(comObj, webviewId, config) {
    (0, _classCallCheck3.default)(this, ParseComponent);
    var customComponentId = config.customComponentId,
        componentInstanceId = config.componentInstanceId,
        parentCustomComponentId = config.parentCustomComponentId,
        parentComponentInstanceId = config.parentComponentInstanceId,
        slotCustomComponentId = config.slotCustomComponentId,
        slotComponentInstanceId = config.slotComponentInstanceId,
        selectors = config.selectors;

    comObj = _utils2.default.cloneObj(comObj);
    delete comObj.__wxWebviewId__;
    this.id = customComponentId;
    this.instanceId = componentInstanceId;
    this.webviewId = webviewId;
    this.parentCustomComponentId = parentCustomComponentId;
    this.parentComponentInstanceId = parentComponentInstanceId;
    this.data = comObj.data || {};
    this.observers = comObj.observers;
    this.properties = comObj.properties || {};
    this.methods = {};
    this.properties = comObj.properties;
    this.options = comObj.options || {};
    this.isAttatched = false;
    this.isCreated = false;
    // this.relationChild = {}
    this.relationInstance = {};
    this.selectors = selectors;
    // behaviors
    _parseUtils2.default.initBehaviors(comObj);

    //relations
    _parseUtils2.default.initRelations(this, comObj, slotCustomComponentId, slotComponentInstanceId, webviewId);

    for (var key in comObj) {
      _parseUtils2.default.copyComponentObjByKey(this, comObj, key);
    }
    _parseUtils2.default.doComponentLifeTime(this, 'created');
    this.isCreated = true;
    var params = {
      data: {
        id: this.id,
        instanceId: this.instanceId,
        data: this.data,
        COMPONENT_DEF: true,
        isAttatched: this.isAttatched
      }
    };
    _utils2.default.publish('componentDataChange', _parseFunction2.default.functionToString(params, this.webviewId), [this.webviewId]);
  }

  (0, _createClass3.default)(ParseComponent, [{
    key: 'setData',
    value: function setData(dataObj, cb) {
      if (!this.isCreated) return;
      try {
        var type = _utils2.default.getDataType(dataObj);
        "Object" !== type && _utils2.default.error("类型错误", "setData accepts an Object rather than some " + type);
        for (var key in dataObj) {
          parsePath.setObjectDataByPath(this.data, key, dataObj[key]);
          // var curValue = parsePath.getObjectByPath(this.data, key),
          //   curObj = curValue.obj,
          //   curKey = curValue.key
          // curObj && (curObj[curKey] = organize(dataObj[key]))
        }
        var params = {
          data: {
            id: this.id,
            instanceId: this.instanceId,
            data: dataObj,
            isAttatched: this.isAttatched
          }
        };
        _utils2.default.publish('componentDataChange', _parseFunction2.default.functionToString(params, this.webviewId), [this.webviewId]);
        typeof cb === 'function' && cb.call(this);
      } catch (e) {
        _utils2.default.errorReport(e);
      }
    }
  }, {
    key: 'triggerEvent',
    value: function triggerEvent(name, data, options) {
      var params = {
        data: {
          id: this.id,
          instanceId: this.instanceId,
          name: name,
          data: data,
          options: options,
          isTriggerEvent: true
        }
      };
      _utils2.default.publish('componentTriggerEvent', params, [this.webviewId]);
    }
  }, {
    key: 'getRelationNodes',
    value: function getRelationNodes(path) {
      var _this = this;

      path = _utils2.default.getFullPath(this.id, path);
      return (this.relationInstance[path] || []).map(function (i) {
        return _parseUtils2.default.getComponentInstances(i.id, i.instanceId, _this.webviewId);
      });
    }
  }, {
    key: 'selectComponent',
    value: function selectComponent(selector) {
      if (typeof selector !== 'string') return;
      var res = _parseUtils2.default.getSelectComponent(selector, this.__wxWebviewId__);
      return Array.isArray(res) ? res[0] : null;
    }
  }, {
    key: 'selectAllComponents',
    value: function selectAllComponents(selector) {
      if (typeof selector !== 'string') return;
      var res = _parseUtils2.default.getSelectComponent(selector, this.__wxWebviewId__);
      return res || [];
    }
  }]);
  return ParseComponent;
}();

var defaultTypeMap = {
  'Number': 0,
  'String': '',
  'Boolean': false,
  'Object': null,
  'Array': []
};

var Component = function Component(comObj) {
  (0, _classCallCheck3.default)(this, Component);

  if (!__wxRouteBegin) {
    _utils2.default.error('Component 注册错误', 'Please do not register multiple Component in ' + __wxRoute + '.js');
    new _utils2.default.AppServiceEngineKnownError('Please do not register multiple Component in ' + __wxRoute + '.js');
  }
  var n = {};
  comObj.data = comObj.data || {};
  comObj.options = comObj.options || {};
  comObj.properties = comObj.properties || {};
  if (Array.isArray(comObj.behaviors)) {
    var tmp = [];
    comObj.behaviors.forEach(function (i) {
      if (!tmp.includes(i)) {
        tmp.push(i);
      }
    });
    comObj.behaviors = tmp;
    var keys = ['data', 'properties'];
    keys.forEach(function (key) {
      comObj.behaviors.map(function (i) {
        return _parseBehavior2.default.getBehaviorByKey(i, key);
      }).forEach(function (i) {
        (0, _assign2.default)(comObj[key], i);
      });
    });
  }
  if (Array.isArray(comObj.externalClasses) && comObj.externalClasses.length) {
    comObj.externalClasses.forEach(function (className, index) {
      className = className.replace(/-[a-z]/g, function (val) {
        return val[1].toUpperCase();
      });
      if (!comObj.properties[className]) {
        comObj.properties[className] = {
          type: String,
          value: ''
        };
      } else {
        comObj.externalClasses.splice(index, 1);
      }
    });
  }
  for (var i in comObj.properties) {
    var o = comObj.properties[i];
    if (!o) {
      n[i] = {
        type: null,
        value: null,
        observer: null,
        public: true
      };
    } else if ((0, _keys2.default)(defaultTypeMap).includes(o.name)) {
      n[i] = {
        type: o.name,
        value: defaultTypeMap[o.name],
        observer: null,
        public: true
      };
    } else {
      n[i] = {
        type: null === o.type ? null : o.type.name,
        value: o.value || defaultTypeMap[o.name],
        observer: null === o.observer ? null : o.observer,
        public: true
      };
    }
    comObj.data[i] = n[i].value;
  }
  comObj.properties = n;
  __wxRouteBegin = false;
  components[__wxRoute] = comObj;
  var pages = __wxConfig__.pages;
  _utils2.default.info('Register Component: ' + __wxRoute);
  var pagePath = pages.find(function (p) {
    return p === __wxRoute;
  });
  if (!pagePath) {
    return;
  }
  if (pagePath.startsWith('/')) {
    pagePath = pagePath.substring(1, pagePath.length);
  }
  var pageConfig = __wxConfig__.window.pages[pagePath];
  if (!pageConfig) {
    return;
  }
  var pageObj = (0, _extends3.default)({}, comObj);

  pageObj['config'] = pageConfig;
  if (_utils2.default.getDataType(pageObj) !== 'Object') {
    _utils2.default.error('Component 注册错误', 'Options is not object: ' + (0, _stringify2.default)(pageObj) + ' in ' + __wxRoute + '.js');
    new _utils2.default.AppServiceEngineKnownError('Options is not object: ' + (0, _stringify2.default)(pageObj) + ' in ' + __wxRoute + '.js');
  }
  _utils2.default.info('Register Component: ' + pagePath);
  if (pagePath.substring(0, 1) !== '/') {
    pagePath = '/' + pagePath;
  }
  pageObj['path'] = pagePath;
  _pageRouter2.default.configObjs[pagePath] = pageObj;
};

function component_def_event(eventName, data, webviewId) {
  var customComponentId = data.customComponentId,
      componentInstanceId = data.componentInstanceId;

  var component = components[customComponentId] && new ParseComponent(components[customComponentId], webviewId, data);
  _parseUtils2.default.setComponentInstances(customComponentId, componentInstanceId, webviewId, component);
  _parseUtils2.default.setSelectorMap(component, webviewId);
  component_prop_update_event(eventName, data, webviewId);
}

function component_prop_update_event(eventName, data, webviewId) {
  var customComponentId = data.customComponentId,
      componentInstanceId = data.componentInstanceId,
      prop = data.prop;

  var component = _parseUtils2.default.getComponentInstances(customComponentId, componentInstanceId, webviewId);
  if (!component) return;
  component.data = (0, _assign2.default)({}, component.data, prop);
  for (var propKey in component.properties) {
    if (!(propKey in prop)) continue;
    var newVal = prop[propKey],
        property = component.properties[propKey],
        oldVal = property.value;
    if (newVal === oldVal) continue;
    if ((property.observer || component.observers) && !_utils2.default.deepEqual(newVal, oldVal)) {
      if (component.observers) {
        if (component.observers[propKey]) {
          component.observers[propKey].call(component, newVal, oldVal);
        } else {
          for (var key in component.observers) {
            var vkey = key + ',';
            if (vkey.indexOf(propKey + ',') >= 0) {
              component.observers[key].call(component, newVal, oldVal);
              break;
            }
          }
        }
      }
      var observer = property.observer;
      if (observer) {
        if (typeof observer === 'function') {
          observer.call(component, newVal, oldVal);
        } else if (typeof observer === 'string') {
          typeof component.methods[observer] === 'function' && component[observer](newVal, oldVal);
        }
      }
    }
    var val = _parseFunction2.default.setFunction(newVal, webviewId);
    component.properties[propKey].value = val;
    component.data[propKey] = val;
  }
}

function lifetime_method_event(eventName, data, webviewId) {
  var customComponentId = data.customComponentId,
      componentInstanceId = data.componentInstanceId,
      type = data.type;

  var component = _parseUtils2.default.getComponentInstances(customComponentId, componentInstanceId, webviewId);
  if (!component) return;
  switch (type) {
    case 'created':
      component.isCreated = true;
      _parseUtils2.default.doComponentLifeTime(component, type);
      break;
    case 'attached':
      var page = _pageRouter2.default.stackObjs[webviewId].page;

      if (!page.isInit) {
        lifetime_method_event('LIFETIME_METHOD', {
          customComponentId: customComponentId,
          componentInstanceId: componentInstanceId,
          type: 'ready'
        }, webviewId);
      }
      _parseUtils2.default.doComponentLifeTime(component, type);
      _parseUtils2.default.doRelationFunc(component, type, webviewId);
      _utils2.default.publish('componentDataChange', {
        data: {
          id: customComponentId,
          instanceId: componentInstanceId,
          isAttatched: component.isAttatched
        }
      }, [webviewId]);
      break;
    case 'detached':
      _utils2.default.publish('componentDetached', {
        data: {
          customComponentId: customComponentId,
          componentInstanceId: componentInstanceId
        }
      }, [webviewId]);
      _parseUtils2.default.doComponentLifeTime(component, type);
      _parseUtils2.default.doRelationFunc(component, type, webviewId);
      // 删除
      _parseUtils2.default.deleteComponentInstances(customComponentId, componentInstanceId, webviewId);
      break;
    default:
      _parseUtils2.default.doComponentLifeTime(component, type);
      break;

  }
}

function component_default_event(eventName, data, webviewId) {
  var customComponentId = data.customComponentId,
      componentInstanceId = data.componentInstanceId;

  var component = _parseUtils2.default.getComponentInstances(customComponentId, componentInstanceId, webviewId);
  if (!component) return;
  var parentCustomComponentId = component.parentCustomComponentId,
      parentComponentInstanceId = component.parentComponentInstanceId;

  var parentComp = void 0;
  if (parentCustomComponentId && parentComponentInstanceId) {
    parentComp = _parseUtils2.default.getComponentInstances(parentCustomComponentId, parentComponentInstanceId, webviewId);
  }

  if (data.isTriggerEvent) {
    delete data.target.offsetLeft;
    delete data.target.offsetTop;
    delete data.currentTarget.offsetLeft;
    delete data.currentTarget.offsetTop;
    data.target.id = '';
    data.currentTarget.id = '';
    var page = _pageRouter2.default.stackObjs[webviewId].page;

    if (parentComp) {
      // 当该事件为组件triggerEvent触发
      typeof parentComp.methods[eventName] === 'function' && parentComp.methods[eventName](data);
    } else if (typeof page[eventName] === 'function') {
      // 没有方法则向Page找方法
      _pageInit2.default.doWebviewEvent(webviewId, eventName, data);
    } else if (typeof component.methods[eventName] === 'function') {
      component.methods[eventName](data);
    }
  } else {
    if (typeof component.methods[eventName] === 'function') {
      component.methods[eventName](data);
    } else if (parentComp) {
      typeof parentComp.methods[eventName] === 'function' && parentComp.methods[eventName](data);
    }
  }
}

wx.onComponentEvent(function (params) {
  var webviewId = params.webviewId,
      eventName = params.eventName,
      data = params.data;
  var customComponentId = data.customComponentId,
      componentInstanceId = data.componentInstanceId;

  var component = _parseUtils2.default.getComponentInstances(customComponentId, componentInstanceId, webviewId);

  switch (eventName) {
    case 'COMPONENT_DEF':
      component_def_event(eventName, data, webviewId);
      break;
    case 'COMPONENT_PROP_UPDATE':
      if (!component) return;
      component.isAttatched = true;
      component_prop_update_event(eventName, data, webviewId);
      break;
    case 'LIFETIME_METHOD':
      if (!component) return;
      component.isAttatched = true;
      lifetime_method_event(eventName, data, webviewId);
      break;
    default:
      if (!component) return;
      component.isAttatched = true;
      component_default_event(eventName, data, webviewId);
      break;
  }
});
// function handleEvent
function getComponents(compId, webviewId) {
  var arr = [];
  var config = __AppCode__[compId + '.json'];
  if (config) {
    var comObj = components[compId];
    comObj['__wxWebviewId__'] = webviewId;
    var _comObj$data = comObj.data,
        data = _comObj$data === undefined ? {} : _comObj$data,
        _comObj$properties = comObj.properties,
        properties = _comObj$properties === undefined ? {} : _comObj$properties,
        _comObj$options = comObj.options,
        options = _comObj$options === undefined ? {} : _comObj$options,
        _comObj$externalClass = comObj.externalClasses,
        externalClasses = _comObj$externalClass === undefined ? [] : _comObj$externalClass,
        _comObj$behaviors = comObj.behaviors,
        behaviors = _comObj$behaviors === undefined ? [] : _comObj$behaviors;

    arr.push({
      id: compId,
      properties: properties,
      data: data,
      options: options,
      externalClasses: externalClasses,
      customBehaviors: behaviors
    });
    if (config && config.usingComponents && (0, _keys2.default)(config.usingComponents).length > 0) {
      for (var key in config.usingComponents) {
        var s = config.usingComponents[key].startsWith('/') ? config.usingComponents[key].slice(1) : _path2.default.join(_path2.default.dirname(compId), config.usingComponents[key]);
        if (compId === s) continue;
        var a = getComponents(s, webviewId);
        arr = [].concat(arr, a);
      }
    }
  }
  return arr;
}
ServiceJSBridge.subscribe('request_custcomponent_info', function (params, t) {
  var coms = params.components;
  var arr = [];
  // 取所有用到的组件
  for (var i in coms) {
    arr = [].concat(arr, getComponents(coms[i], t));
  }
  var data = [];

  var _loop = function _loop(_i) {
    var s = data.filter(function (item, index) {
      return item && item.id === arr[_i].id;
    });
    if (s.length === 0) {
      data.push(arr[_i]);
    }
  };

  for (var _i in arr) {
    _loop(_i);
  }
  // 去注册组件
  ServiceJSBridge.publish('response_custcomponent_info', data, [t]);
});

var componentHolder = function componentHolder(comObj) {
  com = new Component(comObj);
};
var getComponent = function getComponent() {
  return com;
};
exports.default = {
  componentHolder: componentHolder,
  getComponent: getComponent,
  lifetime_method_event: lifetime_method_event
};

/***/ }),
/* 642 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var statusDefineFlag = 1;
var statusRequiringFlag = 2;
var statusRequiredFlag = 3;
var moduleArr = {};

var define = function define(path, fun) {
  moduleArr[path] = {
    status: statusDefineFlag,
    factory: fun,
    exports: {}
  };
};

var getPathPrefix = function getPathPrefix(pathname) {
  // 返回path
  var res = pathname.match(/(.*)\/([^\/]+)?$/);
  return res && res[1] ? res[1] : './';
};

var getRequireFun = function getRequireFun(pathname) {
  // e:path 返回相对e的require
  var pathPrefix = getPathPrefix(pathname);
  return function (path) {
    if (typeof path !== 'string') {
      throw new Error('require args must be a string');
    }
    var floderArr = [];
    if (/^[\./].*$/.test(path)) {
      var folders = (pathPrefix + '/' + path).split('/');
      var pathLength = folders.length;
      for (var i = 0; i < pathLength; ++i) {
        var folder = folders[i];
        if (folder != '' && folder != '.') {
          if (folder == '..') {
            if (floderArr.length == 0) {
              throw new Error("can't find module : " + path);
            }
            floderArr.pop();
          } else {
            i + 1 < pathLength && folders[i + 1] == '..' ? i++ : floderArr.push(folder);
          }
        }
      }
    } else {
      floderArr[0] = 'miniprogram_npm';
      floderArr[1] = path;
      floderArr[2] = 'index';
    }
    try {
      var pathname = floderArr.join('/');
      if (!/\.js$/.test(pathname)) {
        pathname += '.js';
      }
      return _require(pathname);
    } catch (e) {
      throw e;
    }
  };
};
var _require = function _require(path) {
  // exports o
  if (typeof path !== 'string') {
    throw new Error('require args must be a string');
  }
  var moduleObj = moduleArr[path];
  if (!moduleObj) throw new Error('module "' + path + '" is not defined');
  if (moduleObj.status === statusDefineFlag) {
    var factoryFun = moduleObj.factory;
    var module = {
      exports: {}
    };
    var exports;
    if (factoryFun) {
      try {
        moduleObj.status = statusRequiringFlag;
        exports = factoryFun(getRequireFun(path), module, module.exports);
      } catch (e) {}
    }
    moduleObj.exports = module.exports || exports;
    moduleObj.status = statusRequiredFlag;
    if (path === 'model/auth.js') {
      console.log('~~~~~~~~~~~moduleObj.status = statusRequiringFlag~~~~~~~~~~~~~');
    }
  }
  return moduleObj.exports;
};

exports.define = define;
exports.require = _require;

window.define = define;
window.require = _require;

window.requestAnimationFrame = function (func) {
  typeof func === 'function' && setTimeout(function () {
    func();
  }, 17);
};
window.cancelAnimationFrame = function (id) {
  clearTimeout(id);
};
wx.version = {
  info: '',
  updateTime: '2018.4.28 17:04:53',
  version: '2.0.4'
};

/***/ })
/******/ ]);